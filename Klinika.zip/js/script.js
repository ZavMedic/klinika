// Mobil menyuni boshqarish
const nav = document.querySelector('nav');
const navLinks = document.querySelectorAll('nav a');

// Mobil menyuni ochish/yopish
document.querySelector('.menu-toggle').addEventListener('click', () => {
    nav.classList.toggle('active');
});

// Har bir menyu linki bosilganda menyuni yopish
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        nav.classList.remove('active');
    });
});

// Touch eventlar
document.addEventListener('touchstart', handleTouchStart, false);
document.addEventListener('touchmove', handleTouchMove, false);

let x1 = null;

function handleTouchStart(event) {
    x1 = event.touches[0].clientX;
}

function handleTouchMove(event) {
    if (!x1) return;

    let x2 = event.touches[0].clientX;
    let xDiff = x2 - x1;

    if (xDiff > 50) {
        // Chapga siljitish
        nav.classList.remove('active');
    } else if (xDiff < -50) {
        // O'ngga siljitish
        nav.classList.add('active');
    }

    x1 = null;
}
// Misol uchun: Formani yuborishdan oldin tekshirish
document.querySelector('form').addEventListener('submit', function (event) {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;

    if (!username || !password || !role) {
        alert("Iltimos, barcha maydonlarni to'ldiring!");
        event.preventDefault();
    }
});