<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $hashed_password = password_hash($password, PASSWORD_BCRYPT); // Parolni hash qilish

    // Foydalanuvchi nomi bandligini tekshirish
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute(['username' => $username]);
    if ($stmt->rowCount() > 0) {
        echo "Bu foydalanuvchi nomi band!";
    } else {
        // Yangi foydalanuvchini qo'shish
        $query = "INSERT INTO users (username, password, role, status) 
                  VALUES (:username, :password, :role, 'faol')";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            'username' => $username,
            'password' => $hashed_password,
            'role' => $role
        ]);
        echo "Muvaffaqiyatli ro'yxatdan o'tdingiz!";
    }
}
?>

<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ro'yxatdan O'tish</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Ro'yxatdan O'tish</h1>
        <form method="POST">
            <label for="username">Foydalanuvchi nomi:</label>
            <input type="text" name="username" id="username" required>

            <label for="password">Parol:</label>
            <input type="password" name="password" id="password" required>

            <label for="role">Rol:</label>
            <select name="role" id="role" required>
                <option value="">Rolni tanlang</option>
                <option value="shifokor">Shifokor</option>
                <option value="hamshira">Hamshira</option>
                <option value="kassir">Kassir</option>
                <option value="sanitarka">Sanitarka</option>
                <option value="bugalter">Bugalter</option>
                <option value="rizerv1">Rizerv1</option>
                <option value="rizerv2">Rizerv2</option>
            </select>

            <button type="submit">Ro'yxatdan O'tish</button>
        </form>
        <p>Allaqachon ro'yxatdan o'tganmisiz? <a href="pages/login.php">Kirish</a></p>
    </div>
</body>
</html>