<?php
require_once '../includes/db.php';

$doctor_id = $_GET['doctor_id'] ?? null;

if ($doctor_id) {
    $stmt = $conn->prepare("SELECT * FROM services WHERE doctor_id = :doctor_id");
    $stmt->execute(['doctor_id' => $doctor_id]);
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: application/json');
    echo json_encode($services);
} else {
    echo json_encode([]);
}