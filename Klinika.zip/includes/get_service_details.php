<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isLoggedIn() || getUserRole() !== 'rahbar') {
    die("Ruxsat yo'q!");
}

$service_id = $_GET['service_id'] ?? 0;
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');

// Shifokorlar statistikasi
$doctors_query = "SELECT 
    d.id,
    d.username AS shifokor,
    COUNT(DISTINCT p.id) AS bemorlar_soni,
    SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) AS jami_tushum,
    SUM((s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) * 
        (SELECT COALESCE(SUM(sp.percentage), 0) FROM staff_percentages sp 
         WHERE sp.user_id = p.doctor_id AND sp.service_id = s.id) / 100) AS shifokor_ulushi,
    (SELECT COALESCE(SUM(sp.percentage), 0) FROM staff_percentages sp 
     WHERE sp.user_id = p.doctor_id AND sp.service_id = s.id) AS shifokor_foizi
FROM patients p
JOIN patient_services ps ON p.id = ps.patient_id
JOIN services s ON ps.service_id = s.id
JOIN users d ON p.doctor_id = d.id
WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
AND s.id = :service_id
GROUP BY d.id, d.username
ORDER BY jami_tushum DESC";
$doctors_stmt = $conn->prepare($doctors_query);
$doctors_stmt->execute(['start_date' => $start_date, 'end_date' => $end_date, 'service_id' => $service_id]);
$doctors_stats = $doctors_stmt->fetchAll(PDO::FETCH_ASSOC);

// Hamshiralar statistikasi
if ($service_id == 5) {
    $nurses_query = "SELECT 
        u.id,
        u.username AS hamshira,
        COUNT(DISTINCT p.id) AS bemorlar_soni,
        SUM(p.nurse_income) AS hamshira_ulushi,
        SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) AS jami_tushum,
        ROUND(100 * SUM(p.nurse_income) / NULLIF(SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100), 0), 2) AS hamshira_foizi
    FROM patients p
    JOIN patient_services ps ON p.id = ps.patient_id
    JOIN services s ON ps.service_id = s.id
    JOIN users u ON p.nurse_id = u.id
    WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
    AND s.id = :service_id
    GROUP BY u.id, u.username
    ORDER BY hamshira_ulushi DESC";
} else {
    $nurses_query = "SELECT 
        n.id,
        n.username AS hamshira,
        COUNT(DISTINCT p.id) AS bemorlar_soni,
        SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) AS jami_tushum,
        SUM((s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) * 
            (SELECT COALESCE(SUM(sp.percentage), 0) FROM staff_percentages sp 
             WHERE sp.user_id = p.nurse_id AND sp.service_id = s.id) / 100) AS hamshira_ulushi,
        (SELECT COALESCE(SUM(sp.percentage), 0) FROM staff_percentages sp 
         WHERE sp.user_id = p.nurse_id AND sp.service_id = s.id) AS hamshira_foizi
    FROM patients p
    JOIN patient_services ps ON p.id = ps.patient_id
    JOIN services s ON ps.service_id = s.id
    JOIN users n ON p.nurse_id = n.id
    WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
    AND s.id = :service_id
    GROUP BY n.id, n.username
    ORDER BY jami_tushum DESC";
}
$nurses_stmt = $conn->prepare($nurses_query);
$nurses_stmt->execute(['start_date' => $start_date, 'end_date' => $end_date, 'service_id' => $service_id]);
$nurses_stats = $nurses_stmt->fetchAll(PDO::FETCH_ASSOC);

// Umumiy xizmat statistikasi
$service_query = "SELECT 
    s.name AS xizmat_turi,
    COUNT(DISTINCT p.id) AS umumiy_bemorlar_soni,
    SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) AS umumiy_tushum
FROM patients p
JOIN patient_services ps ON p.id = ps.patient_id
JOIN services s ON ps.service_id = s.id
WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
AND s.id = :service_id";
$service_stmt = $conn->prepare($service_query);
$service_stmt->execute(['start_date' => $start_date, 'end_date' => $end_date, 'service_id' => $service_id]);
$service_stats = $service_stmt->fetch(PDO::FETCH_ASSOC);
?>

<div class="service-details-container">
    <h5><?= htmlspecialchars($service_stats['xizmat_turi']) ?> xizmati bo'yicha tafsilotlar</h5>
    <div class="row">
        <!-- Shifokorlar -->
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0">Shifokorlar statistikasi</h6>
                </div>
                <div class="card-body">
                    <?php if (!empty($doctors_stats)): ?>
                        <div class="table-responsive">
                            <table class="table table-sm table-bordered">
                                <thead>
                                    <tr>
                                        <th>Shifokor</th>
                                        <th>Bemorlar</th>
                                        <th>Jami Tushum</th>
                                        <th>Shifokor Ulushi</th>
                                        <th>Ulush %</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($doctors_stats as $doctor): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($doctor['shifokor']) ?></td>
                                            <td><?= $doctor['bemorlar_soni'] ?></td>
                                            <td><?= number_format($doctor['jami_tushum'], 0, ',', ' ') ?> so'm</td>
                                            <td><?= number_format($doctor['shifokor_ulushi'], 0, ',', ' ') ?> so'm</td>
                                            <td><?= $doctor['shifokor_foizi'] ?>%</td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-center">Shifokorlar statistikasi topilmadi</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Hamshiralar (faqat xizmat_id=5 uchun nurce_income bo'yicha) -->
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0">Hamshiralar statistikasi</h6>
                </div>
                <div class="card-body">
                    <?php if (!empty($nurses_stats)): ?>
                        <div class="table-responsive">
                            <table class="table table-sm table-bordered">
                                <thead>
                                    <tr>
                                        <th>Hamshira</th>
                                        <th>Bemorlar</th>
                                        <th>Jami Tushum</th>
                                        <th>Hamshira Ulushi</th>
                                        <th>Ulush %</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($nurses_stats as $nurse): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($nurse['hamshira']) ?></td>
                                            <td><?= $nurse['bemorlar_soni'] ?></td>
                                            <td><?= number_format($nurse['jami_tushum'], 0, ',', ' ') ?> so'm</td>
                                            <td><?= number_format($nurse['hamshira_ulushi'], 0, ',', ' ') ?> so'm</td>
                                            <td><?= $nurse['hamshira_foizi'] ?>%</td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-center">Hamshiralar statistikasi topilmadi</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Umumiy statistika -->
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h6 class="mb-0">Umumiy statistika</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <p><strong>Bemorlar soni:</strong> <?= $service_stats['umumiy_bemorlar_soni'] ?></p>
                </div>
                <div class="col-md-4">
                    <p><strong>Jami tushum:</strong> <?= number_format($service_stats['umumiy_tushum'], 0, ',', ' ') ?> so'm</p>
                </div>
                <div class="col-md-4">
                    <p><strong>Davr:</strong> <?= $start_date ?> dan <?= $end_date ?> gacha</p>
                </div>
            </div>
        </div>
    </div>
</div>
