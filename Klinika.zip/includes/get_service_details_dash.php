<?php
header('Content-Type: text/html; charset=utf-8');

// Sessionni boshlash
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Foydalanuvchi tizimga kirganligini tekshirish
if (!isLoggedIn()) {
    die('<div class="alert alert-danger">Kirish mumkin emas. Iltimos, tizimga kiring.</div>');
}

$role = getUserRole();
$user_id = $_SESSION['user']['id'];

// Ma'lumotlarni olish
$service_id = isset($_POST['service_id']) ? intval($_POST['service_id']) : 0;
$date = isset($_POST['date']) ? $_POST['date'] : date('Y-m-d');

if ($service_id <= 0) {
    die('<div class="alert alert-danger">Noto\'g\'ri xizmat IDsi</div>');
}

try {
    // Bemorlarni olish
    $query = "SELECT 
                p.id,
                p.full_name AS bemor,
                p.price,
                p.payment_method,
                p.created_at,
                u1.username AS shifokor,
                u2.username AS hamshira
              FROM patients p
              JOIN patient_services ps ON p.id = ps.patient_id
              LEFT JOIN users u1 ON p.doctor_id = u1.id
              LEFT JOIN users u2 ON p.nurse_id = u2.id
              WHERE DATE(p.created_at) = :date 
              AND ps.service_id = :service_id
              " . ($role == 'shifokor' ? "AND p.doctor_id = :user_id" : "AND p.nurse_id = :user_id") . "
              AND p.debt = 0
              ORDER BY p.created_at DESC";

    $stmt = $conn->prepare($query);
    $params = ['date' => $date, 'service_id' => $service_id];
    if ($role == 'shifokor' || $role == 'hamshira') {
        $params['user_id'] = $user_id;
    }
    $stmt->execute($params);
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Jadvalni chiqarish
    if (!empty($patients)) {
        echo '<div class="table-responsive">';
        echo '<table class="table table-bordered table-hover">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Bemor</th>';
        echo '<th>To\'lov</th>';
        echo '<th>Usul</th>';
        echo '<th>Vaqt</th>';
        if ($role == 'shifokor') {
            echo '<th>Hamshira</th>';
        } else {
            echo '<th>Shifokor</th>';
        }
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($patients as $patient) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($patient['bemor']) . '</td>';
            echo '<td>' . number_format($patient['price'], 0, '.', ',') . ' so\'m</td>';
            echo '<td>' . htmlspecialchars($patient['payment_method']) . '</td>';
            echo '<td>' . date('H:i', strtotime($patient['created_at'])) . '</td>';
            if ($role == 'shifokor') {
                echo '<td>' . htmlspecialchars($patient['hamshira']) . '</td>';
            } else {
                echo '<td>' . htmlspecialchars($patient['shifokor']) . '</td>';
            }
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
        
        // Jami summa
        $total = array_sum(array_column($patients, 'price'));
        echo '<div class="alert alert-success mt-3">';
        echo '<strong>Jami:</strong> ' . number_format($total, 0, '.', ',') . ' so\'m';
        echo '</div>';
    } else {
        echo '<div class="alert alert-info">Bugun hech qanday bemor topilmadi.</div>';
    }
} catch (PDOException $e) {
    echo '<div class="alert alert-danger">';
    echo '<strong>Database Xatosi:</strong> ' . htmlspecialchars($e->getMessage());
    echo '</div>';
}
?>