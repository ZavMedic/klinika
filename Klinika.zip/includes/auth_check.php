<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user'])) {
    // Joriy sahifani saqlab qo'yish
    $redirect_url = $_SERVER['REQUEST_URI'];
    header("Location: ../pages/login.php?redirect=" . urlencode($redirect_url));
    exit();
}

// Sessiya vaqtini tekshirish (30 daqiqadan keyin avtomatik chiqish)
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
    session_unset();
    session_destroy();
    header("Location: ../pages/login.php");
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time();