<?php
session_start();
session_unset(); // Sessiyadagi barcha ma'lumotlarni tozalash
session_destroy(); // Sessiyani yo'q qilish
header("Location: ../pages/login.php"); // Login sahifasiga yo'naltirish
exit();
?>