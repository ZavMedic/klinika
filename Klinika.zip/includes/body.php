
<body class="d-flex flex-column min-vh-100">
    <!-- Asosiy kontent -->
    <?php include 'medical_jokes.php'; ?>

    <main class="flex-grow-1">
        <div class="container py-4">
            <!-- Orqaga qaytish tugmasi -->
            <div class="mb-4">
                <a href="dashboard.php" class="btn btn-outline-primary">
                    <i class="bi bi-arrow-left"></i> Bosh sahifaga qaytish
                </a>
            </div>
            
            <!-- Kontent maydoni 
            <?php if (isset($content)): ?>
                <div class="content-wrapper">
                    <?= $content ?>
                </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    Kontent topilmadi
                </div>
            <?php endif; ?>  -->
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-light py-3 mt-auto">
        <div class="container text-center">
            <p class="mb-0 text-muted">
                &copy; <?= date('Y') ?> Happy Medline. Barcha huquqlar himoyalangan.
            </p>
        </div>
    </footer>

    <!-- JavaScript kutubxonalari -->
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" 
            crossorigin="anonymous"></script>
    
    <!-- Custom JavaScript fayllar -->
    <script src="/assets/js/main.js"></script>
</body>
</html>