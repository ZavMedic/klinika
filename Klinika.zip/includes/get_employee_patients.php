<?php
header('Content-Type: text/html; charset=utf-8');

// Sessionni boshlash
//if (session_status() === PHP_SESSION_NONE) {
//    session_start();
//}

require_once '../includes/db.php';
require_once '../includes/functions.php';

// Foydalanuvchi tizimga kirganligini tekshirish
if (!isLoggedIn()) {
    echo '<div class="alert alert-danger">Kirish mumkin emas. Iltimos, tizimga kiring.</div>';
    exit;
}

$role = getUserRole();
$user_id = $_SESSION['user']['id'];

// Faqat rahbar va kassir uchun ruxsat
if (!in_array($role, ['rahbar', 'kassir'])) {
    echo '<div class="alert alert-danger">Ruxsat yo\'q</div>';
    exit;
}

// Ma'lumotlarni olish
$employee_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
$employee_role = isset($_POST['role']) ? $_POST['role'] : '';
$date = isset($_POST['date']) ? $_POST['date'] : date('Y-m-d');

if ($employee_id <= 0 || empty($employee_role)) {
    echo '<div class="alert alert-danger">Noto\'g\'ri ma\'lumotlar</div>';
    exit;
}

try {
    // Asosiy bemorlarni olish
    if ($employee_role == 'shifokor') {
        $query = "SELECT 
                    p.id,
                    p.full_name AS bemor,
                    p.price,
                    p.payment_method,
                    p.created_at,
                    u.username AS hamshira
                  FROM patients p
                  LEFT JOIN users u ON p.nurse_id = u.id
                  WHERE DATE(p.created_at) = :date 
                  AND p.doctor_id = :employee_id
                  AND p.debt = 0
                  ORDER BY p.created_at DESC";
    } else {
        $query = "SELECT 
                    p.id,
                    p.full_name AS bemor,
                    p.price,
                    p.payment_method,
                    p.created_at,
                    u.username AS shifokor
                  FROM patients p
                  LEFT JOIN users u ON p.doctor_id = u.id
                  WHERE DATE(p.created_at) = :date 
                  AND p.nurse_id = :employee_id
                  AND p.debt = 0
                  ORDER BY p.created_at DESC";
    }

    $stmt = $conn->prepare($query);
    $stmt->execute([
        'date' => $date,
        'employee_id' => $employee_id
    ]);
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($patients)) {
        // Har bir bemor uchun xizmat turlarini olish
        foreach ($patients as &$patient) {
            $service_query = "SELECT s.name 
                             FROM patient_services ps
                             JOIN services s ON ps.service_id = s.id
                             WHERE ps.patient_id = :patient_id";
            $service_stmt = $conn->prepare($service_query);
            $service_stmt->execute(['patient_id' => $patient['id']]);
            $services = $service_stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $patient['xizmatlar'] = implode(', ', $services);
        }
        unset($patient);

        // Jadvalni chiqarish
        echo '<div class="table-responsive">';
        echo '<table class="table table-bordered table-hover">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Bemor</th>';
        echo '<th>Xizmatlar</th>';
        echo '<th>Narx</th>';
        echo '<th>Turi</th>';
        echo '<th>Vaqt</th>';
        if ($employee_role == 'shifokor') {
            echo '<th>Hamshira</th>';
//        } else {
//            echo '<th>Shifokor</th>';
        }
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($patients as $patient) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($patient['bemor']) . '</td>';
            echo '<td>' . htmlspecialchars($patient['xizmatlar']) . '</td>';
            echo '<td>' . number_format($patient['price'], 0, '.', ',') . ' so\'m</td>';
            echo '<td>' . htmlspecialchars($patient['payment_method']) . '</td>';
            echo '<td>' . date('H:i', strtotime($patient['created_at'])) . '</td>';
            if ($employee_role == 'shifokor') {
                echo '<td>' . htmlspecialchars($patient['hamshira']) . '</td>';
//            } else {
//                echo '<td>' . htmlspecialchars($patient['shifokor']) . '</td>';
            }
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
        
        // Jami summa
        $total = array_sum(array_column($patients, 'price'));
        echo '<div class="alert alert-success mt-3">';
        echo '<strong>Jami:</strong> ' . number_format($total, 0, '.', ',') . ' so\'m';
        echo '</div>';
    } else {
        echo '<div class="alert alert-info">Bugun hech qanday bemor topilmadi.</div>';
    }
} catch (PDOException $e) {
    echo '<div class="alert alert-danger">';
    echo '<strong>Database Xatosi:</strong> ' . htmlspecialchars($e->getMessage());
    echo '</div>';
} catch (Exception $e) {
    echo '<div class="alert alert-danger">';
    echo '<strong>Xatolik:</strong> ' . htmlspecialchars($e->getMessage());
    echo '</div>';
}
?>