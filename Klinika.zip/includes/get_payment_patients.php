<?php
// Xatoliklarni ko'rsatish
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'db.php';
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $paymentType = $_POST['payment_type'] ?? null;
    $today = date('Y-m-d');

    if ($paymentType) {
        if ($paymentType === 'qarzdan_undirilgan') {
            // Bugun qarzdan undirilganlar (debt_payments jadvalidan)
            $stmt = $conn->prepare("
                SELECT 
                    p.full_name,
                    dp.patient_id,
                    dp.payment_method,
                    SUM(dp.debt_amount + dp.medicine_cost) AS total_paid
                FROM debt_payments dp
                JOIN patients p ON dp.patient_id = p.id
                WHERE DATE(dp.repayment_date) = :today
                  AND DATE(p.created_at) != :today
                GROUP BY dp.patient_id, dp.payment_method
                ORDER BY p.full_name
            ");
            $stmt->execute(['today' => $today]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($rows) {
                $totalDebtors = count($rows);
                echo "<div class='mb-3'>";
                echo "<h5><span class='badge bg-success'>Undirilgan: {$totalDebtors} ta</span></h5>";
                echo "</div>";

                echo '<div class="table-responsive">';
                echo '<table class="table table-striped">';
                echo '<thead><tr><th>Ism</th><th>Toʻlov Turi</th><th>Qaytarilgan Qarz</th></tr></thead><tbody>';

                foreach ($rows as $row) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($row['full_name']) . '</td>';
                    echo '<td>' . ucfirst($row['payment_method']) . '</td>';
                    echo '<td>' . number_format($row['total_paid'], 0, '.', ',') . ' so\'m</td>';
                    
                    echo '</tr>';
                }

                echo '</tbody></table>';
                echo '</div>';
            } else {
                echo "<div class='alert alert-warning'>Bugun qarzdan hech kim to'lamagan.</div>";
            }
        } 
        elseif ($paymentType === 'qarz') {
            $stmt = $conn->prepare("
                SELECT full_name, phone_number, price, created_at 
                FROM patients 
                WHERE DATE(created_at) = :today 
                AND debt = 1
            ");
            $stmt->execute(['today' => $today]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // pastda chiqaramiz
            printPatientsTable($rows, 'qarz');
        }
        
        elseif ($paymentType === 'dori') {
            $stmt = $conn->prepare("
                SELECT comment, amount, created_at 
                FROM expenses 
                WHERE DATE(created_at) = :today 
                AND comment LIKE '%Bemor uchun dori%'
            ");
            $stmt->execute(['today' => $today]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // pastda chiqaramiz
            printPatientsTable($rows, 'dori');
        } 
        elseif ($paymentType === 'boshqa') {
    $stmt = $conn->prepare("
        SELECT comment, amount, created_at 
        FROM expenses 
        WHERE DATE(created_at) = :today 
        AND comment NOT LIKE '%Bemor uchun dori%'
    ");
    $stmt->execute(['today' => $today]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // pastda chiqaramiz
    printPatientsTable($rows, 'boshqa');
}

        else {
            $stmt = $conn->prepare("
                SELECT full_name, phone_number, price, created_at 
                FROM patients 
                WHERE DATE(created_at) = :today 
                AND payment_method = :payment_type 
                AND debt = 0
            ");
            $stmt->execute([
                'today' => $today,
                'payment_type' => $paymentType
            ]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // pastda chiqaramiz
            printPatientsTable($rows, 'normal');
        }

    } else {
        echo "<div class='alert alert-danger'>To'lov turi aniqlanmadi.</div>";
    }
} else {
    echo "<div class='alert alert-danger'>Noto'g'ri so'rov turi.</div>";
}

// Reusable funksiya
function printPatientsTable($rows, $mode) {
    if ($rows) {
        echo "<div class='mb-3'>";
        echo "<h5><span class='badge bg-success'>Jami: " . count($rows) . " ta bemor</span></h5>";
        echo "</div>";

        echo '<div class="table-responsive">';
        echo '<table class="table table-striped">';
        echo '<thead><tr>';

        if ($mode === 'dori' || $mode === 'boshqa') {
            echo '<th>Izoh</th><th>Summasi</th><th>Vaqt</th>';
        } elseif ($mode === 'qarz') {
            echo '<th>Ism</th><th>Telefon</th><th>Qarz (so‘m)</th><th>Vaqt</th>';
        } else {
            echo '<th>Ism</th><th>Telefon</th><th>Summa (so‘m)</th><th>Vaqt</th>';
        }

        echo '</tr></thead><tbody>';

        foreach ($rows as $row) {
            echo '<tr>';

            if ($mode === 'dori' || $mode === 'boshqa') {
                echo '<td>' . htmlspecialchars($row['comment']) . '</td>';
                echo '<td>' . number_format($row['amount'], 0, '.', ',') . ' so\'m</td>';
                echo '<td>' . date('H:i', strtotime($row['created_at'])) . '</td>';
            } elseif ($mode === 'qarz') {
                echo '<td>' . htmlspecialchars($row['full_name']) . '</td>';
                echo '<td>' . htmlspecialchars($row['phone_number']) . '</td>';
                echo '<td>' . number_format($row['price'], 0, '.', ',') . ' so\'m</td>';
                echo '<td>' . date('H:i', strtotime($row['created_at'])) . '</td>';
            } else {
                echo '<td>' . htmlspecialchars($row['full_name']) . '</td>';
                echo '<td>' . htmlspecialchars($row['phone_number']) . '</td>';
                echo '<td>' . number_format($row['price'], 0, '.', ',') . ' so\'m</td>';
                echo '<td>' . date('H:i', strtotime($row['created_at'])) . '</td>';
            }

            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    } else {
        echo "<div class='alert alert-warning'>Hech qanday ma'lumot topilmadi.</div>";
    }
}
?>
