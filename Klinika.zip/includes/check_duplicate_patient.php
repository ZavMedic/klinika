<?php
require_once 'db.php';
header('Content-Type: application/json');

if (isset($_GET['full_name']) && isset($_GET['price'])) {
    $full_name = trim($_GET['full_name']);
    $price = floatval($_GET['price']);
    
    $stmt = $conn->prepare("
        SELECT *, DATE_FORMAT(created_at, '%H:%i') as time 
        FROM patients 
        WHERE full_name = :full_name 
        AND price = :price 
        AND DATE(created_at) = CURDATE() 
        ORDER BY created_at DESC 
        LIMIT 1
    ");
    $stmt->execute(['full_name' => $full_name, 'price' => $price]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($patient) {
        echo json_encode([
            'exists' => true,
            'patient' => $patient
        ]);
    } else {
        echo json_encode(['exists' => false]);
    }
} else {
    echo json_encode(['exists' => false]);
}
?>