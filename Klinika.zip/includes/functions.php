<?php
// Sessiya sozlamalari
function initSession() {
    if (session_status() === PHP_SESSION_NONE) {
        // 30 kunlik sessiya (2592000 soniya)
        ini_set('session.gc_maxlifetime', 2592000);
        session_set_cookie_params([
            'lifetime' => 2592000,
            'path' => '/',
            'domain' => $_SERVER['HTTP_HOST'],
            'secure' => isset($_SERVER['HTTPS']),
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
        session_start();
        
        // Sessiya yangilash
        if (!isset($_SESSION['CREATED'])) {
            $_SESSION['CREATED'] = time();
        } elseif (time() - $_SESSION['CREATED'] > 18000) {
            // 300 daqiqadan keyin sessiya ID sini yangilash
            session_regenerate_id(true);
            $_SESSION['CREATED'] = time();
        }
    }
}

function isLoggedIn() {
    initSession();
    return isset($_SESSION['user']);
}

//function redirect($url) {
//    header("Location: $url");
//    exit();
//}
function redirect($url) {
    if (!headers_sent()) {
        header("Location: $url");
        exit();
    } else {
        echo "<script>window.location.href='$url';</script>";
        exit();
    }
}


function getUserRole() {
    initSession();
    return $_SESSION['user']['role'] ?? null;
}

function canAddPatient() {
    initSession();
    if (!isset($_SESSION['last_patient_added_time'])) {
        return true;
    }
    $current_time = time();
    $last_added_time = $_SESSION['last_patient_added_time'];
    return ($current_time - $last_added_time) >= 10; // 10 soniya oralig'i
}

function setLastPatientAddedTime() {
    initSession();
    $_SESSION['last_patient_added_time'] = time();
}

// Xatoliklarni log qilish
function logError($message) {
    file_put_contents('../logs/error.log', date('Y-m-d H:i:s')." - ".$message.PHP_EOL, FILE_APPEND);
}

function formatPhoneNumber($phone) {
    if (empty($phone)) {
        return '';
    }
    // Raqamni +998901234567 formatidan +998(90)123-45-67 formatiga o'tkazish
    return preg_replace('/(\+998)(\d{2})(\d{3})(\d{2})(\d{2})/', '$1($2)$3-$4-$5', $phone);
}

function sendTelegramMessage($chat_id, $message, $parse_mode = 'HTML') {
    $config = include '../../config.php';
    $data = [
        'action' => 'send_notification',
        'chat_id' => $chat_id,
        'message' => $message,
        'parse_mode' => $parse_mode
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://happymedline.uz/bot.php');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 2); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $response = curl_exec($ch);
    curl_close($ch);
    
    return $response;
}

function formatPatientNotification($patient) {
    $message = "🆔 **Yangi bemor qo'shildi**\n\n";
    $message .= "👤 **Ism:** " . htmlspecialchars($patient['full_name']) . "\n";
    $message .= "📅 **Tug'ilgan yili:** " . $patient['birth_year'] . "\n";
    $message .= "🏥 **Xizmatlar:** " . ($patient['service_names'] ?? '-') . "\n";
    $message .= "💰 **Narxi:** " . number_format($patient['price'], 0, ',', ' ') . " so'm\n";
    
    if (!empty($patient['medicine_cost']) && $patient['medicine_cost'] > 0) {
        $message .= "💊 **Dori narxi:** " . number_format($patient['medicine_cost'], 0, ',', ' ') . " so'm\n";
        $message .= "🧾 **Jami:** " . number_format($patient['price'] + $patient['medicine_cost'], 0, ',', ' ') . " so'm\n";
    }
    
    $message .= "⏰ **Sana:** " . $patient['created_at'] . "\n";
    return $message;
}

// Avtomatik sessiya boshlash
initSession();
?>