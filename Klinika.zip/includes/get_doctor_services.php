<?php
require_once '../includes/db.php';

$doctor_id = $_GET['doctor_id'] ?? null;

if ($doctor_id) {
    $stmt = $conn->prepare("
        SELECT s.id, s.name, s.price, sp.percentage 
        FROM services s 
        LEFT JOIN staff_percentages sp ON s.id = sp.service_id AND sp.user_id = :doctor_id 
        WHERE s.doctor_id = :doctor_id
    ");
    $stmt->execute(['doctor_id' => $doctor_id]);
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($services);
}
?>