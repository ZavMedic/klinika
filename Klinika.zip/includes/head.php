<?php
require_once 'db.php';
//require_once 'functions.php';

// Sessiya sozlamalari (boshida)
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.gc_maxlifetime', 2592000); // 30 kun (60*60*24*30)
    session_set_cookie_params([
        'lifetime' => 2592000,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => isset($_SERVER['HTTPS']), // HTTPS bo'lsa
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// Sessiya yangilash
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 18000)) {
    // 300 daqiqadan ortiq faolsizlikda sessiyani yangilash
    session_regenerate_id(true);
    $_SESSION['LAST_ACTIVITY'] = time();
}

// Avtomatik chiqish qilish
if (isset($_SESSION['user']) && isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 2592000)) {
    session_unset();
    session_destroy();
    redirect('../pages/login.php');
}

$_SESSION['LAST_ACTIVITY'] = time(); // Har bir yuklanishda yangilash

if (!isLoggedIn()) {
    redirect('../pages/login.php');
}


// Qarzdorlar soni (kassir uchun)
$debtors_count = 0;
if (in_array(getUserRole(), ['kassir', 'rahbar'])) {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM patients WHERE debt = 1");
    $stmt->execute();
    $debtors_count = $stmt->fetchColumn();
}


$role = getUserRole();
$username = $_SESSION['user']['username'];
$current_user_id = $_SESSION['user']['id'];
?>

<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? 'HappyMed Boshqaruv Tizimi') ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="https://happymedline.uz/favicon.ico">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/style.css?v=3&HappyMedline">
    
    <!-- jQuery -->
    <!-- jQuery va jQuery UI -->
<script src="https://code.jquery.com/ui/1.13.0/jquery-ui.min.js"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<style>
    .navbar-custom {
        background-color: #ffffff; /* Oq fon */
        box-shadow: 0 2px 4px rgba(0,0,0,0.1); /* Soyani qo'shamiz */
    }
    .navbar-custom .navbar-brand,
    .navbar-custom .nav-link {
        color: #000000 !important; /* Qora rang */
        font-weight: 500;
    }
    .navbar-custom .nav-link:hover {
        color: #0d6efd !important; /* Sichqoncha ustiga borganda ko'k rang */
    }
    .badge-notification {
        font-size: 0.7rem;
        top: 5px !important;
    }
    .navbar-toggler {
        border-color: rgba(0,0,0,0.1); /* Togglerni chegarasi */
    }
</style>
</head>
<body>
    <div class="container-fluid px-0">
        <!-- Navbar with visible text -->
        <nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container">
        <a class="navbar-brand fw-bold" href="./../pages/dashboard.php">
            <i class="fas fa-hospital me-2 text-primary"></i> <!-- Iconni ko'k qilamiz -->
            <span>Salom, <?= htmlspecialchars($username) ?> (<?= $role ?>)</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                        <?php if ($role === 'rahbar'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/reports.php"><i class="fas fa-chart-bar me-1"></i> Hisobotlar</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/dashboard2.php"><i class="fas fa-users me-1"></i> Xodimlar</a>
                            </li>						
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/patients.php"><i class="fas fa-procedures me-1"></i> Qabul</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/payment.php"><i class="fas fa-money-bill-wave me-1"></i> Maoshlar</a>
                            </li>
                            <li class="nav-item position-relative">
                        <a class="nav-link" href="./../pages/debtors.php">
                            <i class="fas fa-money-bill-alt me-1"></i> Qarzlar
                            <?php if ($debtors_count > 0): ?>
<!--                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger badge-notification">-->
<span class="badge bg-primary">
                                    <?= $debtors_count ?>
                              </span></a>
                            <?php endif; ?>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/send_notifications.php"><i class="fas fa-sms me-1"></i> SMS</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/expenses.php"><i class="fas fa-receipt me-1"></i> Chiqimlar</a>
                            </li>
                        
                        <?php elseif ($role === 'kassir'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/patients.php"><i class="fas fa-user-plus me-1"></i> Qabul</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/reports_kas.php"><i class="fas fa-list me-1"></i> Bemorlar</a>
                            </li>
                            <li class="nav-item position-relative">
                        <a class="nav-link" href="./../pages/debtors.php">
                            <i class="fas fa-money-bill-alt me-1"></i> Qarzlar
                            <?php if ($debtors_count > 0): ?>
<!--                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger badge-notification">-->
<span class="badge bg-primary">
                                    <?= $debtors_count ?>
                              </span></a>
                            <?php endif; ?>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/payment_history.php"><i class="fas fa-history me-1"></i> Maoshlarim</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/expenses.php"><i class="fas fa-receipt me-1"></i> Chiqimlar</a>
                            </li>
                        
                        <?php elseif ($role === 'shifokor'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/employee_reports.php"><i class="fas fa-procedures me-1"></i> Bemorlarim</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./../pages/payment_history.php"><i class="fas fa-history me-1"></i> Maoshlarim</a>
                            </li>
                        
                        <?php elseif ($role === 'hamshira'): ?>
    <li class="nav-item">
        <a class="nav-link" href="./../pages/employee_reports.php"><i class="fas fa-procedures me-1"></i> Qabullarim</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./../pages/payment_history.php"><i class="fas fa-history me-1"></i> Maoshlarim</a>
    </li>
        <?php
    // Shu yerda PHP blok ochiladi
    if (in_array($current_user_id, [9, 10, 12])): ?>
        <li class="nav-item">
            <a class="nav-link" href="./../pages/employe_norma.php">
                <i class="fas fa-percent me-1"></i> Ulushlarim
            </a>
        </li>

    <li class="nav-item">
        <a class="nav-link" href="./../pages/patients.php"><i class="fas fa-user-plus me-1"></i> Bemor qo'shish</a>
    </li>

    <?php endif; ?>
<?php endif; ?>

                    </ul>
                    <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="../includes/logout.php">
                        <i class="fas fa-sign-out-alt me-1"></i> Chiqish
                    </a>
                </li>
            </ul>
                </div>
            </div>
        </nav>
    </div>
<!-- <?php include 'medical_jokes.php'; ?>
     Main content container 
    <div class="container mt-4 mb-5"> -->