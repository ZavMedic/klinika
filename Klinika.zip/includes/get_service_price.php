<?php
require_once '../includes/db.php';

$service_id = $_GET['service_id'] ?? null;

if ($service_id) {
    $stmt = $conn->prepare("SELECT price FROM services WHERE id = :service_id");
    $stmt->execute(['service_id' => $service_id]);
    $service = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($service) {
        echo json_encode(['price' => $service['price']]);
    } else {
        echo json_encode(['price' => 0]);
    }
} else {
    echo json_encode(['price' => 0]);
}