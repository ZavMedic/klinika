<?php
/**
 * staff_shares.php - Xodimlar ulushi (xizmat + bemor qo'shganlar uchun 4% + bonus)
 */

// SQL so'rov
$query = "
    SELECT 
        u.id,
        u.username AS xodim,
        CASE 
            WHEN u.role = 'kassir' THEN 'Kassir'
            WHEN u.role = 'shifokor' THEN 'Shifokor'
            WHEN u.role = 'hamshira' THEN 'Hamshira'
            ELSE u.role
        END AS position,

        -- Xizmat daromadi (shifokor va hamshira)
        SUM(CASE 
            WHEN u.role = 'shifokor' THEN p.doctor_income
            WHEN u.role = 'hamshira' THEN p.nurse_income
            ELSE 0
        END) AS service_income,

        -- Bemor qo'shganlar uchun 4% (cashier_id = u.id va qarzsiz)
        SUM(CASE 
            WHEN p.cashier_id = u.id AND p.debt = 0 THEN p.price * 0.04
            ELSE 0
        END) AS added_patient_income,

        -- Bonuslar
        COALESCE((
            SELECT SUM(b.amount) 
            FROM bonuses b 
            WHERE b.user_id = u.id 
              AND DATE(b.created_at) BETWEEN :start_date AND :end_date
        ), 0) AS bonus_amount,

        -- Jami daromad
        SUM(CASE 
            WHEN u.role = 'shifokor' THEN p.doctor_income
            WHEN u.role = 'hamshira' THEN p.nurse_income
            ELSE 0
        END) + 
        SUM(CASE 
            WHEN p.cashier_id = u.id AND p.debt = 0 THEN p.price * 0.04
            ELSE 0
        END) + 
        COALESCE((
            SELECT SUM(b.amount) 
            FROM bonuses b 
            WHERE b.user_id = u.id 
              AND DATE(b.created_at) BETWEEN :start_date AND :end_date
        ), 0) AS total_income

    FROM patients p
    LEFT JOIN users u ON (
        u.id IN (p.cashier_id, p.doctor_id, p.nurse_id)
    )
    WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
    GROUP BY u.id, u.username, u.role
    HAVING total_income > 0
    ORDER BY total_income DESC
";

$stmt = $conn->prepare($query);
$stmt->execute([
    'start_date' => $start_date,
    'end_date' => $end_date
]);
$all_staff = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_income_all_staff = array_sum(array_column($all_staff, 'total_income'));
$total_percentage = 0;

foreach ($all_staff as &$staff) {
    $staff['percentage'] = ($total_income_all_staff > 0) ?
        round(($staff['total_income'] / $total_income_all_staff) * 100, 2) : 0;
    $total_percentage += $staff['percentage'];
}
unset($staff);

// Jami % 100% bo'lishini tekshirish (yaxlitlash xatolari uchun)
if (abs($total_percentage - 100) > 0.1) {
    $last_index = count($all_staff) - 1;
    $all_staff[$last_index]['percentage'] += (100 - $total_percentage);
    $total_percentage = 100;
}
?>

<!-- Xodimlar ulushi sahifasi -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            Xodimlar Ulushi (<?= date('d.m.Y', strtotime($start_date)) ?> - <?= date('d.m.Y', strtotime($end_date)) ?>)
        </h6>
    </div>
    <div class="card-body">
        <!-- Diagramma -->
        <div class="chart-bar" style="height: 400px;">
            <canvas id="staffSharesChart"></canvas>
        </div>

        <!-- Jadval (pastda) -->
        <div class="table-responsive mt-5">
                <table class="table table-sm table-bordered">
        <thead class="bg-light">
            <tr>
                <th>Xodim</th>
                <th>Lavozim</th>
                <th>Jami</th>
                <th>Kassir</th>
                <th>Bonus</th>
                <th>Xizmat</th>
                <th>%</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($all_staff as $s): ?>
                <tr>
                    <td><?= htmlspecialchars($s['xodim']) ?></td>
                    <td><?= $s['position'] ?></td>
                                        <td><strong><?= number_format($s['total_income'], 0, ',', ' ') ?></strong> so'm</td>
                    
                    <td><?= number_format($s['added_patient_income'], 0, ',', ' ') ?> so'm</td>
                    <td><?= number_format($s['bonus_amount'], 0, ',', ' ') ?> so'm</td>
<td><?= number_format($s['service_income'], 0, ',', ' ') ?> so'm</td>
                    <td><strong><?= number_format($s['percentage'], 2, ',', ' ') ?></strong>%</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot class="font-weight-bold">
            <tr>
                <td colspan="2">Jami</td>
                <td><?= number_format($total_income_all_staff, 0, ',', ' ') ?> so'm</td>
                <td><?= number_format(array_sum(array_column($all_staff, 'added_patient_income')), 0, ',', ' ') ?> so'm</td>
                <td><?= number_format(array_sum(array_column($all_staff, 'bonus_amount')), 0, ',', ' ') ?> so'm</td>
                                <td><?= number_format(array_sum(array_column($all_staff, 'service_income')), 0, ',', ' ') ?> so'm</td>
                <td><?= number_format($total_percentage, 2, ',', ' ') ?>%</td>
            </tr>
        </tfoot>
    </table>
</div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('staffSharesChart').getContext('2d');
    const staffData = <?= json_encode($all_staff) ?>;

    const colors = staffData.map(s => {
        if (s.position === 'Shifokor') return '#4e73df';
        if (s.position === 'Hamshira') return '#1cc88a';
        return '#f6c23e';
    });

    // Yangi formatlash funksiyasi - faqat butun sonlar uchun
    const formatNumber = (num) => {
        // Avval butun songa yaxlitlash
        const rounded = Math.round(num);
        // So'ng probellar bilan formatlash
        return rounded.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    };

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: staffData.map(s => s.xodim),
            datasets: [
                {
                    label: 'Xizmat daromadi',
                    data: staffData.map(s => Math.round(s.service_income)), // Yaxlitlash
                    backgroundColor: colors.map(c => c + 'CC'),
                    borderColor: colors,
                    borderWidth: 1
                },
                {
                    label: '4%',
                    data: staffData.map(s => Math.round(s.added_patient_income)), // Yaxlitlash
                    backgroundColor: colors.map(c => c + '99'),
                    borderColor: colors,
                    borderWidth: 1
                },
                {
                    label: 'Bonus',
                    data: staffData.map(s => Math.round(s.bonus_amount)), // Yaxlitlash
                    backgroundColor: colors.map(c => c + '66'),
                    borderColor: colors,
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    stacked: true,
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: "Summa (so'm)"
                    },
                    ticks: {
                        callback: function(value) {
                            // Faqat butun sonlarni ko'rsatish
                            return formatNumber(value);
                        }
                    }
                },
                x: {
                    stacked: true,
                    title: {
                        display: true,
                        text: "Xodimlar"
                    }
                }
            },
            plugins: {
                legend: { position: 'bottom' },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed.y !== null) {
                                // Tooltipda ham butun son ko'rsatish
                                label += formatNumber(context.parsed.y) + " so'm";
                            }
                            return label;
                        },
                        afterBody: function(context) {
                            const staff = staffData[context[0].dataIndex];
                            return [
                                '-----------------------',
                                'Jami: ' + formatNumber(Math.round(staff.total_income)) + ' so\'m',
                                'Ulush: ' + staff.percentage.toFixed(2) + '%'
                            ];
                        }
                    }
                }
            }
        }
    });
});
</script>