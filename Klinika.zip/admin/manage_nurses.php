<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

//session_start();

// Faqat 4,9,10 iddagi hamshiralar ro'yxati
$nurse_ids = [4, 9, 10];
if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole();
if ($role !== 'rahbar') {
    die("Sizda bu sahifaga kirish uchun ruxsat yo'q!");
}

// Xatoliklarni olish funksiyasi
function getRecentErrors($conn, $ids) {
    $in = str_repeat('?,', count($ids) - 1) . '?';
    $stmt = $conn->prepare("
    SELECT staff_name, error_type, created_at 
    FROM staff_errors 
    WHERE staff_name COLLATE utf8_general_ci IN (
        SELECT username FROM users WHERE id IN ($in)
    ) 
    AND created_at >= DATE_SUB(NOW(), INTERVAL 10 DAY)
    ORDER BY created_at DESC
");
    $stmt->execute($ids);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Har bir xodimning (hamshira yoki kassir) faqat o'z xatolarini olish
function getStaffErrors($conn, $staff_name) {
    $stmt = $conn->prepare("
        SELECT error_type, created_at 
        FROM staff_errors 
        WHERE staff_name = :staff_name 
        AND created_at >= DATE_SUB(NOW(), INTERVAL 10 DAY)
        ORDER BY created_at DESC
    ");
    $stmt->execute(['staff_name' => $staff_name]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['staff_ids']) && isset($_POST['staff_percentage'])) {
        $staff_ids = $_POST['staff_ids'];
        $percentage = (float)$_POST['staff_percentage'];
        $action = $_POST['action_type'] ?? '';

        foreach ($staff_ids as $staff_id) {
            $staff_id = (int)$staff_id;

            $stmt = $conn->prepare("SELECT id, username, role, telegram_id FROM users WHERE id = ?");
            $stmt->execute([$staff_id]);
            $staff = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$staff) continue;

            $role = strtolower($staff['role']);
            $name = $staff['username'];
            $telegram_id = $staff['telegram_id'];

            $min = ($role === 'kassir') ? 3 : 40;
            $max = ($role === 'kassir') ? 6 : 70;
            $service_condition = ($role === 'kassir') ? "" : "AND service_id = 5";

            $stmt = $conn->prepare("SELECT percentage FROM staff_percentages WHERE user_id = ? $service_condition");
            $stmt->execute([$staff_id]);
            $current_percent = (float)$stmt->fetchColumn();

            $new_percent = $percentage;
            if ($action === 'increase') {
                $new_percent = min($current_percent + $percentage, $max);
            } elseif ($action === 'decrease' || $action === 'new_month') {
                $new_percent = max($current_percent - $percentage, $min);
            }

            $stmt = $conn->prepare("UPDATE staff_percentages SET percentage = ? WHERE user_id = ? $service_condition");
            $stmt->execute([$new_percent, $staff_id]);
                // ➡ Session xabarga tayyor ma'lumot
    $service_name = ($role === 'kassir') ? "Barcha xizmatlar" : "Hamshiralik xizmatlari Muolaja (id=5)";
    $change = $new_percent - $current_percent;

    $sessionMessages[] = "<b>{$name}</b>: $service_name uchun ulushi <b>{$current_percent}%</b> edi, " 
                       . (($change > 0) ? "➕" : "➖")
                       . "<b>" . abs($change) . "%</b> "
                       . (($change > 0) ? "oshdi" : "kamaydi") 
                       . ", hozirgi ulush: <b>{$new_percent}%</b>.";
        }

        // Xabar yuborish (hamshira va kassir bo'yicha farq qiladi)
foreach ($staff_ids as $staff_id) {
    $staff_id = (int)$staff_id;

    $stmt = $conn->prepare("SELECT id, username, role, telegram_id FROM users WHERE id = ?");
    $stmt->execute([$staff_id]);
    $staff = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$staff || empty($staff['telegram_id'])) continue;

    $role = strtolower($staff['role']);
    $name = $staff['username'];
    $telegram_id = $staff['telegram_id'];

    if ($role === 'hamshira' && in_array($staff_id, $nurse_ids)) {
        // Hamshiralar uchun
        $errors = getRecentErrors($conn, $nurse_ids);

        $diff = $new_percent - $current_percent; // farq
        $absDiff = abs($diff); // musbat qiymat

        $message = "<b>✅ Hurmatli {$name}</b>\n";
        $message .= "Oldingi ulush: <b>{$current_percent}%</b>\n";
        $message .= ($diff > 0) ? "➕ Ulush oshdi: <b>{$absDiff}%</b>\n" : "➖ Ulush kamaydi: <b>{$absDiff}%</b>\n";
        $message .= "Yangi ulush: <b>{$new_percent}%</b>\n\n";

        if ($action === 'increase') {
            if ($absDiff == 10) {
                $message .= "🎯 Hamshiralar birgalikda limitni bajardilar!";
            } elseif ($absDiff < 10) {
                $message .= "⚠️ Limit bajarildi ammo quyidagi oxirgi 10 kunlik xatoliklar aniqlandi:\n";
                foreach ($errors as $error) {
                    $message .= "• {$error['staff_name']}: {$error['error_type']} ({$error['created_at']})\n";
                }
            }
        } elseif ($action === 'decrease') {
            if ($absDiff >= 10) {
                $message .= "🚨 Limit bajarilmadi va quyidagi oxirgi 10 kunlik xatoliklar aniqlandi:\n";
            } else {
                $message .= "⚠️ Limit bajarildi ammo quyidagi oxirgi 10 kunlik xatoliklar aniqlandi:\n";
            }
            foreach ($errors as $error) {
                $message .= "• {$error['staff_name']}: {$error['error_type']} ({$error['created_at']})\n";
            }
        } elseif ($action === 'new_month') {
            if ($absDiff == 10) {
                $message .= "✅ Yangi oy uchun ulush normal tarzda 10% kamaydi.";
            } elseif ($absDiff >= 11 && $absDiff <= 19) {
                $message .= "⚠️ Yangi oyga o'tishda xatoliklar bo'lgan. Quyidagi xatoliklar:\n";
                foreach ($errors as $error) {
                    $message .= "• {$error['staff_name']}: {$error['error_type']} ({$error['created_at']})\n";
                }
            } elseif ($absDiff >= 20) {
                $message .= "🚨 Limit bajarilmadi va yangi oyga o'tishda quyidagi xatoliklar aniqlandi:\n";
                foreach ($errors as $error) {
                    $message .= "• {$error['staff_name']}: {$error['error_type']} ({$error['created_at']})\n";
                }
            }
        }

        sendTelegramMessage($telegram_id, $message, 'HTML');

    } elseif ($role === 'kassir') {
        // Kassirlar uchun odatdagidek
        $errors = getStaffErrors($conn, $name);

        $diff = $new_percent - $current_percent;
        $absDiff = abs($diff);

        $message = "<b>✅ Hurmatli {$name}</b>\n";
        $message .= "Oldingi ulush: <b>{$current_percent}%</b>\n";
        $message .= ($diff > 0) ? "➕ Ulush oshdi: <b>{$absDiff}%</b>\n" : "➖ Ulush kamaydi: <b>{$absDiff}%</b>\n";
        $message .= "Yangi ulush: <b>{$new_percent}%</b>\n\n";

        if (in_array($action, ['decrease', 'new_month'])) {
            if (!empty($errors)) {
                $message .= "🚨 Oxirgi 10 kunda aniqlangan xatoliklar:\n";
                foreach ($errors as $error) {
                    $message .= "• {$error['error_type']} ({$error['created_at']})\n";
                }
            } else {
                $message .= "✅ So'nggi 10 kunda hech qanday xatolik aniqlanmadi.";
            }
        }

        sendTelegramMessage($telegram_id, $message, 'HTML');
    }
}


// Session xabarini shakllantirish
$_SESSION['success'] = implode("<br>", $sessionMessages);
        header("Location: ".$_SERVER['PHP_SELF']);
        exit;
    }
}

// Faqat id=4,9,10 hamshiralar
$nurses = $conn->query("SELECT id, username FROM users WHERE id IN (4,9,10)")->fetchAll();

// Kassirlar
$cashiers = $conn->query("SELECT id, username FROM users WHERE role = 'kassir'")->fetchAll();



$title = "Ulushlar Boshqaruvi";
require_once '../includes/head.php';
?>

    <style>
        :root {
            --primary: #4e73df;
            --success: #1cc88a;
            --warning: #f6c23e;
            --danger: #e74a3b;
            --dark: #5a5c69;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fc;
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        
        h2 {
            color: var(--primary);
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #eee;
        }
        
        .card {
            border: none;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .card-header {
            background-color: var(--primary);
            color: white;
            padding: 15px 20px;
            border-radius: 8px 8px 0 0;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .staff-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .staff-item {
            display: flex;
            align-items: center;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .staff-item:hover {
            background: #e9ecef;
            transform: translateY(-2px);
        }
        
        .staff-item input {
            margin-right: 10px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-success {
            background-color: var(--success);
            color: white;
        }
        
        .btn-warning {
            background-color: var(--warning);
            color: white;
        }
        
        .btn-danger {
            background-color: var(--danger);
            color: white;
        }
        
        .btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Xodimlar ulushini belgilash <a href="errors_nurses.php" class="btn btn-warning">Xatoliklar</a>
        </h2>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?= $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="card">
                <div class="card-header">
                    <h3>Hamshiralar</h3>
                </div>
                <div class="card-body">
                    <div class="staff-list">
                        <?php foreach ($nurses as $nurse): ?>
    <?php
        // Har bir hamshira uchun service_id = 5 bo'yicha ulushni olish
        $stmt = $conn->prepare("SELECT percentage FROM staff_percentages WHERE user_id = ? AND service_id = 5");
        $stmt->execute([$nurse['id']]);
        $nurse_percentage = (float)$stmt->fetchColumn();
    ?>
    <div class="staff-item">
        <input type="checkbox" name="staff_ids[]" value="<?= $nurse['id'] ?>" id="nurse_<?= $nurse['id'] ?>">
        <label for="nurse_<?= $nurse['id'] ?>">
            <?= htmlspecialchars($nurse['username']) ?> (<b><?= $nurse_percentage ?>%</b>)
        </label>
        
    </div>
<?php endforeach; ?>
<button type="button" onclick="selectAllStaff()" class="btn btn-primary">
                Barchasini belgilash
            </button>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h3>Kassirlar</h3>
                </div>
                <div class="card-body">
                    <div class="staff-list">
                        <?php foreach ($cashiers as $cashier): ?>
    <?php
        // Har bir kassir uchun o'rtacha ulushni olish
        $stmt = $conn->prepare("SELECT AVG(percentage) FROM staff_percentages WHERE user_id = ?");
        $stmt->execute([$cashier['id']]);
        $cashier_percentage = round((float)$stmt->fetchColumn(), 1); // Bir xonali kasr bilan
    ?>
    <div class="staff-item">
        <input type="checkbox" class="manual-only" name="staff_ids[]" value="<?= $cashier['id'] ?>" id="cashier_<?= $cashier['id'] ?>">
        <label for="cashier_<?= $cashier['id'] ?>">
            <?= htmlspecialchars($cashier['username']) ?> (<b><?= $cashier_percentage ?>%</b> o'rtacha)
        </label>
    </div>
<?php endforeach; ?>

                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label for="percentage">Ulush qanchaga:</label>
                <input type="number" step="0.1" min="0" max="100" class="form-control" 
                       name="staff_percentage" id="percentage" required>
            </div>
            
            <div class="btn-group">
                <button type="submit" name="action_type" value="increase" class="btn btn-success">
                    Ulushni oshirish
                </button>
                <button type="submit" name="action_type" value="decrease" class="btn btn-warning">
                    Kamaytirish
                </button>
                <button type="submit" name="action_type" value="new_month" class="btn btn-danger">
                    Yangi oy
                </button>
            </div>
            
            
        </form>
    </div>

    <script>
let selectAllActive = false; // boshlanganda belgilanmagan

function selectAllStaff() {
    const checkboxes = document.querySelectorAll('input[type="checkbox"][name="staff_ids[]"]');
    selectAllActive = !selectAllActive; // holatni almashtiramiz

    checkboxes.forEach(checkbox => {
        if (!checkbox.classList.contains('manual-only')) {
            checkbox.checked = selectAllActive;
        }
    });
}


    </script>
<?php
require_once '../includes/body.php';
?>