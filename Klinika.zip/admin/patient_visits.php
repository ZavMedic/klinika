<?php
// patient_visits.php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('login.php');
}
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-t');

if (isset($_GET['details'])) {
    header('Content-Type: application/json');
    $name = $_GET['details'];

    // Agar sanalar berilmagan bo‘lsa, joriy oy bo‘yicha olamiz
    $start_date = $_GET['start_date'] ?? date('Y-m-01');
    $end_date = $_GET['end_date'] ?? date('Y-m-t');

    // 1. Bazadagi barcha noyob ism-familiyalar
    $patients = $conn->query("SELECT DISTINCT full_name FROM patients")->fetchAll(PDO::FETCH_COLUMN);

    // 2. O‘xshash nomlarni aniqlash (85% dan yuqori bo‘lsa, o‘xshash hisoblanadi)
    $matchedNames = [];
    foreach ($patients as $existing) {
        similar_text(mb_strtolower($name), mb_strtolower($existing), $percent);
        if ($percent >= 85) {
            $matchedNames[] = $existing;
        }
    }

    if (empty($matchedNames)) {
        echo json_encode([]);
        exit;
    }

    // 3. Tayyor so‘rov — tanlangan nomlar va sanalar oralig‘ida
    $placeholders = implode(',', array_fill(0, count($matchedNames), '?'));
    $sql = "
        SELECT DATE(p.created_at) AS date, s.name AS service_name 
        FROM patients p 
        JOIN patient_services ps ON p.id = ps.patient_id 
        JOIN services s ON ps.service_id = s.id 
        WHERE p.full_name IN ($placeholders)
          AND DATE(p.created_at) BETWEEN ? AND ?
        ORDER BY p.created_at DESC
    ";

    // Barcha matched name'lar va orqasidan start/end date
$params = array_merge($matchedNames, [$start_date, $end_date]);

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Sanalar bo‘yicha xizmatlarni guruhlash
    $grouped = [];
    foreach ($rows as $row) {
        $grouped[$row['date']][] = $row['service_name'];
    }

    // 5. Formatlab JSON javobga tayyorlash
    $result = [];
    foreach ($grouped as $date => $services) {
        $result[] = [
            'date' => $date,
            'services' => implode(', ', array_unique($services))
        ];
    }

    echo json_encode($result);
    exit;
}




$title = "Bemorlar Ko‘riklari";
ob_start();

$stmt = $conn->prepare("SELECT id, full_name, created_at FROM patients WHERE DATE(created_at) BETWEEN :start AND :end ORDER BY created_at");
$stmt->execute([
    'start' => $start_date,
    'end' => $end_date
]);
$allPatients = $stmt->fetchAll(PDO::FETCH_ASSOC);


$groups = [];

foreach ($allPatients as $p) {
    $matched = false;
    $created_date = date('d.m.Y', strtotime($p['created_at']));

    foreach ($groups as $standard => &$group) {
        similar_text(strtolower($p['full_name']), strtolower($standard), $percent);
        if ($percent > 85) {
            // Sana oldin bor bo‘lsa, qo‘shmaymiz
            if (!in_array($created_date, $group['dates'])) {
                $group['count']++;
                $group['dates'][] = $created_date;
            }
            $group['raw'][] = $p['full_name'];
            $matched = true;
            break;
        }
    }

    if (!$matched) {
        $groups[$p['full_name']] = [
            'count' => 1,
            'dates' => [$created_date],
            'raw' => [$p['full_name']]
        ];
    }
}


uasort($groups, function($a, $b) {
    return $b['count'] <=> $a['count'];
});

$labels = [];
$data = [];
$tooltips = [];

foreach (array_slice($groups, 0, 10) as $name => $info) {
    $labels[] = $name;
    $data[] = $info['count'];
    $tooltips[] = implode(", ", array_unique($info['dates']));
}

$content = ob_get_clean();
include '../includes/head.php';
?>

<div class="container my-5">
    <h1 class="mb-4">Eng Ko‘p Ko‘rikdan O‘tgan Bemorlar</h1>

<div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Sana oralig'ini tanlang</h6>
        </div>
        <div class="card-body">
            <form method="GET" class="form-inline">
                <div class="form-group mx-2">
                    <label for="start_date" class="mr-2">Boshlanish sanasi</label>
                    <input type="date" name="start_date" class="form-control" value="<?= htmlspecialchars($_GET['start_date'] ?? date('Y-m-01')) ?>">
                </div>
                <div class="form-group mx-2">
                    <label for="end_date" class="mr-2">Tugash sanasi</label>
                    <input type="date" name="end_date" class="form-control" value="<?= htmlspecialchars($_GET['end_date'] ?? date('Y-m-t')) ?>">
                </div>
                <button type="submit" class="btn btn-primary ml-2">
                    <i class="fas fa-filter"></i> Filtrlash
                </button>
            </form>
        </div>
    </div>
    <canvas id="visitChart" height="100"></canvas>
    <h2 class="mt-5">Top 50 Bemorlar Roʻyxati</h2>
    <div class="table-responsive">
        <table class="table table-bordered" id="patientTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Ism Familya</th>
                    <th>Necha marta</th>
                    <th>Ko‘rik sanalari</th>
                </tr>
            </thead>
            <tbody>
                <?php $index = 1; ?>
                <?php foreach (array_slice($groups, 0, 50) as $name => $info): ?>
                    <tr>
                        <td><?= $index++ ?></td>
                        <td><a href="#" class="view-details" data-name="<?= htmlspecialchars($name) ?>"><?= htmlspecialchars($name) ?></a></td>
                        <td><?= $info['count'] ?></td>
                        <td><?= implode(', ', array_unique($info['dates'])) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="modal fade" id="detailModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Bemor tafsilotlari</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="detailContent">Yuklanmoqda...</div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('visitChart').getContext('2d');
const visitChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($labels, JSON_UNESCAPED_UNICODE) ?>,
        datasets: [{
            label: 'Ko‘riklar soni',
            data: <?= json_encode($data) ?>,
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            tooltip: {
                callbacks: {
                    title: function(context) {
                        return context[0].label;
                    },
                    afterLabel: function(context) {
                        const tooltips = <?= json_encode($tooltips, JSON_UNESCAPED_UNICODE) ?>;
                        return '📅 Sanalar: ' + tooltips[context.dataIndex];
                    }
                }
            },
            legend: {
                display: false
            },
            title: {
                display: true,
                text: 'Eng ko‘p qayta ko‘rikda bo‘lgan bemorlar'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                stepSize: 1
            }
        }
    }
});

// AJAX orqali bemor xizmatlarini olish
const detailModal = new bootstrap.Modal(document.getElementById('detailModal'));
document.querySelectorAll('.view-details').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const name = this.dataset.name;
        const container = document.getElementById('detailContent');
        container.innerHTML = 'Yuklanmoqda...';
        detailModal.show();

        fetch(`?details=${encodeURIComponent(name)}&start_date=${encodeURIComponent('<?= $start_date ?>')}&end_date=${encodeURIComponent('<?= $end_date ?>')}`)
            .then(res => res.json())
            .then(data => {
                if (data.length === 0) {
                    container.innerHTML = '<div class="text-muted">Maʼlumot topilmadi</div>';
                    return;
                }
                let html = '<ul class="list-group">';
                data.forEach(item => {
                    html += `<li class="list-group-item">
                        <strong>${item.date}</strong> – ${item.services}
                    </li>`;
                });
                html += '</ul>';
                container.innerHTML = html;
            })
            .catch(err => {
                container.innerHTML = '<div class="text-danger">Xatolik yuz berdi!</div>';
            });
    });
});

</script>

<?php
include '../includes/body.php';
?>