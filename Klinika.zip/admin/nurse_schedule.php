<?php
//session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';

$title = "Hamshiralar Ish Jadvali";
ob_start();

// Hamshiraning telegram_id sini olish
function getNurseTelegramId($nurse_id, $conn) {
    try {
        $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = ?");
        $stmt->execute([$nurse_id]);
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return false;
    }
}

// Tasdiqlangan hamshiralar ro'yxati
function getConfirmedNurses($month, $conn) {
    $stmt = $conn->prepare("
        SELECT u.username, nc.confirmed_at 
        FROM nurse_confirmations nc
        JOIN users u ON nc.nurse_id = u.id
        WHERE nc.schedule_month = ?
        ORDER BY nc.confirmed_at DESC
    ");
    $stmt->execute([$month]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole();
if ($role !== 'rahbar') {
    die("Sizda bu sahifaga kirish uchun ruxsat yo'q!");
}

// Oyni aniqlash
$selected_month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$start_date = date('Y-m-01', strtotime($selected_month));
$end_date = date('Y-m-t', strtotime($selected_month));

// Hamshiralar ro'yxati
$nurse_ids = [10, 9, 12];
$placeholders = implode(',', array_fill(0, count($nurse_ids), '?'));
$stmt = $conn->prepare("SELECT id, username FROM users WHERE id IN ($placeholders)");
$stmt->execute($nurse_ids);
$nurses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Sana oralig'i va hafta kunlari
$dates = [];
$weekdays = [];
$current = strtotime($start_date);
$last = strtotime($end_date);

while ($current <= $last) {
    $date = date('Y-m-d', $current);
    $day_of_week = date('w', $current); // 0-Yakshanba, 1-Dushanba, ..., 6-Shanba
    $dates[] = $date;
    $weekdays[$date] = $day_of_week;
    $current = strtotime('+1 day', $current);
}

// POST so'rovni qayta ishlash (jadvalni saqlash)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['schedule'])) {
    try {
        $conn->beginTransaction();
        
        // Avvalgi yozuvlarni o'chirish
        $stmt = $conn->prepare("DELETE FROM nurse_schedule WHERE work_date BETWEEN :start AND :end");
        $stmt->execute(['start' => $start_date, 'end' => $end_date]);
        
        // Yangi yozuvlarni qo'shish
        $stmt = $conn->prepare("INSERT INTO nurse_schedule (nurse_id, work_date) VALUES (:nurse_id, :work_date)");
        
        foreach ($_POST['schedule'] as $nurse_id => $work_dates) {
            foreach ($work_dates as $date) {
                $stmt->execute(['nurse_id' => $nurse_id, 'work_date' => $date]);
            }
        }
        
        $conn->commit();
        $_SESSION['success'] = "Jadval muvaffaqiyatli saqlandi!";
        
        // Rasm hosil qilish va Telegramga yuborish
        $image_path = generateScheduleImage($selected_month, $conn);

        // Gruhga yuborish (inline tugmasiz)
        sendToTelegram($image_path, $selected_month, true);

        // Har bir hamshiraga shaxsiy chat orqali yuborish
        foreach ($nurses as $nurse) {
            $telegram_id = getNurseTelegramId($nurse['id'], $conn);
            
            if ($telegram_id) {
                sendToTelegram($image_path, $selected_month, false, $telegram_id);
            }
        }
        
    } catch (PDOException $e) {
        $conn->rollBack();
        $_SESSION['error'] = "Xatolik yuz berdi: " . $e->getMessage();
    }
    
    redirect($_SERVER['PHP_SELF'] . '?month=' . $selected_month);
}

// Avvalgi saqlangan jadvalni olish
$stmt = $conn->prepare("SELECT nurse_id, work_date FROM nurse_schedule WHERE work_date BETWEEN :start AND :end");
$stmt->execute(['start' => $start_date, 'end' => $end_date]);
$saved = $stmt->fetchAll(PDO::FETCH_ASSOC);

$saved_map = [];
foreach ($saved as $row) {
    $saved_map[$row['nurse_id']][$row['work_date']] = true;
}

// Rasm hosil qilish funksiyasi (mukammal jadval bilan)
function generateScheduleImage($month, $conn) {
    $start_date = date('Y-m-01', strtotime($month));
    $end_date = date('Y-m-t', strtotime($month));
    
    // Hamshiralar ro'yxati
    $nurses = [
        10 => 'Maxliyo',
        9 => 'Feruza',
        12 => 'Nilufar',
    ];
    
    // Jadvalni olish
    $stmt = $conn->prepare("SELECT nurse_id, work_date FROM nurse_schedule WHERE work_date BETWEEN :start AND :end");
    $stmt->execute(['start' => $start_date, 'end' => $end_date]);
    $schedule = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $map = [];
    foreach ($schedule as $row) {
        $map[$row['nurse_id']][] = $row['work_date'];
    }
    
    // O'zbekcha oy va kun nomlari
    $uzbek_months = [
        'January' => 'Yanvar', 'February' => 'Fevral', 'March' => 'Mart',
        'April' => 'Aprel', 'May' => 'May', 'June' => 'Iyun',
        'July' => 'Iyul', 'August' => 'Avgust', 'September' => 'Sentabr',
        'October' => 'Oktabr', 'November' => 'Noyabr', 'December' => 'Dekabr'
    ];
    
    $uzbek_days = [
        'Mon' => 'Du', 'Tue' => 'Se', 'Wed' => 'Ch', 
        'Thu' => 'Pa', 'Fri' => 'Ju', 'Sat' => 'Sh', 
        'Sun' => 'Ya'
    ];
    
    // Rasm parametrlari (kattalashtirilgan)
    $cell_width = 50;  // Kattalashtirildi
    $cell_height = 50; // Kattalashtirildi
    $header_height = 80;
    $left_margin = 150; // Kattalashtirildi
    $top_margin = 120;  // Kattalashtirildi
    
    $days_in_month = date('t', strtotime($month));
    $width = $left_margin + ($days_in_month * $cell_width) + 50;
    $height = $top_margin + (count($nurses) * $cell_height) + 120;
    
    $image = imagecreatetruecolor($width, $height);
    
    // Ranglar
    $white = imagecolorallocate($image, 255, 255, 255);
    $black = imagecolorallocate($image, 0, 0, 0);
    $blue = imagecolorallocate($image, 0, 100, 255);
    $green = imagecolorallocate($image, 0, 128, 0);
    $yellow = imagecolorallocate($image, 255, 255, 0);
    $light_gray = imagecolorallocate($image, 240, 240, 240);
    $dark_gray = imagecolorallocate($image, 100, 100, 100);
    $selected_cell = imagecolorallocate($image, 220, 255, 220);
    
    imagefill($image, 0, 0, $white);
    
    // Shrift yo'li
    $font_bold = __DIR__ . '/../fonts/OpenSans-Bold.ttf';
    $font_regular = __DIR__ . '/../fonts/OpenSans-Regular.ttf';
    
    // O'zbekcha oy nomi
    $month_name = date('F', strtotime($month));
    $uzbek_month = $uzbek_months[$month_name] ?? $month_name;
    
    // Sarlavha (kattalashtirilgan)
    imagettftext($image, 20, 0, $left_margin, 50, $black, $font_bold, "Happy Medline HAMSHIRALARI ISH JADVALI");
    imagettftext($image, 18, 0, $left_margin, 85, $blue, $font_bold, $uzbek_month . " " . date('Y', strtotime($month)));
    
    // Jadval chizish
    // 1. Kunlar ustuni
    $x = $left_margin;
    $y = $top_margin - 40;
    
    for ($day = 1; $day <= $days_in_month; $day++) {
        $current_date = date('Y-m-', strtotime($month)) . str_pad($day, 2, '0', STR_PAD_LEFT);
        $day_of_week = date('D', strtotime($current_date));
        $is_sunday = (date('w', strtotime($current_date)) == 0);
        $uzbek_day = $uzbek_days[$day_of_week] ?? $day_of_week;
        
        // Kun raqami (kattaroq)
        imagettftext($image, 12, 0, $x + 15, $y + 25, $is_sunday ? $black : $black, $font_bold, $day);
        
        // Hafta kuni qisqartmasi (O'zbekcha)
        imagettftext($image, 10, 0, $x + 15, $y + 45, $is_sunday ? $black : $dark_gray, $font_regular, $uzbek_day);
        
        $x += $cell_width;
    }
    
    // 2. Hamshiralar va belgilangan kunlar
    $row = 0;
    foreach ($nurses as $id => $name) {
        $x = $left_margin;
        $y = $top_margin + ($row * $cell_height);
        
         // Nechta + borligini sanash
        $count = 0; 
        
        // Hamshira ismi (kattaroq)
        imagettftext($image, 14, 0, 30, $y + 30, $blue, $font_bold, $name);
        
        // Jadval kataklari
        for ($day = 1; $day <= $days_in_month; $day++) {
            $current_date = date('Y-m-', strtotime($month)) . str_pad($day, 2, '0', STR_PAD_LEFT);
            $day_of_week = date('w', strtotime($current_date));
            $is_sunday = ($day_of_week == 0);
            $is_selected = isset($map[$id]) && in_array($current_date, $map[$id]);
            
            // Katak fon rangi
            $bg_color = $white;
            if ($is_sunday) {
                $bg_color = $yellow;
            }
            if ($is_selected) {
            $bg_color = $selected_cell;
            $count++; // + sanaladi
            }
            
            imagefilledrectangle($image, $x, $y, $x + $cell_width - 1, $y + $cell_height - 1, $bg_color);
            imagerectangle($image, $x, $y, $x + $cell_width - 1, $y + $cell_height - 1, $dark_gray);
            
            // Belgilangan kunlar uchun "+" belgisi (kattaroq)
            if ($is_selected) {
                imagettftext($image, 18, 0, $x + 20, $y + 35, $black, $font_bold, '+');
            }
            
            $x += $cell_width;
        }
           // Oxirgi ustunga ish kuni soni yoziladi
    imagettftext($image, 14, 0, $x + 10, $y + 30, $green, $font_bold, "$count kun");

        $row++;
    }
    
    // Legend (kattaroq)
    $legend_x = 50;
    $legend_y = $height - 80;
    
    // Belgilangan kun
    imagefilledrectangle($image, $legend_x, $legend_y, $legend_x + 25, $legend_y + 25, $selected_cell);
    imagerectangle($image, $legend_x, $legend_y, $legend_x + 25, $legend_y + 25, $dark_gray);
    imagettftext($image, 12, 0, $legend_x + 35, $legend_y + 20, $black, $font_regular, "Belgilangan ish kuni (+)");
    
    // Yakshanba
    $legend_x += 250;
    imagefilledrectangle($image, $legend_x, $legend_y, $legend_x + 25, $legend_y + 25, $yellow);
    imagerectangle($image, $legend_x, $legend_y, $legend_x + 25, $legend_y + 25, $dark_gray);
    imagettftext($image, 12, 0, $legend_x + 35, $legend_y + 20, $black, $font_regular, "Yakshanba kuni");
    
    // Footer
    $footer_text = "Ish vaqti 09:00-22:00ga qadar davom etadi. Hamshira tibbiy forma va bosh kiyimda bo'lishi shart!";
    imagettftext($image, 12, 0, $left_margin, $height - 30, $dark_gray, $font_regular, $footer_text);
    
    // Rasmni saqlash
    $image_dir = __DIR__ . '/../images/';
    if (!file_exists($image_dir)) {
        mkdir($image_dir, 0755, true);
    }
    
    $image_path = $image_dir . 'schedule_' . $month . '.jpg';
    imagejpeg($image, $image_path, 95);
    imagedestroy($image);
    
    return $image_path;
}

// Telegramga yuborish funksiyasi
function sendToTelegram($image_path, $month, $is_group = false, $chat_id = null) {
    $bot_token = '7615354316:AAHL0052GFJeVrV0lOFY6wdR1OJbVtHgcWI';
    $default_chat_id = '267601097'; // Admin chat
//    $default_chat_id = ['267601097', '5597814151', '-4638130851']; // Admin chat ID
//    $chat_id = ['267601097', '5320056345', '1717165462', '1686520390'];
       $chat_id = $is_group ? $default_chat_id : $chat_id;
    
    $uzbek_months = [
        'January' => 'Yanvar', 'February' => 'Fevral', 'March' => 'Mart',
        'April' => 'Aprel', 'May' => 'May', 'June' => 'Iyun',
        'July' => 'Iyul', 'August' => 'Avgust', 'September' => 'Sentabr',
        'October' => 'Oktabr', 'November' => 'Noyabr', 'December' => 'Dekabr'
    ];
    
    $month_name = date('F', strtotime($month));
    $uzbek_month = $uzbek_months[$month_name] ?? $month_name;
    
    $caption = "🏥 *Hamshiralar #ish_jadvali (" . $uzbek_month . " " . date('Y', strtotime($month)) . ")*\n\n";
    $caption .= "✅ *+* belgisi - belgilangan ish kuni\n";
    $caption .= "🔴 *Pushti kataklar* - yakshanba kunlari";
    
    // Rasmni yuborish
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot{$bot_token}/sendPhoto");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    
    $post_fields = [
        'chat_id' => $chat_id,
        'caption' => $caption,
        'photo' => new CURLFile($image_path),
        'parse_mode' => 'Markdown'
    ];
    
    // Agar guruhga yuborilayotgan bo'lsa, inline keyboard qo'shilmaysin
    if (!$is_group) {
        // Inline keyboard (faqat shaxsiy chatlar uchun)
        $keyboard = [
            'inline_keyboard' => [
                [
                    [
                        'text' => "✅ Tasdiqlash",
                        'callback_data' => 'confirm_schedule_' . $month
                    ]
                ]
            ]
        ];
        $post_fields['reply_markup'] = json_encode($keyboard);
    }
    
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}
?>

<!DOCTYPE html>
<html lang="uz">
<head>
    <?php include '../includes/head.php'; ?>
    <title><?= $title ?></title>
    <style>
        .schedule-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            padding: 25px;
            margin-bottom: 30px;
        }
        .schedule-header {
            background-color: #4e73df;
            color: white;
            padding: 15px;
            border-radius: 5px 5px 0 0;
            margin-bottom: 20px;
        }
        .schedule-table {
            width: 100%;
            overflow-x: auto;
            display: block;
        }
        .schedule-table table {
            min-width: 1500px;
        }
        .schedule-table th {
            white-space: nowrap;
            text-align: center;
            background-color: #f8f9fa;
            position: sticky;
            top: 0;
            padding: 10px 5px;
        }
        .schedule-table td {
            text-align: center;
            vertical-align: middle;
            padding: 12px 5px;
        }
        .nurse-name {
            font-weight: bold;
            white-space: nowrap;
            background-color: #f0f8ff;
            position: sticky;
            left: 0;
        }
        .sunday {
            background-color: #fff0f0;
        }
        .sunday-header {
            background-color: #f8d7da;
            color: #d9534f;
        }
        .selected-day {
            background-color: #d4edda !important;
        }
        .form-check-input {
            width: 20px;
            height: 20px;
        }
        .month-selector {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .legend {
            display: flex;
            gap: 20px;
            margin-top: 15px;
        }
        .legend-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .legend-color {
            width: 20px;
            height: 20px;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="schedule-header">
                    <h1 class="h3 mb-0 text-white"><?= $title ?></h1>
                </div>
                
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= $_SESSION['success'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['success']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?= $_SESSION['error'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>
                
                <div class="month-selector">
                    <form method="get" class="row g-3 align-items-center">
                        <div class="col-md-4">
                            <label for="month" class="form-label">Oy tanlang:</label>
                            <input type="month" class="form-control" id="month" name="month" value="<?= $selected_month ?>">
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search"></i> Ko'rish
                            </button>
                        </div>
                        <div class="col-md-6 text-end">
                            <a href="<?= generateScheduleImage($selected_month, $conn) ?>" 
                               class="btn btn-success" 
                               download="hamshiralar_jadvali_<?= $selected_month ?>.jpg">
                                <i class="fas fa-download"></i> Rasmni Yuklab Olish
                            </a>
                        </div>
                    </form>
                </div>
                
                <div class="schedule-container">
                    <form method="post">
                        <input type="hidden" name="month" value="<?= $selected_month ?>">
                        
                        <div class="legend">
                            <div class="legend-item">
                                <div class="legend-color" style="background-color: #d4edda;"></div>
                                <span>Belgilangan ish kuni</span>
                            </div>
                            <div class="legend-item">
                                <div class="legend-color" style="background-color: #fff0f0;"></div>
                                <span>Yakshanba kuni</span>
                            </div>
                        </div>
                        
                        <div class="table-responsive schedule-table">
                            <table class="table table-bordered table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Hamshira</th>
                                        <?php foreach ($dates as $date): 
                                            $is_sunday = ($weekdays[$date] == 0);
                                            $th_class = $is_sunday ? 'sunday-header' : '';
                                        ?>
                                            <th class="<?= $th_class ?>">
                                                <?= date('d', strtotime($date)) ?><br>
                                                <small><?= date('D', strtotime($date)) ?></small>
                                            </th>
                                        <?php endforeach; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($nurses as $nurse): ?>
                                    <tr>
                                        <td class="nurse-name"><?= htmlspecialchars($nurse['username']) ?></td>
                                        <?php foreach ($dates as $date): 
                                            $is_sunday = ($weekdays[$date] == 0);
                                            $is_selected = isset($saved_map[$nurse['id']][$date]);
                                            $td_class = $is_sunday ? 'sunday' : '';
                                            $td_class .= $is_selected ? ' selected-day' : '';
                                        ?>
                                        <td class="<?= $td_class ?>">
                                            <div class="form-check d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" 
                                                       name="schedule[<?= $nurse['id'] ?>][]" 
                                                       value="<?= $date ?>"
                                                       <?= $is_selected ? 'checked' : '' ?>
                                                       style="transform: scale(1.3);">
                                            </div>
                                        </td>
                                        <?php endforeach; ?>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Jadvalni Saqlash va Telegramga Yuborish
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <?php include '../includes/body.php'; ?>
    
    <script>
        // Yakshanba kunlarini va belgilangan kunlarni ajratib ko'rsatish
        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('input[type="checkbox"]');
            
            checkboxes.forEach(checkbox => {
                const dateStr = checkbox.value;
                const date = new Date(dateStr);
                const isSunday = date.getDay() === 0; // 0 = Sunday
                const td = checkbox.closest('td');
                
                if (isSunday) {
                    td.classList.add('sunday');
                }
                
                if (checkbox.checked) {
                    td.classList.add('selected-day');
                }
                
                // Checkbox o'zgarishlarini kuzatish
                checkbox.addEventListener('change', function() {
                    if (this.checked) {
                        td.classList.add('selected-day');
                    } else {
                        td.classList.remove('selected-day');
                    }
                });
            });
        });
    </script>
</body>
</html>