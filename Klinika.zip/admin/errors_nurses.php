<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

//session_start();

// Hamshira kollektiv IDs
$nurse_collective_ids = [4, 9, 10];

if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole();
if ($role !== 'rahbar') {
    die("Sizda bu sahifaga kirish uchun ruxsat yo'q!");
}

// Staff xatosini saqlash va Telegramga xabar yuborish
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['staff_id']) && !empty($_POST['error_type'])) {
        $staff_id = (int)$_POST['staff_id'];
        $error_type = trim($_POST['error_type']);

        // Staff ma'lumotlarini olish
        $stmt = $conn->prepare("SELECT id, username, role, telegram_id FROM users WHERE id = ?");
        $stmt->execute([$staff_id]);
        $staff = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($staff) {
            $staff_name = $staff['username'];
            $staff_type = strtolower($staff['role']);
            $telegram_id = $staff['telegram_id'];

            // Xatolikni staff_errors jadvaliga yozish
            $stmt = $conn->prepare("INSERT INTO staff_errors (staff_type, staff_name, error_type, created_at) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$staff_type, $staff_name, $error_type]);

            // Xabar matni
            $message = "🚨 <b>#Xatolik aniqlandi</b>\n\n👤 Xodim: <b>{$staff_name}</b>\n❗ Xatolik turi: <b>{$error_type}</b>\n🕒 Sana: <b>" . date('d.m.Y H:i') . "</b>";

            // Xabarni kimlarga yuborish kerak?
            if ($staff_type === 'hamshira') {
                if (in_array($staff_id, $nurse_collective_ids)) {
                    
                    // 4,9,10 hamshiralar — barcha 4,9,10 id egalarga yuboriladi
                    $stmt_nurses = $conn->query("SELECT telegram_id FROM users WHERE id IN (4,9,10) AND telegram_id IS NOT NULL");
                    $nurses = $stmt_nurses->fetchAll(PDO::FETCH_ASSOC);

                    foreach ($nurses as $nurse) {
                        sendTelegramMessage($nurse['telegram_id'], $message);
                    }
                } else {
                    // Boshqa hamshiralar — faqat o'ziga yuboriladi
                    if (!empty($telegram_id)) {
                        sendTelegramMessage($telegram_id, $message);
                    }
                }
            } elseif ($staff_type === 'kassir') {
                // Kassir xato qilsa — barcha kassirlarga yuboriladi
                $stmt_cashiers = $conn->query("SELECT telegram_id FROM users WHERE role = 'kassir' AND telegram_id IS NOT NULL");
                $cashiers = $stmt_cashiers->fetchAll(PDO::FETCH_ASSOC);

                foreach ($cashiers as $cashier) {
                    sendTelegramMessage($cashier['telegram_id'], $message);
                }
            }

            $_SESSION['success'] = "Xatolik muvaffaqiyatli qo'shildi va xabar yuborildi!";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        } else {
            $_SESSION['error'] = "Xodim topilmadi.";
        }
    } else {
        $_SESSION['error'] = "Ma'lumotlar to'liq emas.";
    }
}

// Oxirgi 10 ta xatolikni olish
// Kodda SQL so‘rovini shunday o'zgartiring:
$sql = "
    SELECT se.*, u.id as user_id 
    FROM staff_errors se
    LEFT JOIN users u ON se.staff_name COLLATE utf8_general_ci = u.username COLLATE utf8_general_ci
    ORDER BY se.created_at DESC 
    LIMIT 10
";
$stmt = $conn->query($sql);
$recent_errors = $stmt->fetchAll(PDO::FETCH_ASSOC);



// Staff ro'yxatini olish
$staff_list = $conn->query("SELECT id, username, role FROM users WHERE role IN ('hamshira', 'kassir') ORDER BY username")->fetchAll();
$title = "Xatoliklarini Qo'shish";
require_once '../includes/head.php';
?>
<style>
    h2 {
        color: #4e73df;
        margin-bottom: 20px;
    }
    .form-group {
        margin-bottom: 15px;
    }
    .form-group label {
        display: block;
        margin-bottom: 5px;
    }
    .form-control {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    .btn {
        background: #1cc88a;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .btn:hover {
        background: #17a673;
    }
    .alert {
        padding: 10px;
        margin-bottom: 20px;
        border-radius: 5px;
    }
    .alert-success {
        background: #d4edda;
        color: #155724;
    }
    .alert-error {
        background: #f8d7da;
        color: #721c24;
    }
    .error-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 30px;
    }
    .error-table th, .error-table td {
        padding: 12px 15px;
        border: 1px solid #ddd;
        text-align: left;
    }
    .error-table th {
        background-color: #4e73df;
        color: white;
    }
    .error-table tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    .error-table tr:hover {
        background-color: #e9ecef;
    }
    .section-title {
        margin-top: 40px;
        padding-bottom: 10px;
        border-bottom: 2px solid #4e73df;
    }
</style>
<div class="container">
    <h2>Xodimlar Xatoliklarini Qo'shish <a href="manage_nurses.php" class="btn btn-warning">Ulushlarni o'zgartirish</a></h2>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?= $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error">
            <?= $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>

    <form method="POST" id="errorForm">
        <div class="form-group">
            <label for="staff_id">Xodimni tanlang:</label>
            <select name="staff_id" id="staff_id" class="form-control" required>
                <option value="">-- Tanlang --</option>
                <?php foreach ($staff_list as $staff): ?>
                    <option value="<?= $staff['id'] ?>">[<?= ucfirst($staff['role']) ?>] <?= htmlspecialchars($staff['username']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="error_type">Xatolik turi:</label>
            <input type="text" name="error_type" id="error_type" class="form-control" placeholder="Masalan: Ishga kech keldi" required>
        </div>

        <button type="submit" class="btn">Xatolikni Qo'shish</button>
    </form>
<h3 class="section-title">Oxirgi 10 ta xatolik</h3>
    
    <table class="error-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Xodim</th>
                <th>Lavozim</th>
                <th>Xatolik turi</th>
                <th>Sana</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($recent_errors)): ?>
                <?php foreach ($recent_errors as $index => $error): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td>
                            <?php if ($error['user_id']): ?>
                            <b>
                                    <?= htmlspecialchars($error['staff_name']) ?>
                            </b>
                            <?php else: ?>
                                <?= htmlspecialchars($error['staff_name']) ?>
                            <?php endif; ?>
                        </td>
                        <td><?= ucfirst($error['staff_type']) ?></td>
                        <td><?= htmlspecialchars($error['error_type']) ?></td>
                        <td><?= date('d.m.Y H:i', strtotime($error['created_at'])) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align: center;">Xatoliklar topilmadi</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
// Formni yuborishda inputlarni tekshirish (optional)
const form = document.getElementById('errorForm');
form.addEventListener('submit', function(event) {
    const staffSelect = document.getElementById('staff_id');
    const errorInput = document.getElementById('error_type');

    if (!staffSelect.value || !errorInput.value.trim()) {
        event.preventDefault();
        alert('Iltimos, barcha maydonlarni to'ldiring.');
    }
});
</script>
<?php
require_once '../includes/body.php';
?>