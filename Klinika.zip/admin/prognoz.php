<?php
// prognoz.php - Yakuniy tuzatilgan versiya
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 1. Majburiy o'zgaruvchilarni tekshirish va ishonchlilik
$required_vars = [
    'is_filtered' => false,
    'start_date' => date('Y-m-01'),
    'end_date' => date('Y-m-t'),
    'period_stats' => ['total_income' => 0],
    'daily_stats' => [],
    'total_doctor_income' => 0,
    'total_nurse_income' => 0,
    'total_expenses' => 0,
    'all_staff' => [],
    'conn' => null
];

foreach ($required_vars as $var => $default) {
    if (!isset($$var)) {
        $$var = is_array($default) ? (array)$default : $default;
        error_log("Ogohlantirish: $var o'zgaruvchisi aniqlanmagan, standart qiymat o'rnatildi");
    }
}

// 2. Agar filtr qo'llanilgan bo'lsa, prognozni ko'rsatmaslik
if ($is_filtered) {
    echo '<div class="alert alert-info">Prognoz faqat filtrsiz rejimda ko\'rsatiladi</div>';
    return; // yoki exit;
}

// 3. Ma'lumotlar bazasi ulanishini tekshirish
if (!$conn || !($conn instanceof PDO)) {
    die("<div class='alert alert-danger'>Xato: Ma'lumotlar bazasiga ulanmadi</div>");
}

// 4. Faqat joriy oy uchun prognoz ko'rsatish
$is_current_month = (date('Y-m') == date('Y-m', strtotime($start_date)));
if (!$is_current_month) {
    echo '<div class="alert alert-info">Prognoz faqat joriy oy uchun ko\'rsatiladi</div>';
    return;
}

try {
    // 5. Yakshanba statistikasi
    $sunday_stats = calculateSundayStats($conn);
    $avg_sunday_income = $sunday_stats['avg_income'];
    $avg_sunday_staff = $sunday_stats['avg_staff'];

    // 6. Ish kuni statistikasi
    $weekday_stats = calculateWeekdayStats($conn, $start_date, $end_date);
    $avg_weekday_income = $weekday_stats['avg_income'];
    $avg_weekday_staff = $weekday_stats['avg_staff'];

    // 7. Prognoz hisoblash
    $projection = calculateProjections(
        $period_stats,
        $total_doctor_income,
        $total_nurse_income,
        $total_expenses,
        $daily_stats,
        $avg_weekday_income,
        $avg_weekday_staff,
        $avg_sunday_income,
        $avg_sunday_staff
    );

    // 8. Xodimlar prognozi
    $staff_projection = calculateStaffProjections($all_staff, $daily_stats, $projection['remaining_days']);

    // 9. HTML chiqishlarni ko'rsatish
    displayProjectionResults(
        $projection,
        $period_stats, // $period_stats ni ham uzatamiz
        $avg_sunday_income,
        $avg_sunday_staff,
        $avg_weekday_income,
        $avg_weekday_staff
    );

    // 10. Diagramma uchun ma'lumotlar
    displayChart($conn, $daily_stats, $avg_weekday_income, $avg_weekday_staff, $avg_sunday_income, $avg_sunday_staff);

} catch (PDOException $e) {
    echo "<div class='alert alert-danger'>Ma'lumotlar bazasi xatosi: " . htmlspecialchars($e->getMessage()) . "</div>";
} catch (Exception $e) {
    echo "<div class='alert alert-warning'>Xato: " . htmlspecialchars($e->getMessage()) . "</div>";
}

// FUNKSIYALAR //

function calculateSundayStats($conn) {
    $stats = ['avg_income' => 0, 'avg_staff' => 0];
    
    $query = "SELECT DATE(created_at) as sunday_date,
              SUM(price) as total_income,
              SUM(doctor_income + nurse_income) as staff_payment
              FROM patients
              WHERE WEEKDAY(created_at) = 6 
              AND DATE(created_at) BETWEEN DATE_SUB(CURDATE(), INTERVAL 3 MONTH) AND CURDATE()
              GROUP BY DATE(created_at)";
    
    $stmt = $conn->query($query);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($results) > 0) {
        $stats['avg_income'] = array_sum(array_column($results, 'total_income')) / count($results);
        $stats['avg_staff'] = array_sum(array_column($results, 'staff_payment')) / count($results);
    }
    
    return $stats;
}

function calculateWeekdayStats($conn, $start_date, $end_date) {
    $stats = ['avg_income' => 0, 'avg_staff' => 0];
    
    $query = "SELECT AVG(daily_income) as avg_income, AVG(daily_staff) as avg_staff
              FROM (
                  SELECT DATE(created_at) as day, 
                  SUM(price) as daily_income,
                  SUM(doctor_income + nurse_income) as daily_staff
                  FROM patients
                  WHERE WEEKDAY(created_at) != 6
                  AND DATE(created_at) BETWEEN :start_date AND :end_date
                  GROUP BY DATE(created_at)
              ) as weekdays";
    
    $stmt = $conn->prepare($query);
    $stmt->execute(['start_date' => $start_date, 'end_date' => $end_date]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $stats['avg_income'] = $data['avg_income'] ?? 0;
    $stats['avg_staff'] = $data['avg_staff'] ?? 0;
    
    return $stats;
}

function calculateProjections($period_stats, $total_doctor, $total_nurse, $total_expenses, $daily_stats, $avg_weekday_income, $avg_weekday_staff, $avg_sunday_income, $avg_sunday_staff) {
    $result = [];
    
    // Qolgan kunlar hisobi
    $current_date = new DateTime();
    $end_of_month = new DateTime('last day of this month');
    $result['remaining_days'] = 0;
    $result['remaining_sundays'] = 0;
    
    while ($current_date <= $end_of_month) {
        $result['remaining_days']++;
        if ((int)$current_date->format('w') === 0) {
            $result['remaining_sundays']++;
        }
        $current_date->modify('+1 day');
    }
    
    // Prognoz hisoblash
    $result['projected_weekday_income'] = $avg_weekday_income * ($result['remaining_days'] - $result['remaining_sundays']);
    $result['projected_sunday_income'] = $avg_sunday_income * $result['remaining_sundays'];
    $result['total_projected_income'] = ($period_stats['total_income'] ?? 0) + $result['projected_weekday_income'] + $result['projected_sunday_income'];
    
    $result['projected_weekday_staff'] = $avg_weekday_staff * ($result['remaining_days'] - $result['remaining_sundays']);
    $result['projected_sunday_staff'] = $avg_sunday_staff * $result['remaining_sundays'];
    $result['total_projected_staff'] = ($total_doctor + $total_nurse) + $result['projected_weekday_staff'] + $result['projected_sunday_staff'];
    
    $avg_daily_expenses = count($daily_stats) > 0 ? $total_expenses / count($daily_stats) : 0;
    $result['total_projected_expenses'] = $total_expenses + ($avg_daily_expenses * $result['remaining_days']);
    
    $result['total_projected_profit'] = $result['total_projected_income'] - $result['total_projected_staff'] - $result['total_projected_expenses'];
    
    return $result;
}

function calculateStaffProjections($all_staff, $daily_stats, $remaining_days) {
    $projections = [];
    $days_count = count($daily_stats);
    
    foreach ($all_staff as $staff) {
        $daily_avg = $days_count > 0 ? $staff['income'] / $days_count : 0;
        $projections[] = [
            'name' => $staff['xodim'] ?? 'Noma\'lum',
            'position' => $staff['position'] ?? '',
            'current' => $staff['income'] ?? 0,
            'projected' => ($staff['income'] ?? 0) + ($daily_avg * $remaining_days),
            'percentage' => $staff['percentage'] ?? 0
        ];
    }
    
    return $projections;
}

function displayProjectionResults($projection, $period_stats, $avg_sunday_income, $avg_sunday_staff, $avg_weekday_income, $avg_weekday_staff) {
    $total_income = $period_stats['total_income'] ?? 0;
    ?>
    <!-- Joriy Oy Prognozi -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-primary text-white">
            <h6 class="m-0 font-weight-bold"><?= date('F Y') ?> Oyining Prognozi</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="card border-left-success h-100">
                        <div class="card-body">
                            <h5 class="card-title">Jami Kutilayotgan Tushum</h5>
                            <p class="h4"><?= number_format($projection['total_projected_income'], 0, ',', ' ') ?> so'm</p>
                            <div class="progress mt-2" style="height: 10px;">
                                <div class="progress-bar bg-success" role="progressbar" 
                                     style="width: <?php
$max = $projection['total_projected_income'] ?? 0;
$percent = ($max > 0) ? min(100, ($total_income / $max) * 100) : 0;
?>

<div class="progress-bar" 
     style="width: <?= $percent ?>%;" 
     aria-valuenow="<?= $total_income ?>" 
     aria-valuemax="<?= $max ?>">

                                </div>
                            </div>
                            <small class="text-muted">
                                <?= number_format($total_income, 0, ',', ' ') ?> so'm allaqachon yig'ilgan
                            </small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-left-info h-100">
                        <div class="card-body">
                            <h5 class="card-title">Qolgan Ish Kunlari</h5>
                            <p class="h4"><?= $projection['remaining_days'] ?> kun</p>
                            <small class="text-muted">
                                <?= $projection['remaining_sundays'] ?> ta yakshanba<br>
                                <?= ($projection['remaining_days'] - $projection['remaining_sundays']) ?> ta ish kuni
                            </small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-left-warning h-100">
                        <div class="card-body">
                            <h5 class="card-title">Kutilayotgan Sof Foyda</h5>
                            <p class="h4"><?= number_format($projection['total_projected_profit'], 0, ',', ' ') ?> so'm</p>
                            <small class="text-muted">
                                Tushum: <?= number_format($projection['total_projected_income'], 0, ',', ' ') ?> so'm<br>
                                Xodimlar: <?= number_format($projection['total_projected_staff'], 0, ',', ' ') ?> so'm<br>
                                Chiqimlar: <?= number_format($projection['total_projected_expenses'], 0, ',', ' ') ?> so'm
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}

function displayChart($conn, $daily_stats, $avg_weekday_income, $avg_weekday_staff, $avg_sunday_income, $avg_sunday_staff) {
    ?>
    <!-- Kunlik Tendentsiyalar -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Kunlik Tushum Prognozi</h6>
            <small class="text-muted">
                Yakshanba: <?= number_format($avg_sunday_income, 0, ',', ' ') ?> so'm<br>
                Ish kuni: <?= number_format($avg_weekday_income, 0, ',', ' ') ?> so'm
            </small>
        </div>
        <div class="card-body">
            <div class="chart-area" style="height: 450px;">
                <canvas id="dailyTrendChart"></canvas>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('dailyTrendChart').getContext('2d');
        const labels = [];
        const actualIncome = [];
        const projectedIncome = [];

        // O'tgan kunlar
        <?php foreach ($daily_stats as $day): ?>
        labels.push('<?= date("d.m", strtotime($day['day'])) ?>');
        actualIncome.push(<?= $day['daily_income'] ?? 0 ?>);
        projectedIncome.push(null);
        <?php endforeach; ?>

        // Qolgan kunlar
        let date = new Date();
        date.setDate(date.getDate() + 1);
        const today = new Date();
        const currentMonth = today.getMonth();

        while (date.getMonth() === currentMonth) {
            const d = ('0' + date.getDate()).slice(-2);
            const m = ('0' + (date.getMonth() + 1)).slice(-2);
            labels.push(`${d}.${m}`);

            const isSunday = date.getDay() === 0;
            projectedIncome.push(isSunday ? <?= $avg_sunday_income ?> : <?= $avg_weekday_income ?>);
            actualIncome.push(null);

            date.setDate(date.getDate() + 1);
        }

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Haqiqiy tushum',
                        data: actualIncome,
                        borderColor: '#4e73df',
                        backgroundColor: 'rgba(78, 115, 223, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.3
                    },
                    {
                        label: 'Prognoz tushum',
                        data: projectedIncome,
                        borderColor: '#1cc88a',
                        backgroundColor: 'rgba(28, 200, 138, 0.1)',
                        borderWidth: 2,
                        borderDash: [4, 4],
                        fill: false,
                        tension: 0.3
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: { display: true, text: "Summa (so'm)" }
                    },
                    x: {
                        title: { display: true, text: 'Kunlar' },
                        grid: { display: false }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + (context.raw || 0).toLocaleString('uz') + ' so\'m';
                            }
                        }
                    },
                    legend: {
                        position: 'bottom',
                        labels: { boxWidth: 12 }
                    }
                }
            }
        });
    });
    </script>
    <?php
}
?>