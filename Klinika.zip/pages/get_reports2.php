<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Foydalanuvchi tizimga kirganligini tekshirish
if (!isLoggedIn()) {
    die("Kirish mumkin emas!");
}

$role = getUserRole(); // Foydalanuvchi roli
$user_id = $_SESSION['user']['id']; // Foydalanuvchi ID si

// Faqat shifokor va hamshira uchun ruxsat
if (!in_array($role, ['shifokor', 'hamshira'])) {
    die("Sizda ushbu sahifaga kirish uchun ruxsat yo'q!");
}

// AJAX so'rovidan kelgan ma'lumotlarni olish
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];

// Tanlangan davr uchun bemorlar ro'yxati
$query = "SELECT 
            p.id,
            p.full_name AS bemor_ismi,
            s.name AS xizmat_nomi,
            p.price AS narxi,
            p.created_at AS qabul_vaqti
          FROM patients p
          LEFT JOIN services s ON p.service_id = s.id
          WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
          AND (p.doctor_id = :user_id OR p.nurse_id = :user_id)";
$stmt = $conn->prepare($query);
$stmt->execute([
    'start_date' => $start_date,
    'end_date' => $end_date,
    'user_id' => $user_id
]);
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

// JSON formatida javob qaytarish
echo json_encode($reports);
?>