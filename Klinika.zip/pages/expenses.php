<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Session muddatini 1 oygacha uzaytiramiz
//$sessionLifetime = 30 * 24 * 60 * 60; // 30 kun
//session_set_cookie_params($sessionLifetime);
//ini_set('session.gc_maxlifetime', $sessionLifetime);

if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole();
if ($role !== 'kassir' && $role !== 'rahbar') {
    die("Sizda ruxsat yo'q!");
}

$title = "Chiqimlar Boshqaruvi";
ob_start();

$message = "";
$expenses = [];
$totalExpenses = 0;
$expensesByType = [];

// Chiqim qo'shish
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_expense'])) {
    $amount = floatval($_POST['amount']);
    $type = trim($_POST['type']);
    $comment = trim($_POST['comment']);

    if (empty($amount) || empty($type)) {
        $message = "Iltimos, barcha maydonlarni to'ldiring!";
    } else {
        try {
            $stmt = $conn->prepare("INSERT INTO expenses (amount, type, comment, created_by, created_at) VALUES (:amount, :type, :comment, :created_by, NOW())");
            $stmt->execute([
                'amount' => $amount,
                'type' => $type,
                'comment' => $comment,
                'created_by' => $_SESSION['user']['id']
            ]);
            $message = "Chiqim muvaffaqiyatli qo'shildi!";
        } catch (Exception $e) {
            $message = "Xatolik yuz berdi: " . $e->getMessage();
        }
    }
}

// Kunlik chiqimlar (kassir uchun)
if ($role === 'kassir') {
    $stmt = $conn->prepare("
        SELECT e.*, u.username AS created_by_name 
        FROM expenses e 
        LEFT JOIN users u ON e.created_by = u.id 
        WHERE DATE(e.created_at) = CURDATE() 
        ORDER BY e.created_at DESC
    ");
    $stmt->execute();
    $expenses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Jami chiqimlar
    $totalExpenses = array_sum(array_column($expenses, 'amount'));

    // Chiqimlar turi bo'yicha
    $expensesByType = array_reduce($expenses, function ($carry, $item) {
        $carry[$item['type']] = ($carry[$item['type']] ?? 0) + $item['amount'];
        return $carry;
    }, []);
}

// Oylik chiqimlar (rahbar uchun)
if ($role === 'rahbar' && (isset($_GET['month']) || isset($_GET['year']))) {
    $month = $_GET['month'] ?? date('m');
    $year = $_GET['year'] ?? date('Y');

    $stmt = $conn->prepare("
        SELECT e.*, u.username AS created_by_name 
        FROM expenses e 
        LEFT JOIN users u ON e.created_by = u.id 
        WHERE MONTH(e.created_at) = :month AND YEAR(e.created_at) = :year 
        ORDER BY e.created_at DESC
    ");
    $stmt->execute(['month' => $month, 'year' => $year]);
    $expenses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Jami chiqimlar
    $totalExpenses = array_sum(array_column($expenses, 'amount'));

    // Chiqimlar turi bo'yicha
    $expensesByType = array_reduce($expenses, function ($carry, $item) {
        $carry[$item['type']] = ($carry[$item['type']] ?? 0) + $item['amount'];
        return $carry;
    }, []);
}

$content = ob_get_clean();
include '../includes/head.php';
?>

<div class="container mt-4 mb-5">
<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12">
            <div class="page-header d-flex justify-content-between align-items-center">
                <h1 class="mb-0">
                    <i class="bi bi-cash-stack me-2"></i><?= $title ?>
                </h1>
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left"></i> Orqaga
                </a>
            </div>
            
            <?php if ($message): ?>
                <div class="alert alert-dismissible fade show alert-<?= strpos($message, 'muvaffaqiyatli') !== false ? 'success' : 'danger' ?>">
                    <?= htmlspecialchars($message) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-4 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-plus-circle"></i> Yangi Chiqim</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label for="amount" class="form-label">Summa</label>
                            <div class="input-group">
                                <input type="number" class="form-control" id="amount" name="amount" step="1000" required>
                                <span class="input-group-text">so'm</span>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="type" class="form-label">Chiqim turi</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="Kons Tovar">Kons Tovar</option>
                                <option value="Xoz Tovar">Xoz Tovar</option>
                                <option value="Dorilar">Dorilar</option>
                                <option value="Boshqa">Boshqa</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="comment" class="form-label">Izoh</label>
                            <textarea class="form-control" id="comment" name="comment" rows="2"></textarea>
                        </div>
                        
                        <button type="submit" name="add_expense" class="btn btn-primary w-100">
                            <i class="bi bi-save"></i> Saqlash
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-bar-chart"></i> Hisobotlar</h5>
                </div>
                <div class="card-body">
                    <?php if ($role === 'kassir'): ?>
                        <div class="alert alert-success">
                            <h5><i class="bi bi-calendar-day"></i> Kunlik hisobot</h5>
                            <div class="d-flex justify-content-between align-items-center">
                                <span>Jami chiqim:</span>
                                <strong><?= number_format($totalExpenses, 0) ?> so'm</strong>
                            </div>
                        </div>
                        
                        <?php if (!empty($expensesByType)): ?>
                            <div class="row">
                                <?php foreach ($expensesByType as $type => $amount): ?>
                                    <div class="col-md-6 mb-3">
                                        <div class="card bg-light">
                                            <div class="card-body p-3">
                                                <div class="d-flex justify-content-between">
                                                    <span><?= $type ?></span>
                                                    <strong><?= number_format($amount, 0) ?> so'm</strong>
                                                </div>
                                                <div class="progress mt-2" style="height: 5px;">
                                                    <div class="progress-bar" 
                                                         role="progressbar" 
                                                         style="width: <?= $totalExpenses > 0 ? ($amount/$totalExpenses)*100 : 0 ?>%" 
                                                         aria-valuenow="<?= $amount ?>" 
                                                         aria-valuemin="0" 
                                                         aria-valuemax="<?= $totalExpenses ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if ($role === 'rahbar'): ?>
                        <form id="monthlyReportForm" class="mb-4">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="month" class="form-label">Oy</label>
                                    <select id="month" name="month" class="form-select">
                                        <?php for ($i = 1; $i <= 12; $i++): ?>
                                            <option value="<?= sprintf('%02d', $i) ?>" <?= ($i == date('m')) ? 'selected' : '' ?>>
                                                <?= date('F', mktime(0, 0, 0, $i, 10)) ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="year" class="form-label">Yil</label>
                                    <input type="number" id="year" name="year" class="form-control" value="<?= date('Y') ?>">
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-filter"></i> Hisobotni ko'rsatish
                                    </button>
                                </div>
                            </div>
                        </form>

                        <?php if (!empty($expenses)): ?>
                            <div class="alert alert-success">
                                <h5><i class="bi bi-calendar-month"></i> Oylik hisobot (<?= date('F Y', mktime(0, 0, 0, $month, 1, $year)) ?>)</h5>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span>Jami chiqim:</span>
                                    <strong><?= number_format($totalExpenses, 2) ?> so'm</strong>
                                </div>
                            </div>
                            
                            <?php if (!empty($expensesByType)): ?>
                                <div class="row">
                                    <?php foreach ($expensesByType as $type => $amount): ?>
                                        <div class="col-md-6 mb-3">
                                            <div class="card bg-light">
                                                <div class="card-body p-3">
                                                    <div class="d-flex justify-content-between">
                                                        <span><?= $type ?></span>
                                                        <strong><?= number_format($amount, 0) ?> so'm</strong>
                                                    </div>
                                                    <div class="progress mt-2" style="height: 5px;">
                                                        <div class="progress-bar" 
                                                             role="progressbar" 
                                                             style="width: <?= $totalExpenses > 0 ? ($amount/$totalExpenses)*100 : 0 ?>%" 
                                                             aria-valuenow="<?= $amount ?>" 
                                                             aria-valuemin="0" 
                                                             aria-valuemax="<?= $totalExpenses ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-list"></i> Chiqimlar ro'yxati</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Summa</th>
                                    <th>Turi</th>
                                    <th>Izoh</th>
                                    <th>Qo'shgan</th>
                                    <th>Sana</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($expenses)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4 text-muted">
                                            <i class="bi bi-exclamation-circle fs-1"></i>
                                            <p class="mt-2">Chiqimlar topilmadi</p>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($expenses as $index => $expense): ?>
                                        <tr>
                                            <td><?= $index + 1 ?></td>
                                            <td class="fw-bold"><?= number_format($expense['amount'], 0) ?> so'm</td>
                                            <?php
$type = htmlspecialchars($expense['type']);
$typeColors = [
    'Dorilar' => 'bg-danger',
    'Kons Tovar' => 'bg-success',
    'Xoz Tovar' => 'bg-warning text-dark',
    'Boshqa' => 'bg-secondary'
];
$badgeColor = $typeColors[$type] ?? 'bg-primary';
?>
<td><span class="badge <?= $badgeColor ?>"><?= $type ?></span></td>

                                            <td><?= !empty($expense['comment']) ? htmlspecialchars($expense['comment']) : '-' ?></td>
                                            <td><?= htmlspecialchars($expense['created_by_name']) ?></td>
                                            <td><?= date('d.m.Y H:i', strtotime($expense['created_at'])) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<script>
    // Oylik hisobot formasi
    document.getElementById('monthlyReportForm')?.addEventListener('submit', function(e) {
        e.preventDefault();
        const month = document.getElementById('month').value;
        const year = document.getElementById('year').value;
        window.location.href = `expenses.php?month=${month}&year=${year}`;
    });

    // Auto-format amount input
    document.getElementById('amount')?.addEventListener('blur', function(e) {
        const value = parseFloat(e.target.value);
        if (!isNaN(value)) {
            e.target.value = value.toFixed(2);
        }
    });
</script>

<?php
include '../includes/body.php';
?>