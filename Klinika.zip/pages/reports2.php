<?php

require_once '../includes/db.php';
require_once '../includes/functions.php';

// Xatoliklarni ko'rsatish
error_reporting(E_ALL);
ini_set('display_errors', 1);

$title = "Hisobotlar";
ob_start();
$content = ob_get_clean();
include '../includes/head.php';

if (!isLoggedIn()) {
    redirect('../pages/login.php');
}

$role = getUserRole();
$user_id = $_SESSION['user']['id'];

if ($role !== 'rahbar') {
    die("Sizda bu sahifaga kirish uchun ruxsat yo'q!");
}

// Tanlangan davr uchun statistikani olish
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$doctor_id = $_GET['doctor_id'] ?? null;
$service_id = $_GET['service_id'] ?? null;
$nurse_id = $_GET['nurse_id'] ?? null;

// Xizmat turlari ro'yxati (filtrlash uchun)
$services = $conn->query("SELECT id, name, price FROM services")->fetchAll(PDO::FETCH_ASSOC);

// Shifokorlar ro'yxati (filtrlash uchun)
$doctors = $conn->query("SELECT id, username FROM users WHERE role = 'shifokor'")->fetchAll(PDO::FETCH_ASSOC);

// Hamshiralar ro'yxati (filtrlash uchun)
$nurses = $conn->query("SELECT id, username FROM users WHERE role = 'hamshira'")->fetchAll(PDO::FETCH_ASSOC);

// Xizmat turlari bo'yicha statistika
$service_query = "SELECT 
    s.id, s.name AS xizmat_turi,
    s.price AS xizmat_narxi,
    COUNT(DISTINCT p.id) AS bemorlar_soni,
    SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) AS jami_tushum,
    
    -- Shifokor ulushi (hamma joyda staff_percentages orqali)
    SUM((s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) * 
        (SELECT COALESCE(SUM(sp.percentage), 0) 
         FROM staff_percentages sp 
         WHERE sp.user_id = p.doctor_id AND sp.service_id = s.id) / 100) AS shifokor_ulushi,

    -- Hamshira ulushi: agar service_id = 5 bo‘lsa patients.nurse_income
    SUM(CASE 
            WHEN s.id = 5 THEN p.nurse_income
            ELSE (s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) * 
                 (SELECT COALESCE(SUM(sp.percentage), 0) 
                  FROM staff_percentages sp 
                  WHERE sp.user_id = p.nurse_id AND sp.service_id = s.id) / 100
        END
    ) AS hamshira_ulushi,

    -- Kassir ulushi: agar service_id = 5 bo‘lsa patients.cashier_income
    SUM(CASE 
            WHEN s.id = 5 THEN p.kassir_income
            ELSE (s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) * 
                 (SELECT COALESCE(SUM(sp.percentage), 0) 
                  FROM staff_percentages sp 
                  WHERE sp.user_id = p.cashier_id AND sp.service_id = s.id) / 100
        END
    ) AS kassir_ulushi

FROM patients p
JOIN patient_services ps ON p.id = ps.patient_id
JOIN services s ON ps.service_id = s.id
WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
" . ($service_id ? " AND s.id = :service_id" : "") . "
GROUP BY s.id, s.name, s.price
ORDER BY jami_tushum DESC";

$service_stmt = $conn->prepare($service_query);
$params = ['start_date' => $start_date, 'end_date' => $end_date];
if ($service_id) $params['service_id'] = $service_id;
$service_stmt->execute($params);
$service_stats = $service_stmt->fetchAll(PDO::FETCH_ASSOC);

// Shifokorlar ulushi
$doctor_query = "SELECT 
                    u.id,
                    u.username AS xodim,
                    SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) AS total_income,
                    SUM((s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) * 
                        (SELECT COALESCE(SUM(sp.percentage), 0) FROM staff_percentages sp 
                         WHERE sp.user_id = p.doctor_id AND sp.service_id = s.id) / 100) AS doctor_income,
                    COUNT(DISTINCT p.id) AS patient_count
                 FROM patients p
                 JOIN patient_services ps ON p.id = ps.patient_id
                 JOIN services s ON ps.service_id = s.id
                 JOIN users u ON p.doctor_id = u.id
                 WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
                 " . ($doctor_id ? " AND p.doctor_id = :doctor_id" : "") . "
                 GROUP BY u.id, u.username
                 ORDER BY doctor_income DESC";
$doctor_stmt = $conn->prepare($doctor_query);
$params = ['start_date' => $start_date, 'end_date' => $end_date];
if ($doctor_id) $params['doctor_id'] = $doctor_id;
$doctor_stmt->execute($params);
$doctor_shares = $doctor_stmt->fetchAll(PDO::FETCH_ASSOC);

// Hamshiralar ulushi (id=5 uchun alohida nurse_income dan olinadi)
if ($service_id == 5) {
    $nurse_query = "SELECT 
        u.id,
        u.username AS xodim,
        COUNT(DISTINCT p.id) AS patient_count,
        SUM(p.nurse_income) AS nurse_income,
        SUM(p.nurse_income) AS total_income,
        ROUND(100 * SUM(p.nurse_income) / NULLIF(SUM(p.nurse_income), 0), 2) AS ulush_foizi
    FROM patients p
    JOIN patient_services ps ON p.id = ps.patient_id
    JOIN services s ON ps.service_id = s.id
    JOIN users u ON p.nurse_id = u.id
    WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
    AND s.id = :service_id
    " . ($nurse_id ? " AND p.nurse_id = :nurse_id" : "") . "
    GROUP BY u.id, u.username
    ORDER BY nurse_income DESC";
} else {
    $nurse_query = "SELECT 
        u.id,
        u.username AS xodim,
        SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) AS total_income,
        SUM((s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) * 
            (SELECT COALESCE(SUM(sp.percentage), 0) FROM staff_percentages sp 
             WHERE sp.user_id = p.nurse_id AND sp.service_id = s.id) / 100) AS nurse_income,
        COUNT(DISTINCT p.id) AS patient_count
     FROM patients p
     JOIN patient_services ps ON p.id = ps.patient_id
     JOIN services s ON ps.service_id = s.id
     JOIN users u ON p.nurse_id = u.id
     WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
     " . ($service_id ? " AND s.id = :service_id" : "") .
     ($nurse_id ? " AND p.nurse_id = :nurse_id" : "") . "
     GROUP BY u.id, u.username
     ORDER BY nurse_income DESC";
}

$nurse_stmt = $conn->prepare($nurse_query);
$params = ['start_date' => $start_date, 'end_date' => $end_date];
if ($service_id) $params['service_id'] = $service_id;
if ($nurse_id) $params['nurse_id'] = $nurse_id;
$nurse_stmt->execute($params);
$nurse_shares = $nurse_stmt->fetchAll(PDO::FETCH_ASSOC);


// Xizmat turi bo'yicha to'liq statistika (JS uchun yashirin ma'lumot)
$service_full_stats = [];
foreach ($services as $service) {
    $query = "SELECT 
                s.name AS xizmat_turi,
                COUNT(DISTINCT p.id) AS bemorlar_soni,
                (
                    SELECT GROUP_CONCAT(DISTINCT CONCAT(u.username, ' (', u.cnt, ')') SEPARATOR ', ')
                    FROM (
                        SELECT d.id, d.username, COUNT(DISTINCT p2.id) as cnt
                        FROM patients p2
                        JOIN patient_services ps2 ON p2.id = ps2.patient_id
                        JOIN users d ON p2.doctor_id = d.id
                        WHERE DATE(p2.created_at) BETWEEN :start_date AND :end_date
                        AND ps2.service_id = :service_id
                        GROUP BY d.id, d.username
                    ) u
                ) AS shifokorlar,
                (
                    SELECT GROUP_CONCAT(DISTINCT CONCAT(u.username, ' (', u.cnt, ')') SEPARATOR ', ')
                    FROM (
                        SELECT n.id, n.username, COUNT(DISTINCT p2.id) as cnt
                        FROM patients p2
                        JOIN patient_services ps2 ON p2.id = ps2.patient_id
                        JOIN users n ON p2.nurse_id = n.id
                        WHERE DATE(p2.created_at) BETWEEN :start_date AND :end_date
                        AND ps2.service_id = :service_id
                        GROUP BY n.id, n.username
                    ) u
                ) AS hamshiralar,
                SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) AS jami_tushum,
                SUM((s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100 * 
                    (SELECT COALESCE(SUM(sp.percentage), 0) FROM staff_percentages sp 
                    WHERE sp.user_id = p.doctor_id AND sp.service_id = s.id) / 100) AS shifokor_ulushi,
                SUM((s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100 * 
                    (SELECT COALESCE(SUM(sp.percentage), 0) FROM staff_percentages sp 
                    WHERE sp.user_id = p.nurse_id AND sp.service_id = s.id) / 100) AS hamshira_ulushi
            FROM patients p
            JOIN patient_services ps ON p.id = ps.patient_id
            JOIN services s ON ps.service_id = s.id
            WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
            AND s.id = :service_id
            GROUP BY s.name";
    
    try {
        $stmt = $conn->prepare($query);
        $stmt->execute([
            'start_date' => $start_date, 
            'end_date' => $end_date, 
            'service_id' => $service['id']
        ]);
        $service_full_stats[$service['id']] = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Xatolikni log qilish yoki foydalanuvchiga xabar berish
        error_log("SQL Error: " . $e->getMessage());
        $service_full_stats[$service['id']] = null;
    }
}
?>

<div class="container mt-4 mb-5">
    <div class="container-fluid py-4">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h4 class="m-0 font-weight-bold text-primary">Hisobotlar</h4>
            <div>
                <a href="reports2.php" class="btn btn-secondary btn-sm">Filtrlarni tozalash</a>
            </div>
        </div>
        <div class="card-body">
            <!-- Filtrlash formasi -->
            <form method="GET" class="mb-4">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label>Boshlanish sanasi</label>
                        <input type="date" name="start_date" class="form-control" value="<?= $start_date ?>">
                    </div>
                    <div class="col-md-3">
                        <label>Tugash sanasi</label>
                        <input type="date" name="end_date" class="form-control" value="<?= $end_date ?>">
                    </div>
                    <div class="col-md-3">
                        <label>Xizmat turi</label>
                        <select name="service_id" class="form-control">
                            <option value="">Barchasi</option>
                            <?php foreach ($services as $service): ?>
                                <option value="<?= $service['id'] ?>" <?= $service_id == $service['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($service['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label>Shifokor</label>
                        <select name="doctor_id" class="form-control">
                            <option value="">Barchasi</option>
                            <?php foreach ($doctors as $doctor): ?>
                                <option value="<?= $doctor['id'] ?>" <?= $doctor_id == $doctor['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($doctor['username']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-12 mt-3">
                        <button type="submit" class="btn btn-primary">Filtrlash</button>
                    </div>
                </div>
            </form>

            
            <!-- Xizmat turlari bo'yicha statistika -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Xizmat Turlari Bo'yicha Statistika (<?= $start_date ?> - <?= $end_date ?>)</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="serviceTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Xizmat Turi</th>
                                    <th>Bemorlar Soni</th>
                                    <th>Jami Tushum</th>
                                    <th>Shifokor Ulushi</th>
                                    <th>Hamshira Ulushi</th>
                                    <th>Kassir Ulushi</th>
                                    <th>Jami Ulush</th>
                                    <th>Klinika Foydasi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($service_stats)): ?>
                                    <?php foreach ($service_stats as $service): ?>
                                        <?php
                                        $jami_ulush = $service['shifokor_ulushi'] + $service['hamshira_ulushi'] + $service['kassir_ulushi'];
                                        $klinika_foydasi = $service['jami_tushum'] - $jami_ulush;
                                        ?>
                                        <tr class="service-row" data-service-id="<?= $service['id'] ?>">
                                            <td>
                                                <button class="btn btn-link p-0 border-0 bg-transparent text-primary toggle-service-details">
                                                    <?= htmlspecialchars($service['xizmat_turi']) ?>
                                                </button>
                                            </td>
                                            <td><?= $service['bemorlar_soni'] ?></td>
                                            <td><?= number_format($service['jami_tushum'], 0, ',', ' ') ?> so'm</td>
                                            <td><?= number_format($service['shifokor_ulushi'], 0, ',', ' ') ?> so'm</td>
                                            <td><?= number_format($service['hamshira_ulushi'], 0, ',', ' ') ?> so'm</td>
                                            <td><?= number_format($service['kassir_ulushi'], 0, ',', ' ') ?> so'm</td>
                                            <td><?= number_format($jami_ulush, 0, ',', ' ') ?> so'm</td>
                                            <td><?= number_format($klinika_foydasi, 0, ',', ' ') ?> so'm</td>
                                        </tr>
                                        <tr class="service-details" data-service-id="<?= $service['id'] ?>" style="display: none;">
                                            <td colspan="8">
                                                <div class="service-details-content p-3">
                                                    <div class="spinner-border text-primary" role="status">
                                                        <span class="visually-hidden">Yuklanmoqda...</span>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center">Ma'lumot topilmadi</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Shifokorlar ulushi -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Shifokorlar Ulushi (<?= $start_date ?> - <?= $end_date ?>)</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="doctorTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Shifokor</th>
                                    <th>Bemorlar Soni</th>
                                    <th>Jami Tushum</th>
                                    <th>Shifokor Ulushi</th>
                                    <th>Harakat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($doctor_shares)): ?>
                                    <?php foreach ($doctor_shares as $doctor): ?>
                                        <tr class="doctor-row" data-doctor-id="<?= $doctor['id'] ?>">
                                            <td><?= htmlspecialchars($doctor['xodim']) ?></td>
                                            <td><?= $doctor['patient_count'] ?></td>
                                            <td><?= number_format($doctor['total_income'], 0, ',', ' ') ?> so'm</td>
                                            <td><?= number_format($doctor['doctor_income'], 0, ',', ' ') ?> so'm</td>
                                            <td>
                                                <button class="btn btn-sm btn-info toggle-doctor-details">
                                                    <i class="fas fa-eye"></i> Ko'rish
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="doctor-details" data-doctor-id="<?= $doctor['id'] ?>" style="display: none;">
                                            <td colspan="5">
                                                <?php 
                                                // Shifokorning barcha xizmat turlari bo'yicha statistikasi
                                                $doctor_full_query = "SELECT 
                                                    s.name AS xizmat_turi,
                                                    COUNT(DISTINCT p.id) AS bemorlar_soni,
                                                    SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) AS jami_tushum,
                                                    SUM((s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) * 
                                                        (SELECT COALESCE(SUM(sp.percentage), 0) FROM staff_percentages sp 
                                                         WHERE sp.user_id = p.doctor_id AND sp.service_id = s.id) / 100) AS doctor_income,
                                                    (SELECT COALESCE(SUM(sp.percentage), 0) FROM staff_percentages sp 
                                                     WHERE sp.user_id = p.doctor_id AND sp.service_id = s.id) AS doctor_percentage
                                                  FROM patients p
                                                  JOIN patient_services ps ON p.id = ps.patient_id
                                                  JOIN services s ON ps.service_id = s.id
                                                  WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
                                                  AND p.doctor_id = :doctor_id
                                                  GROUP BY s.name
                                                  ORDER BY jami_tushum DESC";
                                                $stmt = $conn->prepare($doctor_full_query);
                                                $stmt->execute(['start_date' => $start_date, 'end_date' => $end_date, 'doctor_id' => $doctor['id']]);
                                                $doctor_full_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                                ?>
                                                <?php if (!empty($doctor_full_stats)): ?>
                                                    <div class="table-responsive mt-3">
                                                        <table class="table table-sm table-bordered">
                                                            <thead>
                                                                <tr>
                                                                    <th>Xizmat Turi</th>
                                                                    <th>Bemorlar Soni</th>
                                                                    <th>Jami Tushum</th>
                                                                    <th>Shifokor Ulushi</th>
                                                                    <th>Ulush Foizi</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php foreach ($doctor_full_stats as $stat): ?>
                                                                    <tr>
                                                                        <td><?= htmlspecialchars($stat['xizmat_turi']) ?></td>
                                                                        <td><?= $stat['bemorlar_soni'] ?></td>
                                                                        <td><?= number_format($stat['jami_tushum'], 0, ',', ' ') ?> so'm</td>
                                                                        <td><?= number_format($stat['doctor_income'], 0, ',', ' ') ?> so'm</td>
                                                                        <td><?= $stat['doctor_percentage'] ?>%</td>
                                                                    </tr>
                                                                <?php endforeach; ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                <?php else: ?>
                                                    <p class="text-center">Ma'lumot topilmadi</p>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center">Ma'lumot topilmadi</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Hamshiralar ulushi -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Hamshiralar Ulushi (<?= $start_date ?> - <?= $end_date ?>)</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="nurseTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Hamshira</th>
                                    <th>Bemorlar Soni</th>
                                    <th>Jami Tushum</th>
                                    <th>Hamshira Ulushi</th>
                                    <th>Harakat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($nurse_shares)): ?>
                                    <?php foreach ($nurse_shares as $nurse): ?>
                                        <tr class="nurse-row" data-nurse-id="<?= $nurse['id'] ?>">
                                            <td><?= htmlspecialchars($nurse['xodim']) ?></td>
                                            <td><?= $nurse['patient_count'] ?></td>
                                            <td><?= number_format($nurse['total_income'], 0, ',', ' ') ?> so'm</td>
                                            <td><?= number_format($nurse['nurse_income'], 0, ',', ' ') ?> so'm</td>
                                            <td>
                                                <button class="btn btn-sm btn-info toggle-nurse-details">
                                                    <i class="fas fa-eye"></i> Ko'rish
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="nurse-details" data-nurse-id="<?= $nurse['id'] ?>" style="display: none;">
                                            <td colspan="5">
                                                <?php 
                                                // Hamshiraning barcha shifokorlar bilan xizmat ko'rsatish statistikasi
                                                $nurse_full_query = "SELECT 
    s.name AS xizmat_turi,
    d.username AS shifokor,
    COUNT(DISTINCT p.id) AS bemorlar_soni,
    SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) AS jami_tushum,
    CASE 
        WHEN s.id = 5 THEN SUM(p.nurse_income)
        ELSE SUM((s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100) * 
             (SELECT COALESCE(SUM(sp.percentage), 0) 
              FROM staff_percentages sp 
              WHERE sp.user_id = p.nurse_id AND sp.service_id = s.id) / 100)
    END AS nurse_income,
    CASE 
        WHEN s.id = 5 THEN 
            ROUND(100 * SUM(p.nurse_income) / NULLIF(SUM(s.price * (100 - COALESCE(p.discount_percentage, 0)) / 100), 0), 2)
        ELSE 
            (SELECT COALESCE(SUM(sp.percentage), 0) 
             FROM staff_percentages sp 
             WHERE sp.user_id = p.nurse_id AND sp.service_id = s.id)
    END AS nurse_percentage
FROM patients p
JOIN patient_services ps ON p.id = ps.patient_id
JOIN services s ON ps.service_id = s.id
JOIN users d ON p.doctor_id = d.id
WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
AND p.nurse_id = :nurse_id
GROUP BY s.name, d.username, s.id
ORDER BY jami_tushum DESC";
$stmt = $conn->prepare($nurse_full_query);
$params = ['start_date' => $start_date, 'end_date' => $end_date, 'nurse_id' => $nurse['id']];
$stmt->execute($params);
$nurse_full_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
                                                <?php if (!empty($nurse_full_stats)): ?>
                                                    <div class="table-responsive mt-3">
                                                        <table class="table table-sm table-bordered">
                                                            <thead>
                                                                <tr>
                                                                    <th>Xizmat Turi</th>
                                                                    <th>Shifokor</th>
                                                                    <th>Bemorlar Soni</th>
                                                                    <th>Jami Tushum</th>
                                                                    <th>Hamshira Ulushi</th>
                                                                    <th>Ulush Foizi</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php foreach ($nurse_full_stats as $stat): ?>
                                                                    <tr>
                                                                        <td><?= htmlspecialchars($stat['xizmat_turi']) ?></td>
                                                                        <td><?= htmlspecialchars($stat['shifokor']) ?></td>
                                                                        <td><?= $stat['bemorlar_soni'] ?></td>
                                                                        <td><?= number_format($stat['jami_tushum'], 0, ',', ' ') ?> so'm</td>
                                                                        <td><?= number_format($stat['nurse_income'], 0, ',', ' ') ?> so'm</td>
                                                                        <td><?= $stat['nurse_percentage'] ?>%</td>
                                                                    </tr>
                                                                <?php endforeach; ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                <?php else: ?>
                                                    <p class="text-center">Ma'lumot topilmadi</p>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center">Ma'lumot topilmadi</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Xizmat turlari bo'yicha tafsilotlarni ko'rsatish
    $('.toggle-service-details').click(function() {
        var serviceId = $(this).closest('tr').data('service-id');
        var detailsRow = $('.service-details[data-service-id="' + serviceId + '"]');
        var contentDiv = detailsRow.find('.service-details-content');
        
        if (detailsRow.is(':visible')) {
            detailsRow.hide();
            return;
        }
        
        // Yuklash animatsiyasi
        contentDiv.html('<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="sr-only">Yuklanmoqda...</span></div></div>');
        detailsRow.show();
        
        // AJAX so'rov orqali ma'lumotlarni olish
        $.ajax({
            url: '../includes/get_service_details.php',
            type: 'GET',
            data: {
                service_id: serviceId,
                start_date: '<?= $start_date ?>',
                end_date: '<?= $end_date ?>'
            },
            success: function(response) {
                contentDiv.html(response);
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", status, error);
                contentDiv.html('<div class="alert alert-danger">Ma\'lumotlarni yuklashda xatolik yuz berdi<br>Xatolik: ' + 
                              error + '<br>Status: ' + xhr.status + '</div>');
            }
        });
    });

    // Shifokorlar tafsilotlari
    $('.toggle-doctor-details').click(function() {
        var doctorId = $(this).closest('tr').data('doctor-id');
        $('.doctor-details[data-doctor-id="' + doctorId + '"]').toggle();
    });

    // Hamshiralar tafsilotlari
    $('.toggle-nurse-details').click(function() {
        var nurseId = $(this).closest('tr').data('nurse-id');
        $('.nurse-details[data-nurse-id="' + nurseId + '"]').toggle();
    });
});
</script>

<?php
include '../includes/body.php';
?>