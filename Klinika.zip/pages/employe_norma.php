<?php
/**
 * Happy Medline Hamshiralari uchun ish haqi to'lov tizimi
 * Fayl nomi: hamshira_salary_system.php
 * Muallif: Happy Medline
 * Versiya: 1.0
 * Sana: [Joriy sana]
 */
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
$title = "Ish haqi to'lov tizimi";
ob_start();
$content = ob_get_clean();
include '../includes/head.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole();
if ($role !== 'hamshira' && $role !== 'rahbar') {
    die("Sizda hamshiralar to'lov tizimini ko'rish uchun ruxsat yo'q!");
}

// Limitlarni olish
$stmt = $conn->query("SELECT id, current_limit FROM nurse_limits WHERE id IN (1,2,3,4)");
$limits = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Formatlangan limitlarni saqlash
$limit_bir = $limit_ikki = $limit_uch = $limit_tort = '';

foreach ($limits as $limit) {
    if ($limit['id'] == 1) {
        $limit_bir = number_format($limit['current_limit'], 0, ',', ' ') . " so'm";
    } elseif ($limit['id'] == 2) {
        $limit_ikki = number_format($limit['current_limit'], 0, ',', ' ') . " so'm";
    } elseif ($limit['id'] == 3) {
        $limit_uch = number_format($limit['current_limit'], 0, ',', ' ') . " so'm";
    } elseif ($limit['id'] == 4) {
        $limit_tort = number_format($limit['current_limit'], 0, ',', ' ') . " so'm";
    }
}
$current_user_id = $_SESSION['user']['id'];

// Faqat service_id = 5 uchun foizni olish
$stmt = $conn->prepare("SELECT percentage FROM staff_percentages WHERE user_id = ? AND service_id = 5");
$stmt->execute([$current_user_id]);
$current_percentage = $stmt->fetchColumn();

?>
<style>

    h1, h2, h3 {
        color: #2c3e50;
    }
    h1 {
        text-align: center;
        margin-bottom: 30px;
        color: #3498db;
    }
    h2 {
        border-bottom: 2px solid #3498db;
        padding-bottom: 5px;
        margin-top: 25px;
    }
    .rule-section {
        background-color: #f9f9f9;
        border-left: 4px solid #3498db;
        padding: 15px;
        margin: 15px 0;
    }
    .example {
        background-color: #e8f4fc;
        padding: 15px;
        border-radius: 5px;
        margin: 15px 0;
    }
    .success-example {
        border-left: 4px solid #2ecc71;
    }
    .error-example {
        border-left: 4px solid #e74c3c;
    }
    .highlight {
        background-color: #fffde7;
        padding: 2px 5px;
        font-weight: bold;
    }
    .login-btn-container {
        text-align: center;
        margin-top: 40px;
        padding: 20px 0;
        border-top: 1px solid #eee;
    }
    .login-btn {
        display: inline-block;
        padding: 12px 30px;
        background-color: #3498db;
        color: white;
        text-decoration: none;
        border-radius: 30px;
        font-weight: bold;
        transition: all 0.3s ease;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        border: 2px solid #3498db;
    }
    .login-btn:hover {
        background-color: #2980b9;
        transform: translateY(-2px);
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
    }
    .login-btn:active {
        transform: translateY(0);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .user-info-card {
        background: linear-gradient(135deg, #3498db, #2c3e50);
        color: white;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 20px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .percentage-display {
        font-size: 2.5rem;
        font-weight: bold;
        margin: 10px 0;
    }
    .btn-show-shares {
        background-color: #2ecc71;
        border: none;
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        transition: all 0.3s;
    }
    .btn-show-shares:hover {
        background-color: #27ae60;
    }
    .service-shares-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .service-shares-table th, 
    .service-shares-table td {
        padding: 12px 15px;
        border: 1px solid #ddd;
        text-align: left;
    }
    .service-shares-table th {
        background-color: #3498db;
        color: white;
    }
    .service-shares-table tr:nth-child(even) {
        background-color: #f2f2f2;
    }
    .service-shares-table tr:hover {
        background-color: #e9ecef;
    }
</style>
    <!-- User Info Card -->
    <div class="user-info-card">
        <div class="percentage-display">
<!--            <b><?= htmlspecialchars($_SESSION['user']['username']) ?></b>  -->
Muolaja: <?= $current_percentage ?>%
        </div>
    </div>
            <div class="container mt-5">
                <div class="card mb-4">
            <div class="card-header">
                <h2 class="mb-0">Happy Medline Hamshiralari uchun ish haqi to'lov tizimi</h2>
            </div>
            <div class="rule-section">
                <h2>1. Ish haqi hisoblash tartibi</h2>
                
                <p><strong>1.1</strong> Har oyning 10-kuni, 20-kuni va oy yakuni bo'yicha hisob-kitob qilinadi.</p>
                
                <p><strong>1.2</strong> Har bir hamshiralar dastlab <span class="highlight">40% ulush</span> bilan ishni boshlaydi.</p>
                
                <p><strong>1.3</strong> Har keyingi 10 kunlikka o'tishda, limit bajarilsa <span class="highlight">10%ga oshadi</span> lekin <span class="highlight">70%dan ko'p emas</span>. Limit bajarilmasa <span class="highlight">10% kam ulush</span> bilan boshlanadi lekin limit bilan bog'liq holda <span class="highlight">40%dan kam bo'lmagan</span> ulush olishi kafolatlanadi.</p>
                
                <p><strong>1.4</strong> Har yangi oyga o'tishda limit bajarilsa oxirgi olayotgan ulushidan <span class="highlight">10% kam ulush</span> bilan oyni boshlaydi. Agarda limit bajarilmasa <span class="highlight">10 kunlik hisobidan 10%</span> va <span class="highlight">yangi oyga o'tish hisobidan 10%ga kamayib</span> jami <span class="highlight">20% kamayishni</span> tashkil qiladi lekin <span class="highlight">40%dan kam bo'lmagan</span> ulush olishi kafolatlanadi.</p>
            </div>
            
            <div class="rule-section">
                <h2>2. Ulushning oshishi</h2>
                
                <p><strong>2.1</strong> Dastlabki 10 kun: Agar barcha hamshiralar birgalikda jami <span class="highlight"><?= $limit_bir ?></span> va undan ko'p maosh olsa, keyingi 10 kunlikda har bir hamshira ulushi <span class="highlight">50%</span> bo'ladi.</p>
                
                <p><strong>2.2</strong> Keyingi 10 kunlik: Agar jami hamshiralar birgalikda jami <span class="highlight"><?= $limit_ikki ?></span> va undan ko'p maosh olsa, yana keyingi 10 kunlikda ulushi <span class="highlight">60%</span> ga oshadi.</p>
                
                <p><strong>2.3</strong> Oxirgi 10 kunlik: Agar jami hamshiralar birgalikda jami <span class="highlight"><?= $limit_uch ?></span> va undan kam bo'lmagan maosh olsa, ulushi <span class="highlight">60%</span> o'zgarishsiz qoladi.</p>
            </div>
            
            <div class="rule-section">
                <h2>3. Oy tugaganda yangi oyga o'tish</h2>
                
                <p><strong>3.1</strong> Agar hamshiralar oy davomida limitga yetsa, yangi oy <span class="highlight">50% ulush</span> (1.4-band) bilan boshlanadi.</p>
                
                <p><strong>3.2</strong> Yangi oydagi dastlabki 10 kunlik: Agar barcha hamshiralar birgalikda jami <span class="highlight"><?= $limit_ikki ?></span> va undan ko'p maosh olsa, yana keyingi 10 kunlikda ulushi <span class="highlight">60%</span> ga oshadi.</p>
                
                <p><strong>3.3</strong> Keyingi 10 kunlik: Agar barcha hamshiralar birgalikda jami <span class="highlight"><?= $limit_uch ?></span> va undan ko'p maosh olishsa, ulushi <span class="highlight">70%</span> ga oshadi.</p>
                
                <p><strong>3.4</strong> Oxirgi 10 kunlik: Agar barcha hamshiralar birgalikda jami <span class="highlight"><?= $limit_tort ?></span> va undan ko'p maosh olsa, ulushi <span class="highlight">70%</span> o'zgarishsiz qoladi.</p>
                
                <p><strong>3.5</strong> Agar limitga yetsa 60%, 1.4 bandga asosan yangi oy <span class="highlight">10% pasaygan ulush</span> bilan boshlanadi.</p>
            </div>
            
            <div class="example success-example">
                <h3>✅ Misol (barcha hamshiralar birgalikda jami):</h3>
                <p>Oy boshida ulush 40% bilan ish boshlangan bo'lsa:</p>
                <ul>
                    <li>1-10 kunlikda <span class="highlight"><?= $limit_bir ?></span> maosh olsa → Keyingi 10 kun uchun <span class="highlight">50%</span> bo'ladi</li>
                    <li>11-20 kunlikda <span class="highlight"><?= $limit_ikki ?></span> maosh olsa → Keyingi 10 kun uchun <span class="highlight">60%</span> bo'ladi</li>
                    <li>21-oy oxirigacha <span class="highlight"><?= $limit_ikki ?>dan kam bo'lmagan</span> maosh olsa → Keyingi 10 kun uchun o'zgarish <span class="highlight">60%</span> qoladi</li>
                    <li>Yangi oy 1.4 bandga asosan <span class="highlight">50%</span> ulush bilan boshlanadi</li>
                    <li>1-10 kunlikda <span class="highlight"><?= $limit_ikki ?></span> maosh olsa → Keyingi 10 kun uchun <span class="highlight">60%</span> bo'ladi</li>
                    <li>11-20 kunlikda <span class="highlight"><?= $limit_uch ?></span> maosh olsa → Keyingi 10 kun uchun <span class="highlight">70%</span> bo'ladi</li>
                    <li>21-oy oxirigacha <span class="highlight"><?= $limit_tort ?>dan kam bo'lmagan</span> maosh olsa → Keyingi 10 kun (yangi oy) uchun (1.4 band) <span class="highlight">60%</span> bilan boshlanadi.</li>
                                        <li>1-10 kunlikda <span class="highlight"><?= $limit_tort ?>dan kam bo'lmagan</span> maosh olsa → Keyingi 10 kun uchun ulush<span class="highlight">70%</span> bilan bo'ladi...</li>
                </ul>
            </div>
            
            <div class="example error-example">
                <h3>❌ Agar 10 kunlikda kerakli limit bajarilmasa:</h3>
                <ul>
                    <li>Masalan, <?= $limit_uch ?> maosh olmasa, keyingi oy <span class="highlight">40% ulush</span> bilan boshlanadi.</li>
                    <li>Maksimal belgilangan 70%ga yetsa keyingi oy 1.4 bandga muvofiq <span class="highlight">60%</span> bilan boshlaydi. <span class="highlight">Tavsiya:</span><b>1.4 band</b> bilan yaqindan tanishib chiqing!</li> 
                </ul>
            </div>
            
            <div class="rule-section">
                <h3>Muhim:</h3>
                <ul>
                    <li>Ulush oshishi faqat <span class="highlight">keyingi 10 kunlik</span> uchun amal qiladi.</li>
                    <li>Yangi oyda yuqori ulushni saqlab qolish uchun <span class="highlight">limitni bajarish</span> kerak.</li>
                    <li><b>40%</b> >> <b>50%</b> <span class="highlight"><?= $limit_bir ?></span></li>
                    <li><b>50%</b> >> <b>60%</b> <span class="highlight"><?= $limit_ikki ?></span></li>
                    <li><b>60%</b> >> <b>70%</b> <span class="highlight"><?= $limit_uch ?></span></li>
                    <li><b>70%</b> ulush <b>muqobil qolish</b> <span class="highlight"><?= $limit_tort ?></span></li>
                    <li><b>‼️</b> Har bir limit bajarilganda ushbu limitning miqdori <b>10%</b>ga <span class="highlight">ko'tariladi.</span></li>
                </ul>
            </div>
            </div>
            <div class="card mb-4">
            <div class="card-header">
                <h2 class="mb-0">"Foizli Jarima" Tamoyili</h2>
            </div>
            <div class="card-body">
                <ul>
<li><b>Tibbiy formada bo‘lmaslik</b> ➔ o'zi uchun<span class="highlight">-5%</span>. Qolgan hamshiralar: <span class="highlight">-2.5%</span></li>
        <li><b>Ishga kech kelish</b> ➔ o'zi uchun<span class="highlight">-5%</span>. Qolgan hamshiralar: <span class="highlight">-2.5%</span></li>
        <li><b>Ruxsatsiz ishdan erta ketish</b> ➔ o'zi uchun<span class="highlight">-5%</span>. Qolgan hamshiralar: <span class="highlight">-2.5%</span></li>
        <li><b>O'z xonasining tartibsizligi</b> ➔ o'zi uchun<span class="highlight">-5%</span>. Qolgan hamshiralar: <span class="highlight">-2.5%</span></li>
        <li><b>Hamshira ustidan shifokor yoki be'morlarning asosli shikoyatlari</b> ➔ o'zi uchun<span class="highlight">-5%</span>. Qolgan hamshiralar: <span class="highlight">-2.5%</span></li>
        <li><b>Be'morlar bilan xushmuomila bo'lmaslik</b> ➔ o'zi uchun<span class="highlight">-5%</span>. Qolgan hamshiralar: <span class="highlight">-2.5%</span></li>
        </ul>
</div>
<ul>
    <p>Har 10 kunlikda ulush oshishi uchun ma'lum limitga erishiladi. Agar qoidabuzarliklar bo‘lsa, shu zaxoti o'zi uchun 5% ulush kamayadi. Qolgan hamshiralar uchun 10 kunlik oxrida (qoidabuzarlik soni x 2.5%) kamayadi. Limit bajaraolmaslik 40% ulush ushlanadi lekin qoidabuzarlik 30%gacha ulush tushishiga olib keladi.</p>
    </ul>

    <h3>Qolgan hamshiralar uchun misol</h3>
<ul>
        <li>Dastlabki ulush: <b>40%</b></li>
        <li>Limit bajarildi ➔ +10% ➔ <b>50%</b> bo‘lishi kerak</li>
        <li>Ammo 6 ta qoidabuzarlik: ➖15%</li>

        <li>Natija: <b>35% ulush</b> bilan qoladi</li>
            <li>✅ Agarda  hamshiralar ulushi 40%dan tushsa, eng past 40%lik limitni bajaraolmasa va keyingi 10 kunlik davomida qoidabuzarlik takrorlanmasa 40% ulush qayta tiklanadi</li>

    </ul>
            <div class="example error-example">
                <h3>Har bir qoidabuzarlikdan keladigan ulushning tushishi shu zahoti faqat shu hamshiraning o'zi uchun amal qiladi, qolgan hamshiralar uchun 10 kunlik oxrida amalga oshiriladi va barcha hamshiralar xabardor qilinadi.</h3>

</div>
<ul>
<li>✅ Birgalikda yutuq — birgalikda ulush oshishi
</li>
<li>✅ Birgalikda xato — birgalikda jarima!
</li>
</ul>
</div></div>


<?php
include '../includes/body.php';
?>