<?php
// 1. Dastur boshlanishi va asosiy sozlamalar
ob_start();
session_start();

// Xatoliklarni ko'rsatish (faqat development uchun)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 2. Kerakli fayllarni ulash
require_once '../includes/db.php';
require_once '../includes/functions.php';

// 3. Sahifa sarlavhasi
$title = "To'lov Boshqaruvi";

// 4. Avtorizatsiya tekshiruvi
if (!isLoggedIn()) {
    $_SESSION['error'] = "Iltimos, tizimga kirishingiz kerak!";
    header("Location: login.php");
    exit();
}

if (getUserRole() !== 'rahbar') {
    $_SESSION['error'] = "Sizda ushbu sahifaga kirish uchun ruxsat yo'q!";
    header("Location: dashboard.php");
    exit();
}

// Bonus qo'shish
// Bonus qo'shish funksiyasi
function handleBonus($conn, $postData) {
    $conn->beginTransaction();
    
    try {
        // Validatsiya
        $employee_id = intval($postData['employee_id']);
        $bonus_amount = floatval($postData['bonus_amount']);
        $bonus_reason = trim($postData['bonus_reason']);
        
        if ($bonus_amount <= 0) {
            throw new Exception("Bonus miqdori noto'g'ri kiritilgan!");
        }
        
        if (empty($bonus_reason)) {
            throw new Exception("Bonus sababini kiriting!");
        }
        
        // Xodim ma'lumotlarini olish
        $stmt = $conn->prepare("SELECT username, telegram_id, total_income FROM users WHERE id = :id");
        $stmt->execute(['id' => $employee_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            throw new Exception("Xodim topilmadi!");
        }
        
        // Bonusni qo'shish
        $insert_bonus = "INSERT INTO bonuses (user_id, amount, reason, created_by) 
                        VALUES (:user_id, :amount, :reason, :created_by)";
        $stmt = $conn->prepare($insert_bonus);
        $stmt->execute([
            'user_id' => $employee_id,
            'amount' => $bonus_amount,
            'reason' => $bonus_reason,
            'created_by' => $_SESSION['user']['id']
        ]);
        
        // Balansni yangilash
        $new_balance = $user['total_income'] + $bonus_amount;
        $update_user = "UPDATE users SET total_income = :balance WHERE id = :id";
        $stmt = $conn->prepare($update_user);
        $stmt->execute(['balance' => $new_balance, 'id' => $employee_id]);
        
        // Hisobotga yozish
        $insert_report = "INSERT INTO reports (user_id, total_income, date, is_bonus, description) 
                         VALUES (:user_id, :amount, NOW(), TRUE, :description)";
        $stmt = $conn->prepare($insert_report);
        $stmt->execute([
            'user_id' => $employee_id,
            'amount' => $bonus_amount,
            'description' => 'Bonus: ' . $bonus_reason
        ]);
        
        // Telegram xabar
        if (!empty($user['telegram_id'])) {
            $message = "🎉 <b>Hurmatli " . htmlspecialchars($user['username']) . "!</b>\n\n";
            $message .= "💰 Sizga <b>" . number_format($bonus_amount, 0, ',', ' ') . "</b> so'm miqdorida #bonus qo'shildi!\n";
            $message .= "📝 Sabab: " . htmlspecialchars($bonus_reason) . "\n";
            $message .= "📅 Sana: " . date('d.m.Y') . "\n\n";
            $message .= "✅ Yangi balans: " . number_format($new_balance, 0, ',', ' ') . " so'm\n";
            $message .= "🔍 Batafsil: " . $_SERVER['HTTP_HOST'] . "/project/pages/payment_history.php";
            
            sendTelegramMessage($user['telegram_id'], $message, 'HTML');
        }
        
        $conn->commit();
        
        // Sessiyaga saqlash
        $_SESSION['bonus_success'] = [
            'username' => $user['username'],
            'amount' => $bonus_amount,
            'reason' => $bonus_reason,
            'timestamp' => time()
        ];
        
    } catch (Exception $e) {
        $conn->rollBack();
        throw $e;
    }
}

// 5. Xodimlarni olish
function getEmployeesWithIncome($conn) {
    try {
        $query = "SELECT id, username, total_income FROM users 
                 WHERE role IN ('shifokor', 'hamshira', 'kassir') 
                 AND total_income > 0
                 ORDER BY username";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Xodimlarni olishda xato: " . $e->getMessage());
        return [];
    }
}

$employees = getEmployeesWithIncome($conn);

// 6. POST so'rovlarni qayta ishlash
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // 6.1 To'lov amalga oshirish
        if (isset($_POST['pay'])) {
            handlePayment($conn, $_POST, $employees);
        }
        
        // 6.2 Bonus qo'shish
        if (isset($_POST['add_bonus'])) {
            handleBonus($conn, $_POST);
        }
        
    } catch (Exception $e) {
        $_SESSION['error'] = "Xatolik: " . $e->getMessage();
        header("Location: payment.php");
        exit();
    }
}

// 7. To'lov funksiyasi
// To'lov funksiyasini yangilangan versiyasi
function handlePayment($conn, $postData, $employees) {
    $conn->beginTransaction();
    
    try {
        // Debug uchun POST ma'lumotlarini logga yozish
        error_log("Payment POST data: " . print_r($postData, true));
        
        if (empty($postData['selected_employees'])) {
            throw new Exception("Hech qanday xodim tanlanmagan!");
        }
        
        $total_payment = 0;
        $payment_details = [];
        
        foreach ($postData['selected_employees'] as $employee_id) {
            $employee_id = intval($employee_id);
            $payment_amount = floatval($postData['payment_amount'][$employee_id] ?? 0);
            
            // Xodimni tekshirish
            $employee = findEmployeeById($employees, $employee_id);
            if (!$employee) {
                error_log("Xodim topilmadi: " . $employee_id);
                continue;
            }
            
            if ($payment_amount <= 0) {
                continue;
            }
            
            // Tranzaksiyani bajarish
            $remaining = $employee['total_income'] - $payment_amount;
            
            // 1. Hisobotga yozish
            $insert_query = "INSERT INTO reports (user_id, total_income, date, description) 
                            VALUES (:user_id, :total_income, NOW(), 'Ish haqi to\'lovi')";
            $insert_stmt = $conn->prepare($insert_query);
            if (!$insert_stmt->execute([
                'user_id' => $employee_id,
                'total_income' => $payment_amount
            ])) {
                throw new Exception("Hisobotga yozishda xato!");
            }
            
            // 2. Balansni yangilash
            $update_query = "UPDATE users SET total_income = :remaining WHERE id = :id";
            $update_stmt = $conn->prepare($update_query);
            if (!$update_stmt->execute([
                'remaining' => $remaining,
                'id' => $employee_id
            ])) {
                throw new Exception("Balansni yangilashda xato!");
            }
            
            $total_payment += $payment_amount;
            $payment_details[] = [
                'username' => $employee['username'],
                'amount' => $payment_amount,
                'remaining' => $remaining
            ];
            
            // Telegram xabarini yuborish
            sendPaymentNotification($conn, $employee_id, $employee['username'], $payment_amount, $remaining);
        }
        
        if ($total_payment <= 0) {
            throw new Exception("To'lov miqdori noto'g'ri!");
        }
        
        // Rahbarga xabar
        sendAdminNotification($conn, $_SESSION['user']['username'], $total_payment, $payment_details);
        
        $conn->commit();
        
        $_SESSION['payment_success'] = [
            'total' => $total_payment,
            'details' => $payment_details,
            'timestamp' => time()
        ];
        
    } catch (Exception $e) {
        $conn->rollBack();
        error_log("Payment error: " . $e->getMessage());
        throw $e;
    }
}

// 8. Yordamchi funksiyalar
function findEmployeeById($employees, $id) {
    foreach ($employees as $employee) {
        if ($employee['id'] == $id) {
            return $employee;
        }
    }
    return null;
}

function sendPaymentNotification($conn, $employee_id, $username, $amount, $remaining) {
    $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = :id");
    $stmt->execute(['id' => $employee_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && !empty($user['telegram_id'])) {
        $message = "💸 <b>#Ish_haqi to'lovi</b>\n\n";
        $message .= "👤 Xodim: " . htmlspecialchars($username) . "\n";
        $message .= "💰 Miqdor: " . number_format($amount, 0, ',', ' ') . " so'm\n";
        $message .= "📅 Sana: " . date('d.m.Y') . "\n";
        $message .= "✅ Holat: To'lov muvaffaqiyatli amalga oshirildi.\n\n";
        $message .= "📊 Qolgan balans: " . number_format($remaining, 0, ',', ' ') . " so'm";
        
        sendTelegramMessage($user['telegram_id'], $message, 'HTML');
    }
}

function sendAdminNotification($conn, $admin_name, $total_payment, $payment_details) {
    $admin_query = "SELECT telegram_id FROM users WHERE role = 'rahbar' LIMIT 1";
    $admin_stmt = $conn->prepare($admin_query);
    $admin_stmt->execute();
    $admin = $admin_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($admin && !empty($admin['telegram_id'])) {
        $message = "📊 <b>To'lov #hisoboti</b>\n\n";
        $message .= "👤 To'lov qilgan: " . htmlspecialchars($admin_name) . "\n";
        $message .= "📅 Sana: " . date('d.m.Y') . "\n\n";
        
        foreach ($payment_details as $detail) {
            $message .= "👤 " . $detail['username'] . ": " . number_format($detail['amount'], 0, ',', ' ') . " so'm\n";
        }
        
        $message .= "\n💵 <b>Jami to'lov: " . number_format($total_payment, 0, ',', ' ') . " so'm</b>\n";
        $message .= "🔍 Batafsil: " . $_SERVER['HTTP_HOST'] . "/project/pages/payment_history.php";
        
        sendTelegramMessage($admin['telegram_id'], $message, 'HTML');
    }
}

// 9. HTML Ko'rinishi
include '../includes/head.php';
?>

<!-- CSS qo'shimchalari -->
<style>
    .payment-card {
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s;
    }
    .payment-card:hover {
        transform: translateY(-2px);
    }
    .payment-amount:disabled {
        background-color: #f8f9fa;
        cursor: not-allowed;
    }
    .table-hover tbody tr:hover {
        background-color: rgba(0, 123, 255, 0.05);
    }
    .confirmation-modal .modal-body {
        max-height: 60vh;
        overflow-y: auto;
    }
    .badge-balance {
        font-size: 0.9em;
        padding: 0.35em 0.65em;
    }
</style>

<!-- Asosiy kontent -->
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">To'lov Boshqaruvi</h1>
        <div>
            <a href="payment_history.php" class="btn btn-outline-primary me-2">
                <i class="fas fa-history me-1"></i> To'lovlar tarixi
            </a>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#bonusModal">
                <i class="fas fa-gift me-1"></i> Bonus qo'shish
            </button>
        </div>
    </div>

    <!-- Xabarlarni ko'rsatish -->
<!-- Xabarlarni ko'rsatish -->
<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <?= htmlspecialchars($_SESSION['error']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['payment_success'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <h5><i class="fas fa-check-circle me-2"></i> To'lov muvaffaqiyatli amalga oshirildi!</h5>
        <p class="mb-1">Jami to'lov: <strong><?= number_format($_SESSION['payment_success']['total'], 0, ',', ' ') ?> so'm</strong></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        
        <div class="mt-3">
            <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" 
                    data-bs-target="#paymentDetails" aria-expanded="false">
                Batafsil ko'rsatish
            </button>
            
            <div class="collapse mt-2" id="paymentDetails">
                <div class="card card-body">
                    <ul class="list-group list-group-flush">
                        <?php foreach ($_SESSION['payment_success']['details'] as $detail): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span><?= htmlspecialchars($detail['username']) ?></span>
                                <span class="badge bg-primary rounded-pill">
                                    <?= number_format($detail['amount'], 0, ',', ' ') ?> so'm
                                </span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <?php unset($_SESSION['payment_success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['bonus_success'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <h5><i class="fas fa-gift me-2"></i> Bonus muvaffaqiyatli qo'shildi!</h5>
        <p class="mb-1">Xodim: <strong><?= htmlspecialchars($_SESSION['bonus_success']['username']) ?></strong></p>
        <p class="mb-1">Miqdor: <strong><?= number_format($_SESSION['bonus_success']['amount'], 0, ',', ' ') ?> so'm</strong></p>
        <p class="mb-0">Sabab: <em><?= htmlspecialchars($_SESSION['bonus_success']['reason']) ?></em></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['bonus_success']); ?>
<?php endif; ?>


    <!-- To'lov formasi -->
    <form method="POST" action="" id="paymentForm">
        <div class="card payment-card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-money-bill-wave me-2"></i> Xodimlarga To'lov</h5>
            </div>
            
            <div class="card-body">
                <?php if (!empty($employees)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="40px" class="text-center">#</th>
                                    <th>Xodim</th>
                                    <th class="text-end">Balans</th>
                                    <th class="text-end">To'lov Miqdori</th>
                                    <th class="text-end">Qoladi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($employees as $employee): ?>
                                    <tr>
                                        <td class="text-center">
                                            <input type="checkbox" name="selected_employees[]" 
                                                   value="<?= $employee['id'] ?>" 
                                                   class="form-check-input employee-checkbox"
                                                   data-id="<?= $employee['id'] ?>">
                                        </td>
                                        <td><?= htmlspecialchars($employee['username']) ?></td>
                                        <td class="text-end">
                                            <span class="badge bg-primary badge-balance">
                                                <?= number_format($employee['total_income'], 0, ',', ' ') ?> so'm
                                            </span>
                                        </td>
                                        <td class="text-end" style="min-width: 150px;">
                                            <input type="number" name="payment_amount[<?= $employee['id'] ?>]" 
                                                   id="amount_<?= $employee['id'] ?>" 
                                                   value="<?= $employee['total_income'] ?>" 
                                                   min="0" max="<?= $employee['total_income'] ?>" 
                                                   class="form-control payment-amount text-end"
                                                   data-id="<?= $employee['id'] ?>"
                                                   data-total="<?= $employee['total_income'] ?>">
                                        </td>
                                        <td class="text-end" id="remaining_<?= $employee['id'] ?>">
                                            0 so'm
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info mb-0">
                        <i class="fas fa-info-circle me-2"></i> To'lov uchun xodimlar topilmadi
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="card-footer bg-light">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0">Jami to'lov: <span id="totalPayment" class="text-success">0</span> so'm</h5>
                    </div>
                    <button type="submit" name="pay" class="btn btn-success btn-lg" id="payButton" disabled>
                        <i class="fas fa-paper-plane me-2"></i> To'lovni Amalga Oshirish
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Tasdiqlash modali -->
        <div class="modal fade" id="confirmationModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title"><i class="fas fa-check-circle me-2"></i> To'lovni Tasdiqlash</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body confirmation-modal">
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Quyidagi xodimlarga to'lov amalga oshirilmoqda. Ushbu amalni qaytarib bo'lmaydi.
                        </div>
                        
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>Xodim</th>
                                        <th class="text-end">To'lov miqdori</th>
                                        <th class="text-end">Qolgan balans</th>
                                    </tr>
                                </thead>
                                <tbody id="confirmationTableBody">
                                    <!-- JavaScript orqali to'ldiriladi -->
                                </tbody>
                                <tfoot class="table-active">
                                    <tr>
                                        <th>Jami:</th>
                                        <th class="text-end" id="confirmationTotal">0 so'm</th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times me-1"></i> Bekor Qilish
                        </button>
                        <button type="button" id="confirmPayment" class="btn btn-primary">
                            <i class="fas fa-check me-1"></i> Tasdiqlash
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- Bonus qo'shish modali -->
<div class="modal fade" id="bonusModal" tabindex="-1" aria-labelledby="bonusModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="" id="bonusForm">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="bonusModalLabel"><i class="fas fa-gift me-2"></i> Bonus Qo'shish</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="employeeSelect" class="form-label">Xodim</label>
                        <select class="form-select" id="employeeSelect" name="employee_id" required>
                            <option value="" selected disabled>Xodimni tanlang</option>
                            <?php foreach ($employees as $employee): ?>
                                <option value="<?= $employee['id'] ?>"><?= htmlspecialchars($employee['username']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="bonusAmount" class="form-label">Bonus miqdori</label>
                        <div class="input-group">
                            <input type="number" class="form-control" id="bonusAmount" 
                                   name="bonus_amount" min="1" required>
                            <span class="input-group-text">so'm</span>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="bonusReason" class="form-label">Bonus sababi</label>
                        <textarea class="form-control" id="bonusReason" name="bonus_reason" 
                                  rows="3" placeholder="Bonus berish sababini yozing..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Bekor Qilish
                    </button>
                    <button type="submit" name="add_bonus" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i> Qo'shish
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Elementlarni tanlash
    const checkboxes = document.querySelectorAll('.employee-checkbox');
    const amountInputs = document.querySelectorAll('.payment-amount');
    const totalPaymentSpan = document.getElementById('totalPayment');
    const payButton = document.getElementById('payButton');
    const paymentForm = document.getElementById('paymentForm');
    const confirmationModal = new bootstrap.Modal('#confirmationModal');
    
    // To'lov miqdorini hisoblash
    function calculatePayment() {
        let total = 0;
        let anySelected = false;
        
        checkboxes.forEach(checkbox => {
            const id = checkbox.dataset.id;
            const amountInput = document.getElementById(`amount_${id}`);
            
            if (checkbox.checked) {
                amountInput.disabled = false;
                amountInput.classList.remove('bg-light');
                anySelected = true;
                
                const amount = parseFloat(amountInput.value) || 0;
                total += amount;
                
                // Qolgan summani ko'rsatish
                const totalIncome = parseFloat(amountInput.dataset.total);
                const remaining = totalIncome - amount;
                document.getElementById(`remaining_${id}`).textContent = 
                    remaining.toLocaleString('ru-RU') + ' so\'m';
            } else {
                amountInput.disabled = true;
                amountInput.classList.add('bg-light');
                document.getElementById(`remaining_${id}`).textContent = '0 so\'m';
            }
        });
        
        // Jami summani yangilash
        totalPaymentSpan.textContent = total.toLocaleString('ru-RU');
        payButton.disabled = !anySelected;
    }
    
    // Har bir checkbox uchun hodisalar
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', calculatePayment);
    });
    
    // Har bir input uchun hodisalar
    amountInputs.forEach(input => {
        input.addEventListener('input', function() {
            if (!this.disabled) {
                const max = parseFloat(this.dataset.total);
                let value = parseFloat(this.value) || 0;
                
                if (value > max) {
                    this.value = max;
                    value = max;
                } else if (value < 0) {
                    this.value = 0;
                    value = 0;
                }
                
                calculatePayment();
            }
        });
    });
    
    // Formani yuborish
    paymentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const total = parseFloat(totalPaymentSpan.textContent.replace(/\s+/g, '')) || 0;
        if (total <= 0) {
            alert('Iltimos, kamida bitta xodimni tanlang va to\'lov miqdorini kiriting!');
            return;
        }
        
        // Tasdiqlash jadvalini to'ldirish
        const tableBody = document.getElementById('confirmationTableBody');
        tableBody.innerHTML = '';
        
        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const id = checkbox.dataset.id;
                const amountInput = document.getElementById(`amount_${id}`);
                const amount = parseFloat(amountInput.value) || 0;
                const totalIncome = parseFloat(amountInput.dataset.total);
                const remaining = totalIncome - amount;
                const username = amountInput.closest('tr').querySelector('td:nth-child(2)').textContent;
                
                tableBody.innerHTML += `
                    <tr>
                        <td>${username}</td>
                        <td class="text-end">${amount.toLocaleString('ru-RU')} so'm</td>
                        <td class="text-end">${remaining.toLocaleString('ru-RU')} so'm</td>
                    </tr>
                `;
            }
        });
        
        document.getElementById('confirmationTotal').textContent = 
            total.toLocaleString('ru-RU') + ' so\'m';
        
        confirmationModal.show();
    });
    
    // Tasdiqlash tugmasi
    document.getElementById('confirmPayment').addEventListener('click', function() {
    confirmationModal.hide();
    
    // Yangi form element yaratib, uni yuborish
    const hiddenForm = document.createElement('form');
    hiddenForm.method = 'POST';
    hiddenForm.action = '';
    
    // Tanlangan xodimlarni qo'shish
    document.querySelectorAll('.employee-checkbox:checked').forEach(checkbox => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_employees[]';
        input.value = checkbox.value;
        hiddenForm.appendChild(input);
        
        const amountInput = document.getElementById(`amount_${checkbox.dataset.id}`);
        const amount = document.createElement('input');
        amount.type = 'hidden';
        amount.name = `payment_amount[${checkbox.value}]`;
        amount.value = amountInput.value;
        hiddenForm.appendChild(amount);
    });
    
    // Submit tugmasi
    const submitInput = document.createElement('input');
    submitInput.type = 'hidden';
    submitInput.name = 'pay';
    submitInput.value = '1';
    hiddenForm.appendChild(submitInput);
    
    document.body.appendChild(hiddenForm);
    hiddenForm.submit();
});
    
    // Dastlabki holatni sozlash
    calculatePayment();
});
</script>

<?php
include '../includes/body.php';
?>