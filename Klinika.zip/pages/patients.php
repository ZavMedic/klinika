<?php
//session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
$title = "Bemorlar";
ob_start();

if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole();
$user_id = $_SESSION['user']['id'];

if ($role !== 'kassir' && $role !== 'rahbar' && $role !== 'hamshira') {
    die("Sizda bemor qo'shish uchun ruxsat yo'q!");
}
if (isset($_GET['search']) && strlen($_GET['search']) >= 3) {
    $term = trim($_GET['search']);

    // 1. Bazadan so‘rov bo‘yicha oxirgi bemorlar
    $stmt = $conn->prepare("
        SELECT p.full_name, p.birth_year, p.phone_number, p.created_at
        FROM patients p
        INNER JOIN (
            SELECT full_name, MAX(created_at) AS latest_time
            FROM patients
            WHERE full_name LIKE :term
            GROUP BY full_name
        ) latest ON p.full_name = latest.full_name AND p.created_at = latest.latest_time
        ORDER BY p.created_at DESC
        LIMIT 20
    ");
    $stmt->execute(['term' => '%' . $term . '%']);
    $rawResults = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2. Similar_text orqali o‘xshashlikni tekshirish
    $filtered = [];
    foreach ($rawResults as $row) {
        similar_text(mb_strtolower($term), mb_strtolower($row['full_name']), $percent);
// 40%dan yuqori bo'lsa taklif berilish
        if ($percent >= 40) {
            $filtered[] = [
                'full_name' => $row['full_name'],
                'birth_year' => $row['birth_year'],
                'phone_number' => $row['phone_number'],
                'similarity' => round($percent)
            ];
        }
    }

    // 3. O‘xshashlikka qarab saralash (ko‘proq o‘xshashlik birinchi bo‘lsin)
    usort($filtered, function($a, $b) {
        return $b['similarity'] <=> $a['similarity'];
    });

    // 4. Javob
    header('Content-Type: application/json');
    echo json_encode(array_slice($filtered, 0, 5)); // faqat 5 ta eng yaqin
    exit;
}


$message = "";

function updateStaffIncome($conn, $service_ids, $doctor_id, $nurse_id, $cashier_id, $paid_amount, $patient_id, $debt) {
    try {
        $total_service_price = 0;
        foreach ($service_ids as $service_id) {
            $stmt = $conn->prepare("SELECT price FROM services WHERE id = :service_id");
            $stmt->execute(['service_id' => $service_id]);
            $service = $stmt->fetch(PDO::FETCH_ASSOC);
            $total_service_price += $service['price'];
        }

        $discount_percentage = ($total_service_price > 0) ? (($total_service_price - $paid_amount) / $total_service_price) * 100 : 0;

        $doctor_income = 0;
        $nurse_income = 0;
        $kassir_income = 0;

        foreach ($service_ids as $service_id) {
            $stmt = $conn->prepare("SELECT price FROM services WHERE id = :service_id");
            $stmt->execute(['service_id' => $service_id]);
            $service_price = $stmt->fetch(PDO::FETCH_ASSOC)['price'];

// Default qiymat: ushbu service uchun doctor_id=6 va hamshira yo‘q bo‘lsa, user_id=13 ulushi doctor_id ga qo‘shiladi
            if ($doctor_id == 6 && !$nurse_id) {
                $stmt = $conn->prepare("SELECT percentage FROM staff_percentages WHERE service_id = :service_id AND user_id = 13");
                $stmt->execute(['service_id' => $service_id]);
                $hamshira_percent = $stmt->fetchColumn();

                if ($hamshira_percent) {
                    $income = ($service_price * $hamshira_percent / 100) * (1 - ($discount_percentage / 100));
                    $doctor_income += $income;
                    if (!$debt) {
                        $stmt = $conn->prepare("UPDATE users SET total_income = total_income + :income WHERE id = :doctor_id");
                        $stmt->execute(['income' => $income, 'doctor_id' => $doctor_id]);
                    }
                     // 2. patients jadvalidagi doctor_income ga ham qo‘shish
        $stmt = $conn->prepare("UPDATE patients SET doctor_income = doctor_income + :income WHERE id = :patient_id");
        $stmt->execute(['income' => $income, 'patient_id' => $patient_id]);
                }
            }
// user_id=13 va doctor_id=6 shu yergacha test qilishim kerak

//$stmt = $conn->prepare(
//                "SELECT user_id, percentage FROM staff_percentages WHERE service_id = :service_id AND user_id IN (:doctor_id, :nurse_id, :cashier_id)"
//            );
            
            $stmt = $conn->prepare("
    SELECT user_id, percentage 
    FROM staff_percentages 
    WHERE service_id = :service_id 
      AND (user_id = :doctor_id OR user_id = :nurse_id OR user_id = :cashier_id)
");
            $stmt->execute([
                'service_id' => $service_id,
                'doctor_id' => $doctor_id,
                'nurse_id' => $nurse_id,
                'cashier_id' => $cashier_id
            ]);
            $percentages = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($percentages as $percentage) {
                $user_id = $percentage['user_id'];
                $income = ($service_price * $percentage['percentage'] / 100) * (1 - ($discount_percentage / 100));

                if ($user_id == $doctor_id) {
                    $doctor_income += $income;
                } elseif ($user_id == $nurse_id) {
                    $nurse_income += $income;
                } elseif ($user_id == $cashier_id) {
                    $kassir_income += $income;
                }

                if (!$debt) {
                    $stmt = $conn->prepare("UPDATE users SET total_income = total_income + :income WHERE id = :user_id");
                    $stmt->execute(['income' => $income, 'user_id' => $user_id]);
                }
            }
        }

        $stmt = $conn->prepare(
            "UPDATE patients SET doctor_income = :doctor_income, nurse_income = :nurse_income, kassir_income = :kassir_income, discount_percentage = :discount_percentage WHERE id = :patient_id"
        );
        $stmt->execute([
            'doctor_income' => $doctor_income,
            'nurse_income' => $nurse_income,
            'kassir_income' => $kassir_income,
            'discount_percentage' => $discount_percentage,
            'patient_id' => $patient_id
        ]);
    } catch (Exception $e) {
        throw new Exception("Daromadlarni hisoblashda xatolik: " . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        if (!canAddPatient()) {
            throw new Exception("Iltimos, 10 soniya kutib turing!");
        }

        $full_name = trim($_POST['full_name']);
        $birth_year = intval($_POST['birth_year']);
        $doctor_id = !empty($_POST['doctor_id']) ? intval($_POST['doctor_id']) : null;
        $nurse_id = !empty($_POST['nurse_id']) ? intval($_POST['nurse_id']) : null;
        $price = floatval($_POST['price']);
        $debt = isset($_POST['debt']) ? 1 : 0;
//        $payment_method = $_POST['payment_method'];
        $payment_method = $debt ? 'qarz' : $_POST['payment_method'];
//        $phone_number = $debt ? trim($_POST['phone_number']) : null;
        $phone_number = trim($_POST['phone_number']);
        $has_medicine = isset($_POST['has_medicine']) ? 1 : 0;
        $medicine_price = $has_medicine ? floatval($_POST['medicine_price']) : 0;

        if (empty($_POST['service_ids']) || !is_array($_POST['service_ids'])) {
            throw new Exception("Kamida bitta xizmat turini tanlang!");
        }
        $service_ids = $_POST['service_ids'];

        if (empty($full_name) || empty($birth_year) || empty($price) || empty($payment_method)) {
            throw new Exception("Barcha maydonlarni to'ldiring!");
        }

        if ($has_medicine && $medicine_price <= 0) {
            throw new Exception("Iltimos, dori narxini to'g'ri kiriting!");
        }

        if ($debt && (empty($phone_number) || !preg_match('/^\+998\d{9}$/', $phone_number))) {
            throw new Exception("Telefon raqam noto'g'ri formatda. Iltimos, +998901234567 formatida kiriting.");
        }

        // Bir xil bemorni tekshirish
        $checkStmt = $conn->prepare("
            SELECT COUNT(*) as count 
            FROM patients 
            WHERE full_name = :full_name 
            AND price = :price 
            AND DATE(created_at) = CURDATE()
        ");
        $checkStmt->execute(['full_name' => $full_name, 'price' => $price]);
        $duplicateCount = $checkStmt->fetch(PDO::FETCH_ASSOC)['count'];

        if ($duplicateCount > 0 && !isset($_POST['confirmed_duplicate'])) {
            $_SESSION['duplicate_patient'] = [
                'full_name' => $full_name,
                'birth_year' => $birth_year,
                'doctor_id' => $doctor_id,
                'nurse_id' => $nurse_id,
                'price' => $price,
                'payment_method' => $payment_method,
                'debt' => $debt,
                'phone_number' => $phone_number,
                'has_medicine' => $has_medicine,
                'medicine_price' => $medicine_price,
                'service_ids' => $service_ids
            ];
            $_SESSION['message'] = "Diqqat! Siz bugun bu bemorni kiritgansiz. Iltimos, tasdiqlang!";
            redirect('patients.php');
            exit;
        }

        // Bemorni qo'shish
        $stmt = $conn->prepare("INSERT INTO patients 
    (full_name, birth_year, doctor_id, nurse_id, price, payment_method, debt, cashier_id, phone_number, created_at) 
    VALUES 
    (:full_name, :birth_year, :doctor_id, :nurse_id, :price, :payment_method, :debt, :cashier_id, :phone_number, NOW())");

$stmt->execute([
    'full_name' => $full_name,
    'birth_year' => $birth_year,
    'doctor_id' => $doctor_id,
    'nurse_id' => $nurse_id,
    'price' => $price,
    'payment_method' => $payment_method,
    'debt' => $debt,
    'cashier_id' => $user_id,
    'phone_number' => $phone_number
]);

        $patient_id = $conn->lastInsertId();

        // Xizmat turlarini qo'shish
        foreach ($service_ids as $service_id) {
            $stmt = $conn->prepare("INSERT INTO patient_services (patient_id, service_id) VALUES (:patient_id, :service_id)");
            $stmt->execute(['patient_id' => $patient_id, 'service_id' => $service_id]);
        }

        // Dori xarajatini qo'shish
        if ($has_medicine) {
            $stmt = $conn->prepare("INSERT INTO expenses 
                (amount, type, comment, created_by, patient_id, created_at) 
                VALUES 
                (:amount, 'Dorilar', 'Bemor uchun dori xarajati', :created_by, :patient_id, NOW())");
            $stmt->execute([
                'amount' => $medicine_price,
                'created_by' => $user_id,
                'patient_id' => $patient_id
            ]);
        }

        updateStaffIncome($conn, $service_ids, $doctor_id, $nurse_id, $user_id, $price, $patient_id, $debt);
        
        // 4% bonus faqat hamshiraga, agar u bemorni qo‘shgan bo‘lsa
if (!$debt && $role === 'hamshira') {
    $hamshira_id = $user_id;
    $bonus_income = round($price * 0.04, 2); // 4%

    // Hamshira shu bemorga xizmat ko‘rsatganmi yoki yo‘q — tekshiramiz
    if ($hamshira_id == $nurse_id) {
        // xizmat ham qilgan => 40% allaqachon updateStaffIncome() orqali qo‘shilgan
        // endi 4% bonusni faqat cashier_income ustuniga yozamiz
        $stmt = $conn->prepare("UPDATE users SET total_income = total_income + :income WHERE id = :id");
        $stmt->execute(['income' => $bonus_income, 'id' => $hamshira_id]);

//        $stmt = $conn->prepare("UPDATE patients SET kassir_income = kassir_income + :bonus WHERE id = :pid");
        $stmt = $conn->prepare("UPDATE patients SET kassir_income = :bonus WHERE id = :pid");
        $stmt->execute(['bonus' => $bonus_income, 'pid' => $patient_id]);
    } else {
        // xizmat ko‘rsatmagan, faqat bemor qo‘shgan
        $stmt = $conn->prepare("UPDATE users SET total_income = total_income + :income WHERE id = :id");
        $stmt->execute(['income' => $bonus_income, 'id' => $hamshira_id]);

        $stmt = $conn->prepare("UPDATE patients SET kassir_income = :bonus WHERE id = :pid");
        $stmt->execute(['bonus' => $bonus_income, 'pid' => $patient_id]);
    }
}



        if ($patient_id) {
            $stmt = $conn->prepare("
                SELECT p.*, 
                       GROUP_CONCAT(DISTINCT s.name SEPARATOR ', ') AS service_names,
                       (SELECT SUM(amount) FROM expenses WHERE patient_id = p.id AND type = 'Dorilar') AS medicine_cost,
                       d.username AS doctor_name,
                       n.username AS nurse_name,
                       c.username AS cashier_name,
                       d.telegram_id AS doctor_telegram_id,
                       n.telegram_id AS nurse_telegram_id,
                       c.telegram_id AS cashier_telegram_id
                FROM patients p
                LEFT JOIN patient_services ps ON p.id = ps.patient_id
                LEFT JOIN services s ON ps.service_id = s.id
                LEFT JOIN users d ON p.doctor_id = d.id
                LEFT JOIN users n ON p.nurse_id = n.id
                LEFT JOIN users c ON p.cashier_id = c.id
                WHERE p.id = :patient_id
                GROUP BY p.id
            ");
            $stmt->execute(['patient_id' => $patient_id]);
            $patient = $stmt->fetch(PDO::FETCH_ASSOC);

            // Rahbarga xabar yuborish
            $admin_id = $conn->query("SELECT id FROM users WHERE role = 'rahbar' LIMIT 1")->fetchColumn();
            if ($admin_id) {
                $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = :admin_id AND telegram_id IS NOT NULL");
                $stmt->execute(['admin_id' => $admin_id]);
                $admin = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($admin && !empty($admin['telegram_id'])) {
                    $message = "🆔 <b>Yangi bemor qo'shildi</b>\n\n";
                    $message .= "👤 <b>Ism:</b> #" . htmlspecialchars($patient['full_name']) . "\n";
                    $message .= "📅 <b>Tug'ilgan yili:</b> " . $patient['birth_year'] . "\n";
                    $message .= "🏥 <b>Xizmatlar:</b> " . ($patient['service_names'] ?? 'Xizmatlar ko\'rsatilmagan') . "\n";
//                    $message .= "👨‍⚕️ <b>Shifokor:</b> #" . ($patient['doctor_name'] ?? 'Tanlanmagan') . "\n";

if (($patient['doctor_id'] ?? null) != 8) {
    $message .= "👨‍⚕️ <b>Shifokor:</b> #" . ($patient['doctor_name'] ?? 'Tanlanmagan') . "\n";
}
                    if ($patient['nurse_name']) {
                        $message .= "👩‍⚕️ <b>Hamshira:</b> #" . $patient['nurse_name'] . "\n";
                    }
                    
                    $message .= "💰 <b>Narxi:</b> " . number_format($patient['price'], 0, ',', ' ') . " so'm\n";
                    $message .= "💳 <b>To'lov usuli:</b> " . ucfirst($patient['payment_method']) . "\n";
                    
                    if ($patient['debt']) {
                        $message .= "⚠️ <b>Holat:</b> QARZ (" . ($patient['phone_number'] ?? 'telefon raqamsiz') . ")\n";
                    } else {
                        $message .= "✅ <b>Holat:</b> To'langan\n";
                    }
                    
                    if ($patient['medicine_cost'] > 0) {
                        $message .= "💊 <b>Dori narxi:</b> " . number_format($patient['medicine_cost'], 0, ',', ' ') . " so'm\n";
                        $message .= "🧾 <b>Jami:</b> " . number_format($patient['price'] + $patient['medicine_cost'], 0, ',', ' ') . " so'm\n";
                    }
                    
                    $message .= "⏰ <b>Sana:</b> " . $patient['created_at'] . "\n";
                    $message .= "📝 <b>Kassir:</b> " . ($patient['cashier_name'] ?? 'Noma\'lum') . "\n";
                    
                    $result = sendTelegramMessage($admin['telegram_id'], $message, 'HTML');
                    if ($result === false) {
                        error_log("Rahbarga xabar yuborishda xatolik: " . print_r($admin, true));
                    }
                }
            }
            
            // Be'morga xabar yuborish
if (!empty($patient['phone_number'])) {
    $clean_phone = str_replace('+', '', $patient['phone_number']);

    $stmt = $conn->prepare("SELECT telegram_id FROM users_unknown WHERE REPLACE(phone, '+', '') = ?");
    $stmt->execute([$clean_phone]);
    $unknown_user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($unknown_user && !empty($unknown_user['telegram_id'])) {
        $msg = "🧾 <b>Siz bugun qabulda bo'ldingiz</b>\n";
        $msg .= "👤 <b>Ism:</b> " . htmlspecialchars($patient['full_name']) . "\n";
        $msg .= "📆 <b>Yil:</b> " . $patient['birth_year'] . "\n";
        $msg .= "🏥 <b>Xizmatlar:</b> " . ($patient['service_names'] ?? 'Yo‘q') . "\n";
if (($patient['doctor_id'] ?? null) != 8) {
    $message .= "👨‍⚕️ <b>Shifokor:</b> " . ($patient['doctor_name'] ?? 'Tanlanmagan') . "\n";
}
        if ($patient['nurse_name']) {
            $msg .= "👩‍⚕️ <b>Hamshira:</b> #" . $patient['nurse_name'] . "\n";
        }
        $msg .= "💰 <b>To‘lov:</b> " . number_format($patient['price'], 0, ',', ' ') . " so‘m\n";

        if ($patient['medicine_cost'] > 0) {
            $msg .= "💊 <b>Dori narxi:</b> " . number_format($patient['medicine_cost'], 0, ',', ' ') . " so‘m\n";
            $msg .= "🧾 <b>Jami:</b> " . number_format($patient['price'] + $patient['medicine_cost'], 0, ',', ' ') . " so‘m\n";
        }

        if ($patient['debt']) {
            $msg .= "⚠️ <b>Holat:</b> QARZ\n";
        } else {
            $msg .= "✅ <b>Holat:</b> To‘langan\n";
        }

        $msg .= "🕒 <b>Vaqt:</b> " . $patient['created_at'];

        sendTelegramMessage($unknown_user['telegram_id'], $msg, 'HTML');
    }
}

            // Shifokorga xabar yuborish
            if (!empty($patient['doctor_telegram_id'])) {
                $message = "👨‍⚕️ <b>Sizga yangi #bemor biriktirildi</b>\n\n";
                $message .= "👤 <b>Ism:</b> " . htmlspecialchars($patient['full_name']) . "\n";
                $message .= "📅 <b>Tug'ilgan yili:</b> " . $patient['birth_year'] . "\n";
                $message .= "🏥 <b>Xizmatlar:</b> " . ($patient['service_names'] ?? 'Xizmatlar ko\'rsatilmagan') . "\n";
                $message .= "💰 <b>Narxi:</b> " . number_format($patient['price'], 0, ',', ' ') . " so'm\n";
                
                if ($patient['debt']) {
                    $message .= "⚠️ <b>Holat:</b> QARZ\n";
                    $message .= "📱 <b>Telefon:</b> " . ($patient['phone_number'] ?? 'Ko\'rsatilmagan') . "\n";
                }
                
                if ($patient['nurse_name']) {
                    $message .= "👩‍⚕️ <b>Hamshira:</b> #" . $patient['nurse_name'] . "\n";
                }
                
                $message .= "⏰ <b>Sana:</b> " . $patient['created_at'] . "\n";
                
                $result = sendTelegramMessage($patient['doctor_telegram_id'], $message, 'HTML');
                if ($result === false) {
                    error_log("Shifokorga xabar yuborishda xatolik. Doctor ID: {$patient['doctor_id']}");
                }
            }
            
            // Hamshiraga xabar yuborish
            if (!empty($patient['nurse_telegram_id'])) {
                $message = "👩‍⚕️ <b>Sizga yangi #bemor biriktirildi</b>\n\n";
                $message .= "👤 <b>Ism:</b> " . htmlspecialchars($patient['full_name']) . "\n";
                $message .= "📅 <b>Tug'ilgan yili:</b> " . $patient['birth_year'] . "\n";
                
                //Shifokor id=8 ko'rsatilmasin
if (($patient['doctor_id'] ?? null) != 8) {
    $message .= "👨‍⚕️ <b>Shifokor:</b> " . ($patient['doctor_name'] ?? 'Tanlanmagan') . "\n";
}
                $message .= "🏥 <b>Xizmatlar:</b> " . ($patient['service_names'] ?? 'Xizmatlar ko\'rsatilmagan') . "\n";
                $message .= "💰 <b>Narxi:</b> " . number_format($patient['price'], 0, ',', ' ') . " so'm\n";
                
                if ($patient['debt']) {
                    $message .= "⚠️ <b>Holat:</b> QARZ\n";
                    $message .= "📱 <b>Telefon:</b> " . ($patient['phone_number'] ?? 'Ko\'rsatilmagan') . "\n";
                }
                $message .= "⏰ <b>Sana:</b> " . $patient['created_at'] . "\n";
                
                $result = sendTelegramMessage($patient['nurse_telegram_id'], $message, 'HTML');
                if ($result === false) {
                    error_log("Hamshiraga xabar yuborishda xatolik. Nurse ID: {$patient['nurse_id']}");
                }
            }
        }

        setLastPatientAddedTime();
        $_SESSION['message'] = "Bemor muvaffaqiyatli qo'shildi!";
        redirect('patients.php');

    } catch (Exception $e) {
        $message = $e->getMessage();
    }
}

if (!empty($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}

$doctors = $conn->query("SELECT * FROM users WHERE role = 'shifokor' AND status = 'faol'")->fetchAll(PDO::FETCH_ASSOC);
$nurses = $conn->query("SELECT * FROM users WHERE role = 'hamshira' AND status = 'faol'")->fetchAll(PDO::FETCH_ASSOC);

$patients = $conn->query("
    SELECT p.*, 
           GROUP_CONCAT(s.name SEPARATOR ', ') AS service_names, 
           u.username AS doctor_name, 
           u2.username AS nurse_name, 
           u3.username AS cashier_name,
           (SELECT SUM(amount) FROM expenses WHERE patient_id = p.id AND type = 'Dorilar') AS medicine_cost
    FROM patients p 
    LEFT JOIN patient_services ps ON p.id = ps.patient_id 
    LEFT JOIN services s ON ps.service_id = s.id 
    LEFT JOIN users u ON p.doctor_id = u.id 
    LEFT JOIN users u2 ON p.nurse_id = u2.id 
    LEFT JOIN users u3 ON p.cashier_id = u3.id 
    WHERE DATE(p.created_at) = CURDATE() 
    GROUP BY p.id 
    ORDER BY p.created_at DESC 
    LIMIT 50
")->fetchAll(PDO::FETCH_ASSOC);

$content = ob_get_clean();
include '../includes/head.php';
?>

<style>
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    .total-price-container {
        background-color: #e9ecef;
        padding: 10px 15px;
        border-radius: 5px;
        margin-bottom: 15px;
        text-align: center;
    }
    .time-column {
        white-space: nowrap;
    }
    .form-container {
        background-color: #f8f9fa;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        margin-bottom: 30px;
    }
    .form-label {
        font-weight: 600;
        color: #495057;
    }
    .form-control, .form-select {
        border-radius: 5px;
        padding: 10px;
        border: 1px solid #ced4da;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    }
    .form-control:focus, .form-select:focus {
        border-color: #80bdff;
        box-shadow: 0 0 0 0.2rem rgba(0,123,255,0.25);
    }
    .form-check-input {
        width: 1.2em;
        height: 1.2em;
        margin-top: 0.2em;
    }
    .form-check-label {
        margin-left: 5px;
    }
    .total-price-display {
        font-size: 1.2rem;
        font-weight: 700;
        color: #28a745;
    }
    .table th {
        background-color: #4e73df;
        color: white;
        font-weight: 600;
    }
    .table-hover tbody tr:hover {
        background-color: rgba(78, 115, 223, 0.1);
    }
    .badge {
        font-size: 0.9rem;
        padding: 5px 10px;
        border-radius: 20px;
    }
    .btn-primary {
        background-color: #4e73df;
        border-color: #4e73df;
        padding: 10px 20px;
        font-weight: 600;
    }
    .btn-secondary {
        padding: 10px 20px;
        font-weight: 600;
    }
    @media (max-width: 768px) {
        .form-container {
            padding: 15px;
        }
        .form-control, .form-select {
            padding: 8px;
        }
        .btn {
            width: 100%;
            margin-bottom: 10px;
        }
    }
</style>

<div class="container">
<?php if (in_array(getUserRole(), ['kassir', 'rahbar'])): ?>
    <div class="page-header">
        <h1>Bemorlar</h1>
        <a href="patients_management.php" class="btn btn-secondary">Bemorlarni boshqarish</a>
    </div>
<?php endif; ?>

    
    <?php if ($message): ?>
        <div class="alert alert-info alert-dismissible fade show">
            <?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="form-container">
        <form method="POST" id="patientForm">
            <?php if (isset($_SESSION['duplicate_patient'])): ?>
        <!--
                <div class="alert alert-warning mb-4">
                    <strong>Diqqat!</strong> Siz bugun bir xil bemorni qayta kiritmoqchisiz. Iltimos, ma'lumotlarni tekshirib, tasdiqlang.
                </div> 
        -->
                <input type="hidden" name="confirmed_duplicate" value="1">
            <?php endif; ?>
            
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="mb-3 position-relative"> <!-- <== bu yerga class qo‘shildi -->
    <label for="full_name" class="form-label">Familiya Ism</label>
    <input type="text" name="full_name" class="form-control" required 
           value="<?= isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : '' ?>">
</div>

                    
                    <div class="mb-3">
                        <label for="birth_year" class="form-label">Tug'ilgan yili</label>
                        <input type="number" name="birth_year" class="form-control" required min="1900" max="<?= date('Y')?>" 
                               value="<?= isset($_POST['birth_year']) ? htmlspecialchars($_POST['birth_year']) : '' ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="phone_number" class="form-label">Telefon raqami</label>
                        <input type="text" name="phone_number" class="form-control" placeholder="+998" id="phoneInput"
                               value="<?= isset($_POST['phone_number']) ? htmlspecialchars($_POST['phone_number']) : '' ?>">
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="doctor_id" class="form-label">Shifokor</label>
                       <select name="doctor_id" id="doctor_id" class="form-select" required>
    <option value="">Tanlang...</option>
    <?php foreach ($doctors as $doctor): ?>
        <option value="<?php echo $doctor['id']; ?>" 
            <?php echo (isset($_POST['doctor_id']) && $_POST['doctor_id'] == $doctor['id'] ? 'selected' : ''); ?>>
            <?php echo htmlspecialchars($doctor['username']); ?>
        </option>
    <?php endforeach; ?>
</select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="nurse_id" class="form-label">Hamshira (ixtiyoriy)</label>
<select name="nurse_id" class="form-select">
    <option value="">Tanlanmagan</option>
    <?php foreach ($nurses as $nurse): ?>
        <option value="<?= $nurse['id'] ?>" 
            <?= (isset($_POST['nurse_id']) && $_POST['nurse_id'] == $nurse['id']) ? 'selected' : '' ?>>
            <?= htmlspecialchars($nurse['username']) ?>
        </option>
    <?php endforeach; ?>
</select>

                    </div>
                </div>
                
                <div class="col-12">
                    <label class="form-label">Xizmat turlari</label>
                    <div class="mb-3 border p-3 rounded" id="servicesContainer">
                        <div class="text-muted">Shifokor tanlangandan keyin xizmat turlari ko'rinadi</div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <label for="price" class="form-label">Xizmatlar narxi</label>
                    <input type="number" name="price" class="form-control" required id="price" min="0" step="1000"
                           value="<?= isset($_POST['price']) ? htmlspecialchars($_POST['price']) : '' ?>">
                </div>
                
                <div class="col-md-4">
                    <label class="form-label">To'lov usuli</label>
                    <select name="payment_method" class="form-select" required>
                        <option value="naqt" <?= (isset($_POST['payment_method']) && $_POST['payment_method'] == 'naqt') ? 'selected' : '' ?>>Naqt</option>
                        <option value="terminal" <?= (isset($_POST['payment_method']) && $_POST['payment_method'] == 'terminal') ? 'selected' : '' ?>>Terminal</option>
                        <option value="click" <?= (isset($_POST['payment_method']) && $_POST['payment_method'] == 'click') ? 'selected' : '' ?>>Click</option>
                    </select>
                </div>
                
                <div class="col-md-4">
                    <div class="d-flex align-items-center h-100">
                        <div class="form-check form-switch">
                            <input type="checkbox" name="debt" class="form-check-input" id="debt" role="switch"
<?= (isset($_POST['debt']) && $_POST['debt'] ? 'checked' : '') ?>
                            <label class="form-check-label" for="debt">Qarz</label>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="form-check">
                        <input type="checkbox" name="has_medicine" class="form-check-input" id="hasMedicine"
                            <?= (isset($_POST['has_medicine']) && $_POST['has_medicine']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="hasMedicine">Dorilar</label>
                    </div>
                    
                    <div class="mb-3 mt-2" id="medicineField" style="<?= (isset($_POST['has_medicine']) && $_POST['has_medicine']) ? '' : 'display: none;' ?>">
                        <label for="medicine_price" class="form-label">Dori narxi (so'mda)</label>
                        <input type="number" name="medicine_price" class="form-control" id="medicinePrice" min="0" step="1000"
                               value="<?= isset($_POST['medicine_price']) ? htmlspecialchars($_POST['medicine_price']) : '' ?>">
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="total-price-container">
                        <strong>Umumiy narx:</strong> 
                        <span class="total-price-display" id="totalPriceDisplay">0</span> so'm
                    </div>
                </div>
                
                <div class="col-12">
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">Bemor qo'shish</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <h2 class="mt-5 mb-3">Bugungi bemorlar 
        <span class="badge bg-primary"><?= count($patients) ?> ta</span>
    </h2>
    
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Ism</th>
                    <th>Yil</th>
                    <th>Tel</th>
                    <th>Xizmatlar</th>
                    <th>Shifokor</th>
                    <th>Hamshira</th>
                    <th>Narxi</th>
                    <th>To'lov</th>
                    <th>Holat</th>
                    <th class="time-column">Vaqt</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($patients)): ?>
                    <tr>
                        <td colspan="10" class="text-center py-4 text-muted">Bugun bemorlar qo'shilmagan</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($patients as $index => $patient): 
                        $total_price = $patient['price'] + ($patient['medicine_cost'] ?? 0);
                        $status_class = $patient['debt'] ? 'bg-warning' : 'bg-success';
                        $status_text = $patient['debt'] ? 'Qarz' : 'To\'langan';
                        $created_time = date('H:i', strtotime($patient['created_at']));
                    ?>
                        <tr>
                            <td><?= $index + 1 ?></td>
                            <td><?= htmlspecialchars($patient['full_name']) ?></td>
                            <td><?= $patient['birth_year'] ?></td>
                                    <td>
                                        <?php if (!empty($patient['phone_number'])): ?>
                                            <a href="tel:<?= $patient['phone_number'] ?>" class="text-decoration-none">
                                                <?= formatPhoneNumber($patient['phone_number']) ?>
                                            </a>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    
                            <td><?= $patient['service_names'] ?? '-' ?></td>
                            <td><?= $patient['doctor_name'] ?? '-' ?></td>
                            <td><?= $patient['nurse_name'] ?? '-' ?></td>
                            <td class="text-end">
                                <?= number_format($patient['price'], 0, ',', ' ') ?> so'm
                                <?php if ($patient['medicine_cost'] > 0): ?>
                                    <br><small class="text-muted">+ <?= number_format($patient['medicine_cost'], 0, ',', ' ') ?> so'm dori</small>
                                    <br><strong>Jami: <?= number_format($total_price, 0, ',', ' ') ?> so'm</strong>
                                <?php endif; ?>
                            </td>
                            <td><?= ucfirst($patient['payment_method']) ?></td>
                            <td><span class="badge <?= $status_class ?>"><?= $status_text ?></span></td>
                            <td class="time-column"><?= $created_time ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
// Bir xil bemorni tekshirish funksiyasi
async function checkDuplicatePatient(fullName, price) {
    try {
        const response = await fetch(`../includes/check_duplicate_patient.php?full_name=${encodeURIComponent(fullName)}&price=${price}`);
        const data = await response.json();
        
        if (data.exists) {
            return {
                exists: true,
                patient: data.patient
            };
        }
        return { exists: false };
    } catch (error) {
        console.error('Xatolik:', error);
        return { exists: false };
    }
}

// Dori maydonini boshqarish
function toggleMedicineField(checkbox) {
    const medicineField = document.getElementById('medicineField');
    const medicinePrice = document.getElementById('medicinePrice');
    
    if (checkbox.checked) {
        medicineField.style.display = 'block';
        medicinePrice.setAttribute('required', true);
    } else {
        medicineField.style.display = 'none';
        medicinePrice.removeAttribute('required');
        medicinePrice.value = '';
    }
    updateTotalPrice();
}

// Umumiy narxni hisoblash
function updateTotalPrice() {
    const servicePrice = parseFloat(document.getElementById('price').value) || 0;
    const medicinePrice = parseFloat(document.getElementById('medicinePrice').value) || 0;
    const total = servicePrice + medicinePrice;
    
    document.getElementById('totalPriceDisplay').textContent = 
        total.toLocaleString('uz-UZ', {maximumFractionDigits: 0});
}

// Telefon raqamini formatlash
document.getElementById('phoneInput').addEventListener('input', function(e) {
    let value = this.value.replace(/[^0-9+]/g, '');
    
    if (!value.startsWith('+998')) {
        value = '+998' + value.replace(/^\+/, '');
    }
    
    if (value.length > 13) {
        value = value.substring(0, 13);
    }
    
    this.value = value;
});

// Shifokor tanlanganda xizmat turlarini yuklash
document.getElementById('doctor_id').addEventListener('change', function() {
    const doctorId = this.value;
    const servicesContainer = document.getElementById('servicesContainer');
    const priceInput = document.getElementById('price');

    if (doctorId) {
        fetch(`../includes/get_doctor_services.php?doctor_id=${doctorId}`)
            .then(response => response.json())
            .then(data => {
                servicesContainer.innerHTML = '';
                let totalPrice = 0;

                if (data.length === 0) {
                    servicesContainer.innerHTML = '<div class="text-muted">Ushbu shifokor uchun xizmat turlari topilmadi</div>';
                    return;
                }

                data.forEach(service => {
                    const div = document.createElement('div');
                    div.className = 'form-check mb-2';
                    div.innerHTML = `
                        <input type="checkbox" name="service_ids[]" value="${service.id}" 
                               class="form-check-input service-checkbox" 
                               id="service_${service.id}" 
                               data-price="${service.price}"
                               <?php 
                               if (isset($_POST['service_ids']) && is_array($_POST['service_ids'])) {
                                   echo in_array($service['id'], $_POST['service_ids']) ? 'checked' : '';
                               }
                               ?>>
                        <label class="form-check-label" for="service_${service.id}">
                            ${service.name} (${service.price.toLocaleString('uz-UZ')} so'm)
                        </label>
                    `;
                    servicesContainer.appendChild(div);
                });

                document.querySelectorAll('.service-checkbox').forEach(checkbox => {
                    checkbox.addEventListener('change', () => {
                        totalPrice = 0;
                        document.querySelectorAll('.service-checkbox:checked').forEach(checkedBox => {
                            totalPrice += parseFloat(checkedBox.dataset.price);
                        });
                        priceInput.value = totalPrice;
                        updateTotalPrice();
                    });
                });

                // Agar oldindan tanlangan xizmatlar bo'lsa, narxni hisoblash
                if (document.querySelectorAll('.service-checkbox:checked').length > 0) {
                    totalPrice = 0;
                    document.querySelectorAll('.service-checkbox:checked').forEach(checkedBox => {
                        totalPrice += parseFloat(checkedBox.dataset.price);
                    });
                    priceInput.value = totalPrice;
                    updateTotalPrice();
                }
            })
            .catch(error => {
                console.error('Xatolik:', error);
                servicesContainer.innerHTML = '<div class="text-danger">Xizmat turlarini yuklashda xatolik yuz berdi</div>';
            });
    } else {
        servicesContainer.innerHTML = '<div class="text-muted">Shifokor tanlangandan keyin xizmat turlari ko\'rinadi</div>';
        priceInput.value = '';
        updateTotalPrice();
    }
});

// Formani yuborishdan oldin tekshirish
document.getElementById('patientForm').addEventListener('submit', async function(e) {
    const debtCheckbox = document.getElementById('debt');
    if (debtCheckbox.checked) {
        // Qarz holatida payment_method ni 'qarz' qilib o'rnatamiz
        const hiddenPaymentMethod = document.createElement('input');
        hiddenPaymentMethod.type = 'hidden';
        hiddenPaymentMethod.name = 'payment_method';
        hiddenPaymentMethod.value = 'qarz';
        this.appendChild(hiddenPaymentMethod);
        
        // Asl select elementini disable qilamiz
        document.querySelector('select[name="payment_method"]').disabled = true;
    }
    const phoneInput = document.getElementById('phoneInput');
    const hasMedicine = document.getElementById('hasMedicine');
    const medicinePrice = document.getElementById('medicinePrice');
    const fullName = document.querySelector('input[name="full_name"]').value.trim();
    const price = document.querySelector('input[name="price"]').value;
    let isValid = true;

    if (debtCheckbox.checked) {
        if (!phoneInput.value) {
            alert("Iltimos, qarz uchun telefon raqamini kiriting!");
            isValid = false;
        } else if (!/^\+998\d{9}$/.test(phoneInput.value)) {
            alert("Telefon raqam noto'g'ri formatda. Iltimos, +998901234567 formatida kiriting.");
            isValid = false;
        }
    }

    if (hasMedicine.checked && (!medicinePrice.value || parseFloat(medicinePrice.value) <= 0)) {
        alert("Iltimos, dori narxini to'g'ri kiriting!");
        isValid = false;
    }

    // Bir xil bemorni tekshirish
    if (isValid && fullName && price) {
        const duplicateCheck = await checkDuplicatePatient(fullName, price);
        if (duplicateCheck.exists && !document.querySelector('input[name="confirmed_duplicate"]')) {
            const duplicate = duplicateCheck.patient;
            const duplicateTime = duplicate.time;
            const duplicatePaymentMethod = duplicate.payment_method === 'naqt' ? 'naqt' : 
                                         duplicate.payment_method === 'terminal' ? 'terminal' : 'click';
            const duplicateDebtStatus = duplicate.debt ? 'qarz' : 'to\'langan';
            
            if (!confirm(`Diqqat! Siz bugun soat ${duplicateTime} da "${fullName}" bemorni  <b>${price}</b> so'm ${duplicatePaymentMethod} to'lov usuli bilan kiritgansiz. Yana qayta kiritmoqchimisiz?`)) {
                isValid = false;
                e.preventDefault();
            }
        }
    }

    if (!isValid) {
        e.preventDefault();
    }
});

// Dori checkbox va narx maydonlarini kuzatish
document.getElementById('hasMedicine').addEventListener('change', function() {
    toggleMedicineField(this);
});
document.getElementById('price').addEventListener('input', updateTotalPrice);
document.getElementById('medicinePrice').addEventListener('input', updateTotalPrice);

// Qarz checkbox uchun telefon maydonini majburiy qilish
document.getElementById('debt').addEventListener('change', function() {
    const phoneInput = document.getElementById('phoneInput');
    if (this.checked) {
        phoneInput.setAttribute('required', true);
        if (!phoneInput.value) {
            phoneInput.value = '+998';
        }
    } else {
        phoneInput.removeAttribute('required');
    }
});

// Agar oldindan tanlangan xizmatlar bo'lsa, ularni yuklash
<?php if (isset($_POST['doctor_id']) && !empty($_POST['doctor_id'])): ?>
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('doctor_id').dispatchEvent(new Event('change'));
});
<?php endif; ?>

// Umumiy narxni dastlabki hisoblash
document.addEventListener('DOMContentLoaded', function() {
    updateTotalPrice();
    
    <?php if (isset($_POST['has_medicine']) && $_POST['has_medicine']): ?>
    document.getElementById('hasMedicine').dispatchEvent(new Event('change'));
    <?php endif; ?>
});

//avtopoisk tizimi bemor 3 harfi yozilganda chiqaradi
const fullNameInput = document.querySelector('input[name="full_name"]');
const birthYearInput = document.querySelector('input[name="birth_year"]');
const phoneInput = document.querySelector('input[name="phone_number"]');

let suggestionBox;

fullNameInput.addEventListener('input', function () {
    const value = this.value.trim();
    if (value.length < 3) return;

    fetch(`patients.php?search=${encodeURIComponent(value)}`)
        .then(res => res.json())
        .then(data => {
            closeSuggestionBox();
            if (data.length > 0) {
                suggestionBox = document.createElement('ul');
                suggestionBox.style.position = 'absolute';
                suggestionBox.style.zIndex = '1000';
                suggestionBox.style.backgroundColor = '#fff';
                suggestionBox.style.border = '1px solid #ccc';
                suggestionBox.style.width = fullNameInput.offsetWidth + 'px';
                suggestionBox.classList.add('list-group', 'mt-1');

                data.forEach(item => {
                    const li = document.createElement('li');
//                    li.textContent = `${item.full_name} (${item.birth_year}) – ${item.similarity}% o‘xshashlik`;
                    li.textContent = `${item.full_name} (${item.birth_year})`;
                    li.classList.add('list-group-item', 'list-group-item-action');
                    li.addEventListener('click', () => {
                        fullNameInput.value = item.full_name;
                        birthYearInput.value = item.birth_year;
                        phoneInput.value = item.phone_number;
                        closeSuggestionBox();
                    });
                    suggestionBox.appendChild(li);
                });

                fullNameInput.parentNode.appendChild(suggestionBox);
            }
        });
});

function closeSuggestionBox() {
    if (suggestionBox) {
        suggestionBox.remove();
        suggestionBox = null;
    }
}

document.addEventListener('click', function (e) {
    if (e.target !== fullNameInput && suggestionBox && !suggestionBox.contains(e.target)) {
        closeSuggestionBox();
    }
});

// sterit fullname to'g'ri yozilishi uchun
fullNameInput.addEventListener('blur', function () {
    this.value = this.value
        .replace(/[0-9]/g, '')                           // Raqamlarni o‘chir
        .replace(/[’‘ʻʼ´`"“”\\/]/g, "'")                       // Turli apostroflarni normalize qil
        .split(' ')                                      // So‘zlarga ajratamiz
        .map(word => {
            // Agar so‘z boshida `'` bo‘lsa — olib tashlaymiz
            if (word.startsWith("'")) {
                word = word.slice(1);
            }
            // So‘zni: faqat 1-harf katta, qolganlari kichik
            return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
        })
        .join(' ')                                       // Yana bitta matnga qaytaramiz
        .trim();
});




</script>

<?php
include '../includes/body.php';
?>