<?php
//session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isLoggedIn() || getUserRole() !== 'kassir') {
    die("Sizda ruxsat yo'q!");
}

$title = "Bermorlar ro'yhati";
ob_start();
include '../includes/head.php';

// Bemorlarni ism bo'yicha qidirish
if (isset($_GET['searchName'])) {
    $searchName = trim($_GET['searchName']);
    $stmt = $conn->prepare("
        SELECT p.*, s.name AS service_name, u.username AS doctor_name, u2.username AS nurse_name, u3.username AS cashier_name 
        FROM patients p 
        LEFT JOIN services s ON p.service_id = s.id 
        LEFT JOIN users u ON p.doctor_id = u.id 
        LEFT JOIN users u2 ON p.nurse_id = u2.id 
        LEFT JOIN users u3 ON p.cashier_id = u3.id 
        WHERE p.full_name LIKE :searchName 
        ORDER BY p.created_at DESC
    ");
    $stmt->execute(['searchName' => "%$searchName%"]);
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Oylik bemorlar ro'yxati
if (isset($_GET['month']) && isset($_GET['year'])) {
    $month = $_GET['month'];
    $year = $_GET['year'];
    $stmt = $conn->prepare("
        SELECT p.*, s.name AS service_name, u.username AS doctor_name, u2.username AS nurse_name, u3.username AS cashier_name 
        FROM patients p 
        LEFT JOIN services s ON p.service_id = s.id 
        LEFT JOIN users u ON p.doctor_id = u.id 
        LEFT JOIN users u2 ON p.nurse_id = u2.id 
        LEFT JOIN users u3 ON p.cashier_id = u3.id 
        WHERE MONTH(p.created_at) = :month AND YEAR(p.created_at) = :year 
        ORDER BY p.created_at DESC
    ");
    $stmt->execute(['month' => $month, 'year' => $year]);
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <style>
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch; /* Smooth scrolling on touch devices */
        }
        .table {
            min-width: 600px; /* Jadvalning minimal kengligi */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Hisobotlar</h1>

        <!-- Bemor qidirish formasi -->
        <form id="searchForm" class="mb-4">
            <div class="form-group">
                <label for="searchName">Bemor Ismi:</label>
                <input type="text" id="searchName" name="searchName" class="form-control" placeholder="Bemor ismini kiriting">
            </div>
            <button type="submit" class="btn btn-primary">Qidirish</button>
        </form>

        <!-- Oylik hisobot formasi -->
        <form id="monthlyReportForm" class="mb-4">
            <div class="form-group">
                <label for="month">Oy:</label>
                <select id="month" name="month" class="form-control">
                    <option value="01">Yanvar</option>
                    <option value="02">Fevral</option>
                    <option value="03">Mart</option>
                    <option value="04">Aprel</option>
                    <option value="05">May</option>
                    <option value="06">Iyun</option>
                    <option value="07">Iyul</option>
                    <option value="08">Avgust</option>
                    <option value="09">Sentabr</option>
                    <option value="10">Oktabr</option>
                    <option value="11">Noyabr</option>
                    <option value="12">Dekabr</option>
                </select>
            </div>
            <div class="form-group">
                <label for="year">Yil:</label>
                <input type="number" id="year" name="year" class="form-control" value="<?= date('Y') ?>">
            </div>
            <button type="submit" class="btn btn-primary">Ko'rsatish</button>
        </form>

        <!-- Natijalar -->
        <div id="results">
            <?php if (!empty($patients)): ?>
                <h2>Natijalar</h2>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Ism</th>
                                <th>Yil</th>
                                <th>Xizmat</th>
                                <th>Shifokor</th>
                                <th>Hamshira</th>
                                <th>Kassir</th>
                                <th>Narxi</th>
                                <th>To'lov</th>
                                <th>Qarz</th>
                                <th>Vaqt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $counter = 1; ?>
                            <?php foreach ($patients as $patient): ?>
                                <tr>
                                    <td><?= $counter++ ?></td>
                                    <td><?= htmlspecialchars($patient['full_name']) ?></td>
                                    <td><?= $patient['birth_year'] ?></td>
                                    <td><?= $patient['service_name'] ?></td>
                                    <td><?= $patient['doctor_name'] ?? '-' ?></td>
                                    <td><?= $patient['nurse_name'] ?? '-' ?></td>
                                    <td><?= $patient['cashier_name'] ?? '-' ?></td>
                                    <td><?= number_format($patient['price'], 2) ?> so'm</td>
                                    <td><?= $patient['payment_method'] ?></td>
                                    <td><?= $patient['debt'] ? 'Ha' : 'Yo‘q' ?></td>
                                    <td><?= $patient['created_at'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php elseif (isset($_GET['searchName']) || isset($_GET['month'])): ?>
                <div class="alert alert-info">Hech qanday natija topilmadi.</div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Bemor qidirish formasi uchun AJAX
        document.getElementById('searchForm').addEventListener('submit', function (e) {
            e.preventDefault();
            const searchName = document.getElementById('searchName').value;
            window.location.href = `reports_kas.php?searchName=${encodeURIComponent(searchName)}`;
        });

        // Oylik hisobot formasi uchun AJAX
        document.getElementById('monthlyReportForm').addEventListener('submit', function (e) {
            e.preventDefault();
            const month = document.getElementById('month').value;
            const year = document.getElementById('year').value;
            window.location.href = `reports_kas.php?month=${month}&year=${year}`;
        });
    </script>


<?php
//$content = ob_get_clean();
include '../includes/body.php';
?>