<?php
session_start();
require_once '../includes/auth_check.php';
// Agar foydalanuvchi login sahifasidan kelayotgan bo'lsa
if (isset($_GET['redirect'])) {
    $_SESSION['redirect_url'] = $_GET['redirect'];
}
require_once '../includes/db.php';
require_once '../includes/functions.php';
if (isset($_GET['redirect'])) {
    $_SESSION['redirect_url'] = $_GET['redirect'];
}
$title = "To'lovlar tarixi";
ob_start();
$content = ob_get_clean();
include '../includes/head.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole();
$user_id = $_SESSION['user']['id'];

// Filter parametrlari
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$employee_id = $_GET['employee_id'] ?? ($role === 'rahbar' ? null : $user_id);

// Xodimlarning joriy balansi
if (in_array($role, ['shifokor', 'hamshira', 'kassir'])) {
    $query = "SELECT total_income FROM users WHERE id = :user_id";
    $stmt = $conn->prepare($query);
    $stmt->execute(['user_id' => $user_id]);
    $user_income = $stmt->fetch(PDO::FETCH_ASSOC)['total_income'];
    
    // Kassir uchun qo'shimcha 000,000 so'm
    if ($role === 'kassir') {
        $user_income += 000000;
    }
}

// Ishlagan kunlar patients jadvalidan - doctor_id, nurse_id, cashier_id tekshiradi
$query = "
    SELECT COUNT(DISTINCT DATE(created_at)) as work_days
    FROM patients
    WHERE (
        doctor_id = :user_id
        OR nurse_id = :user_id
        OR cashier_id = :user_id
    )
    AND created_at BETWEEN :start_date AND :end_date
";

$stmt = $conn->prepare($query);
$stmt->execute([
    'user_id' => $employee_id ?? $user_id,
    'start_date' => $start_date . ' 00:00:00',
    'end_date' => $end_date . ' 23:59:59'
]);
$work_days = (int)$stmt->fetchColumn();

// Sana oralig'ida jami kunlar
$start = new DateTime($start_date);
$end = new DateTime($end_date);
$interval = $start->diff($end);
$total_days = $interval->days + 1;

// Dam olgan kunlar
$rest_days = $total_days - $work_days;

// Xodimlar ro'yxati (rahbar uchun)
$employees = [];
if ($role === 'rahbar') {
    $query = "SELECT id, username FROM users WHERE role IN ('shifokor', 'hamshira', 'kassir') ORDER BY username";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// To'lovlar tarixini olish
try {
    $query = "SELECT r.id, r.user_id, u.username, r.total_income, r.date, 
                     r.is_bonus, r.description, u.role
              FROM reports r
              JOIN users u ON r.user_id = u.id
              WHERE r.date BETWEEN :start_date AND :end_date";
    
    $params = [
        'start_date' => $start_date,
        'end_date' => $end_date . ' 23:59:59'
    ];
    
    if ($role !== 'rahbar' || $employee_id) {
        $query .= " AND r.user_id = :user_id";
        $params['user_id'] = $employee_id ?? $user_id;
    }
    
    $query .= " ORDER BY r.date DESC";
    
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Jami to'lovlar
    $total_payments = 0;
    $total_bonuses = 0;
    foreach ($payments as $payment) {
        if ($payment['is_bonus']) {
            $total_bonuses += $payment['total_income'];
        } else {
            $total_payments += $payment['total_income'];
        }
    }
    $grand_total = $total_payments + $total_bonuses;
    
} catch (Exception $e) {
    die("Xatolik yuz berdi: " . $e->getMessage());
}
?>

<div class="container mt-4">
    <!-- Sarlavha va balans ko'rsatgichi -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">
            <i class="fas fa-history text-primary"></i> To'lovlar tarixi
            <?php if ($employee_id && $role === 'rahbar'): ?>
                <small class="text-muted"><?= htmlspecialchars(array_column($employees, 'username', 'id')[$employee_id] ?? '') ?></small>
            <?php endif; ?>
        </h1>
        
        <?php if (in_array($role, ['shifokor', 'hamshira', 'kassir'])): ?>
            <div class="balance-card bg-success text-white p-3 rounded">
                <h5 class="mb-0">
                    <i class="fas fa-wallet me-2"></i>
                    Joriy balans: <strong><?= number_format($user_income, 0, ',', ' ') ?> so'm</strong>
                    <!--<?php if ($role === 'kassir'): ?>
                        <small class="d-block text-white-50">(300,000 so'm qo'shilgan)</small>
                    <?php endif; ?>-->
                </h5>
            </div>
        <?php endif; ?>
    </div>

    <!-- Filtr paneli -->
    <div class="card mb-4">
        <div class="card-header bg-light">
            <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filtr</h5>
        </div>
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label for="start_date" class="form-label">Boshlanish sanasi</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" 
                           value="<?= htmlspecialchars($start_date) ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label">Tugash sanasi</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" 
                           value="<?= htmlspecialchars($end_date) ?>">
                </div>
                <?php if ($role === 'rahbar'): ?>
                    <div class="col-md-4">
                        <label for="employee_id" class="form-label">Xodim</label>
                        <select class="form-select" id="employee_id" name="employee_id">
                            <option value="">Barcha xodimlar</option>
                            <?php foreach ($employees as $employee): ?>
                                <option value="<?= $employee['id'] ?>" 
                                    <?= ($employee_id == $employee['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($employee['username']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i> Filtrlash
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Jami ko'rsatgichlar -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title"><i class="fas fa-money-bill-wave me-2"></i>Jami to'lov</h5>
                    <h2 class="card-text"><?= number_format($total_payments, 0, ',', ' ') ?> so'm</h2>
                    <small class="opacity-75">Oddiy ish haqi</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-warning text-dark">
                <div class="card-body">
                    <h5 class="card-title"><i class="fas fa-gift me-2"></i>Jami bonus</h5>
                    <h2 class="card-text"><?= number_format($total_bonuses, 0, ',', ' ') ?> so'm</h2>
                    <small class="opacity-75">Qo'shimcha to'lovlar</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title"><i class="fas fa-calculator me-2"></i>Umumiy summa</h5>
                    <h2 class="card-text"><?= number_format($grand_total, 0, ',', ' ') ?> so'm</h2>
                    <small class="opacity-75">Barcha to'lovlar</small>
                </div>
            </div>
        </div>
    </div>

    <!-- To'lovlar jadvali -->
    <div class="card">
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-list me-2"></i>To'lovlar ro'yxati</h5>
            <span class="badge bg-primary">
                <?= date('d.m.Y', strtotime($start_date)) ?> - <?= date('d.m.Y', strtotime($end_date)) ?>
            </span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th width="50">#</th>
                            <th>Xodim</th>
                            <th>Miqdor</th>
                            <th>Turi</th>
                            <th>Sana</th>
                            <th>Izoh</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($payments)): ?>
                            <?php foreach ($payments as $index => $payment): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td>
                                        <?= htmlspecialchars($payment['username']) ?>
                                        <small class="d-block text-muted"><?= $payment['role'] ?></small>
                                    </td>
                                    <td class="fw-bold">
                                        <?= number_format($payment['total_income'], 0, ',', ' ') ?> so'm
                                    </td>
                                    <td>
                                        <?php if ($payment['is_bonus']): ?>
                                            <span class="badge bg-warning text-dark">
                                                <i class="fas fa-gift me-1"></i> Bonus
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-primary">
                                                <i class="fas fa-money-bill-wave me-1"></i> Ish haqi
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('d.m.Y', strtotime($payment['date'])) ?></td>
                                    <td><?= htmlspecialchars($payment['description'] ?? '') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">
                                    <i class="fas fa-info-circle fa-2x mb-3"></i><br>
                                    Tanlangan davrda to'lovlar topilmadi
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-light">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <?php if (!empty($payments)): ?>
<!--                        <span class="text-muted"><?= count($payments) ?> ta yozuv</span> -->
Ish kunlaringiz:<span class="text-muted"> <?= $work_days ?> ta</span> | Dam olish kunlaringiz:<span class="text-muted"> <?= $rest_days ?> ta </span>
                        
                    <?php endif; ?>
                </div>
                <div>
<!--                    <button class="btn btn-outline-primary" onclick="window.print()">
                        <i class="fas fa-print me-1"></i> Chop etish
                    </button>-->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- CSS qo'shimchalari -->
<style>
    .balance-card {
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        transition: all 0.3s ease;
    }
    .balance-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 1rem 2rem rgba(0, 0, 0, 0.15);
    }
    .table-hover tbody tr:hover {
        background-color: rgba(0, 123, 255, 0.05);
    }
    .badge {
        font-size: 0.85em;
        padding: 0.5em 0.75em;
    }
</style>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php
include '../includes/body.php';
?>
</body>
</html>