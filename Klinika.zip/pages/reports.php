<?php
//session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
$title = "Hisobotlar";
ob_start();
include '../includes/head.php';



// Foydalanuvchi autentifikatsiyasi
if (!isLoggedIn()) {
    redirect('../pages/login.php');
}

$role = getUserRole();
$user_id = $_SESSION['user']['id'];

// Faqat rahbar uchun ruxsat
if ($role !== 'rahbar') {
    die("Sizda bu sahifaga kirish uchun ruxsat yo'q!");
}

// Sana oralig'ini belgilash
$today = date('Y-m-d');
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');

// Prognoz faylini include qilish
//$is_filtered = isset($_GET['start_date']) || isset($_GET['end_date']);
//require_once '../admin/prognoz.php';
$is_filtered = isset($_GET['start_date']) || isset($_GET['end_date']);

// reports.php faylining oxirgi qismida (a tegi oldidan)
$continue_url = "?start_date=" . urlencode($start_date) . "&end_date=" . urlencode($end_date);

// Tanlangan davr uchun statistikani olish
$query = "SELECT 
            DATE(created_at) AS day,
            SUM(price) AS daily_income,
            (SELECT SUM(amount) FROM expenses WHERE DATE(created_at) = day) AS daily_expenses
          FROM patients 
          WHERE DATE(created_at) BETWEEN :start_date AND :end_date
          GROUP BY DATE(created_at)
          ORDER BY DATE(created_at)";
$stmt = $conn->prepare($query);
$stmt->execute(['start_date' => $start_date, 'end_date' => $end_date]);
$daily_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Bugungi to'lovlar va qarzlar
$query = "SELECT 
            SUM(price) AS total_income,
            SUM(CASE WHEN payment_method = 'naqt' THEN price ELSE 0 END) AS naqt,
            SUM(CASE WHEN payment_method = 'terminal' THEN price ELSE 0 END) AS terminal,
            SUM(CASE WHEN payment_method = 'click' THEN price ELSE 0 END) AS click,
            SUM(CASE WHEN debt = 1 THEN price ELSE 0 END) AS qarz
          FROM patients 
          WHERE DATE(created_at) = :today";
$stmt = $conn->prepare($query);
$stmt->execute(['today' => $today]);
$today_stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Oylik to'lovlar va qarzlar
$query = "SELECT 
            SUM(price) AS total_income,
            SUM(CASE WHEN payment_method = 'naqt' THEN price ELSE 0 END) AS naqt,
            SUM(CASE WHEN payment_method = 'terminal' THEN price ELSE 0 END) AS terminal,
            SUM(CASE WHEN payment_method = 'click' THEN price ELSE 0 END) AS click,
            SUM(CASE WHEN debt = 1 THEN price ELSE 0 END) AS qarz
          FROM patients 
          WHERE MONTH(created_at) = MONTH(CURDATE())";
$stmt = $conn->prepare($query);
$stmt->execute();
$monthly_stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Tanlangan davr uchun to'lovlar va qarzlar
$query = "SELECT 
            SUM(price) AS total_income,
            SUM(CASE WHEN payment_method = 'naqt' THEN price ELSE 0 END) AS naqt,
            SUM(CASE WHEN payment_method = 'terminal' THEN price ELSE 0 END) AS terminal,
            SUM(CASE WHEN payment_method = 'click' THEN price ELSE 0 END) AS click,
            SUM(CASE WHEN debt = 1 THEN price ELSE 0 END) AS qarz
          FROM patients 
          WHERE DATE(created_at) BETWEEN :start_date AND :end_date";
$stmt = $conn->prepare($query);
$stmt->execute(['start_date' => $start_date, 'end_date' => $end_date]);
$period_stats = $stmt->fetch(PDO::FETCH_ASSOC);


// XODIMLAR ULUSHI (TO'G'RILANGAN VERSIYA)
$query = "SELECT 
            u.id,
            u.username AS xodim,
            'Shifokor' AS position,
            SUM(p.doctor_income) AS income
          FROM patients p
          LEFT JOIN users u ON p.doctor_id = u.id
          WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
          GROUP BY u.id, u.username
          HAVING SUM(p.doctor_income) > 0
          
          UNION ALL
          
          SELECT 
            u.id,
            u.username AS xodim,
            'Hamshira' AS position,
            SUM(p.nurse_income) AS income
          FROM patients p
          LEFT JOIN users u ON p.nurse_id = u.id
          WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
          GROUP BY u.id, u.username
          HAVING SUM(p.nurse_income) > 0
          
          ORDER BY income DESC";
$stmt = $conn->prepare($query);
$stmt->execute(['start_date' => $start_date, 'end_date' => $end_date]);
$all_staff = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Xodimlar ulushi foizini hisoblash
foreach ($all_staff as &$staff) {
    $staff['percentage'] = ($period_stats['total_income'] > 0) ? 
        ($staff['income'] / $period_stats['total_income']) * 100 : 0;
}
unset($staff);

// Shifokorlar va hamshiralarni alohida ajratib olish
$doctor_shares = array_filter($all_staff, function($staff) {
    return $staff['position'] === 'Shifokor';
});

$nurse_shares = array_filter($all_staff, function($staff) {
    return $staff['position'] === 'Hamshira';
});

// Chiqimlarni olish
$query = "SELECT 
            SUM(amount) AS total_expenses
          FROM expenses 
          WHERE DATE(created_at) BETWEEN :start_date AND :end_date";
$stmt = $conn->prepare($query);
$stmt->execute(['start_date' => $start_date, 'end_date' => $end_date]);
$total_expenses = $stmt->fetch(PDO::FETCH_ASSOC)['total_expenses'] ?? 0;

// Klinika foydasi (umumiy tushumdan shifokor, hamshira, chiqimlar va kassir daromadini ayirish)
$total_doctor_income = array_sum(array_column($doctor_shares, 'income'));
$total_nurse_income = array_sum(array_column($nurse_shares, 'income'));
$clinic_profit = $period_stats['total_income'] - $total_doctor_income - $total_nurse_income - $total_expenses;

// Klinika foydasi to'lov turlari bo'yicha
$query = "SELECT 
            SUM(CASE WHEN payment_method = 'naqt' THEN price ELSE 0 END) - 
            SUM(CASE WHEN payment_method = 'naqt' THEN doctor_income + nurse_income ELSE 0 END) AS naqt_profit,
            SUM(CASE WHEN payment_method = 'terminal' THEN price ELSE 0 END) - 
            SUM(CASE WHEN payment_method = 'terminal' THEN doctor_income + nurse_income ELSE 0 END) AS terminal_profit,
            SUM(CASE WHEN payment_method = 'click' THEN price ELSE 0 END) - 
            SUM(CASE WHEN payment_method = 'click' THEN doctor_income + nurse_income ELSE 0 END) AS click_profit
          FROM patients 
          WHERE DATE(created_at) BETWEEN :start_date AND :end_date";
$stmt = $conn->prepare($query);
$stmt->execute(['start_date' => $start_date, 'end_date' => $end_date]);
$clinic_profit_by_payment = $stmt->fetch(PDO::FETCH_ASSOC);

$total_expensess = $clinic_profit_by_payment['naqt_profit'] - $total_expenses;

// Xabarni ko'rsatish
if (isset($_SESSION['message'])) {
    echo "<div class='alert alert-info'>{$_SESSION['message']}</div>";
    unset($_SESSION['message']);
}
?>

<div class="container mt-4 mb-5">
<div class="container-fluid py-4">
<div class="container-fluid">
    <!-- Sarlavha va davomi tugmasi -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 text-gray-800">Hisobotlar</h1>
        <a href="./../admin/patient_visits.php<?= $continue_url ?>" class="btn btn-primary">
            <i class="fas fa-arrow-right"></i> Surunkali be'morlar
        </a>
        
        <a href="reports2.php<?= $continue_url ?>" class="btn btn-primary">
            <i class="fas fa-arrow-right"></i> Davomi
        </a>
    </div>

    <!-- Sana filtr formasi -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Sana oralig'ini tanlang</h6>
        </div>
        <div class="card-body">
            <form method="GET" class="form-inline">
                <div class="form-group mx-2">
                    <label for="start_date" class="mr-2">Boshlanish:</label>
                    <input type="date" name="start_date" class="form-control" value="<?= $start_date ?>">
                </div>
                <div class="form-group mx-2">
                    <label for="end_date" class="mr-2">Tugash:</label>
                    <input type="date" name="end_date" class="form-control" value="<?= $end_date ?>">
                </div>
                <button type="submit" class="btn btn-primary ml-2">
                    <i class="fas fa-filter"></i> Filtrlash
                </button>
            </form>
        </div>
    </div>

    <!-- Tanlangan davr uchun statistika -->
    <h2>Tanlangan Davr Statistika (<?= $start_date ?> - <?= $end_date ?>)</h2>
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Jami Tushum</h5>
                    <p class="card-text"><?= number_format($period_stats['total_income'], 0) ?> so'm</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Naqt</h5>
                    <p class="card-text"><?= number_format($period_stats['naqt'], 0) ?> so'm</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Terminal</h5>
                    <p class="card-text"><?= number_format($period_stats['terminal'], 0) ?> so'm</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Click</h5>
                    <p class="card-text"><?= number_format($period_stats['click'], 0) ?> so'm</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Qarz</h5>
                    <p class="card-text"><?= number_format($period_stats['qarz'], 0) ?> so'm</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <h5 class="card-title">Jami Chiqimlar</h5>
                    <p class="card-text"><?= number_format($total_expenses, 0) ?> so'm</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Klinika foydasi -->
    <h2>Klinika Foydasi (<?= $start_date ?> - <?= $end_date ?>)</h2>
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Klinika Foydasi</h5>
                    <p class="card-text"><?= number_format($clinic_profit, 0) ?> so'm</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Naqt Foydasi</h5>
                    <p class="card-text"><?= number_format($total_expensess, 0) ?> so'm</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Terminal Foydasi</h5>
                    <p class="card-text"><?= number_format($clinic_profit_by_payment['terminal_profit'], 0) ?> so'm</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Click Foydasi</h5>
                    <p class="card-text"><?= number_format($clinic_profit_by_payment['click_profit'], 0) ?> so'm</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Kunlik tushum va chiqimlar diagrammasi -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">
                Kunlik Tushum va Chiqimlar (<?= date('d.m.Y', strtotime($start_date)) ?> - <?= date('d.m.Y', strtotime($end_date)) ?>)
            </h6>
        </div>
        <div class="card-body">
            <div class="chart-bar" style="height: 350px;">
                <canvas id="incomeExpenseChart"></canvas>
            </div>
        </div>
    </div>
<!-- Prognoz bloklari -->
<?php 
require_once '../admin/prognoz_hafta.php';
//include '../admin/prognoz.php';

//Xodimlar ulushi diagramma
require './../admin/staff_shares_xodimlar.php';
?>

    
</div>

<!-- Chart.js kutubxonasi -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

// Kunlik tushum va chiqimlar diagrammasi
document.addEventListener('DOMContentLoaded', function() {
    const ctx2 = document.getElementById('incomeExpenseChart').getContext('2d');
    
    const dailyData = [
        <?php foreach ($daily_stats as $day): ?>
        {
            day: '<?= date("d.m.Y", strtotime($day['day'])) ?>',
            income: <?= $day['daily_income'] ?? 0 ?>,
            expenses: <?= $day['daily_expenses'] ?? 0 ?>
        },
        <?php endforeach; ?>
    ];
    
    new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: dailyData.map(item => item.day),
            datasets: [
                {
                    label: 'Tushum',
                    data: dailyData.map(item => item.income),
                    backgroundColor: '#1cc88a',
                    borderColor: '#1cc88a',
                    borderWidth: 1
                },
                {
                    label: 'Chiqim',
                    data: dailyData.map(item => item.expenses),
                    backgroundColor: '#e74a3b',
                    borderColor: '#e74a3b',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Summa (so\'m)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Kunlar'
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.dataset.label || '';
                            let value = context.raw || 0;
                            return label + ': ' + value.toLocaleString('uz') + ' so\'m';
                        }
                    }
                }
            }
        }
    });
});
</script>

<?php
include '../includes/body.php';
?>