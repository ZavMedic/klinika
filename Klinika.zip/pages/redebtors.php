<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
$title = "Qaytarilgan Qarzlar";
ob_start();
$content = ob_get_clean();
include '../includes/head.php';

// Faqat rahbar va kassir uchun ruxsat
if (!isLoggedIn() || !in_array(getUserRole(), ['rahbar', 'kassir'])) {
    redirect('login.php');
}

// Qaytarilgan qarzlar ro'yxatini olish (xizmat turlari bilan)
$query = "SELECT 
            dp.id, 
            p.full_name AS patient_name, 
            GROUP_CONCAT(DISTINCT s.name SEPARATOR ', ') AS service_names,
            dp.debt_amount, 
            dp.medicine_cost, 
            dp.debt_date, 
            dp.repayment_date, 
            u1.username AS doctor_name, 
            u2.username AS nurse_name,
            u3.username AS cashier_name,
            p.phone_number,
            DATEDIFF(dp.repayment_date, dp.debt_date) AS days_to_repay
          FROM debt_payments dp
          LEFT JOIN patients p ON dp.patient_id = p.id
          LEFT JOIN patient_services ps ON p.id = ps.patient_id
          LEFT JOIN services s ON ps.service_id = s.id
          LEFT JOIN users u1 ON dp.doctor_id = u1.id
          LEFT JOIN users u2 ON dp.nurse_id = u2.id
          LEFT JOIN users u3 ON dp.cashier_id = u3.id
          WHERE dp.repayment_date IS NOT NULL
          GROUP BY dp.id
          ORDER BY dp.repayment_date DESC";

try {
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $repayments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "SQL Xatosi: " . $e->getMessage();
    $repayments = [];
}
?>

<div class="container mt-5">
    <h1 class="mb-4">Qaytarilgan Qarzlar</h1>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success">
            <?= $_SESSION['message'] ?>
        </div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>#</th>
                    <th>Bemor</th>
                    <th>Xizmat Turlari</th>
                    <th>Qarz Miqdori</th>
                    <th>Qarzdorlik Sanasi</th>
                    <th>Qaytarilgan Sana</th>
                    <th>Kunlar</th>
                    <th>Shifokor</th>
                    <th>Hamshira</th>
                    <th>Kassir</th>
                    <th>Telefon</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($repayments)): ?>
                    <?php foreach ($repayments as $index => $repayment): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>  <!-- Tartib raqamini ko'rsatish -->
                            <td><?= htmlspecialchars($repayment['patient_name']) ?></td>
                            <td><?= $repayment['service_names'] ?? 'Xizmatlar ko\'rsatilmagan' ?></td>
                            <td><?= number_format($repayment['debt_amount'], 0) ?>
                            <?php if (!empty($repayment['medicine_cost']) && $repayment['medicine_cost'] > 0): ?>
                                    <br><small class="text-muted">+ <?= number_format($repayment['medicine_cost'], 0) ?> so'm dori</small>
                                    <br><strong>Jami: <?= number_format($repayment['debt_amount'] + $repayment['medicine_cost'], 0) ?> so'm</strong>
                                <?php endif; ?></td>
                            <td><?= date('d.m.Y H:i', strtotime($repayment['debt_date'])) ?></td>
                            <td><?= date('d.m.Y H:i', strtotime($repayment['repayment_date'])) ?></td>
                            <td><?= $repayment['days_to_repay'] ?> kun</td>
                            <td><?= $repayment['doctor_name'] ?? '-' ?></td>
                            <td><?= $repayment['nurse_name'] ?? '-' ?></td>
                            <td><?= $repayment['cashier_name'] ?? '-' ?></td>
                            <td>
                                <?php if (!empty($repayment['phone_number'])): ?>
                                    <a href="tel:<?= $repayment['phone_number'] ?>" class="text-decoration-none">
                                        <?= formatPhoneNumber($repayment['phone_number']) ?>
                                    </a>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="11" class="text-center">Qaytarilgan qarzlar topilmadi.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="row g-3 align-items-end mt-3">
        <center>
            <div class="col-md-2">
                <a href="debtors.php" class="btn btn-primary w-100">Qarzdorlar</a>
            </div>
        </center>
    </div>
</div>

<?php
include '../includes/body.php';
?>