<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
$title = "Qarzdorlar";
ob_start();
$content = ob_get_clean();
include '../includes/head.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole();
if ($role !== 'kassir' && $role !== 'rahbar') {
    die("Sizda qarzdorlarni ko'rish uchun ruxsat yo'q!");
}

// Xabarlarni ko'rsatish
if (isset($_SESSION['message'])) {
    echo '<div class="alert alert-success alert-dismissible fade show">
            '.htmlspecialchars($_SESSION['message']).'
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>';
    unset($_SESSION['message']);
}

// Qarzni undirish jarayoni
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['repay_debt'])) {
    $patient_id = intval($_POST['patient_id']);
    $payment_method = $_POST['payment_method'];

    try {
        $conn->beginTransaction();

        // Bemorni olish (barcha kerakli ma'lumotlar bilan)
        $stmt = $conn->prepare("
            SELECT p.*, 
                   d.username AS doctor_name, 
                   n.username AS nurse_name,
                   c.username AS cashier_name,
                   d.telegram_id AS doctor_telegram_id,
                   n.telegram_id AS nurse_telegram_id,
                   GROUP_CONCAT(DISTINCT s.name SEPARATOR ', ') AS service_names
            FROM patients p
            LEFT JOIN users d ON p.doctor_id = d.id
            LEFT JOIN users n ON p.nurse_id = n.id
            LEFT JOIN users c ON p.cashier_id = c.id
            LEFT JOIN patient_services ps ON p.id = ps.patient_id
            LEFT JOIN services s ON ps.service_id = s.id
            WHERE p.id = :patient_id
            GROUP BY p.id
        ");
        $stmt->execute(['patient_id' => $patient_id]);
        $patient = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$patient) throw new Exception("Bemor topilmadi");

        // Dori xarajatlarini hisoblash
        $stmt = $conn->prepare("SELECT SUM(amount) FROM expenses WHERE patient_id = :patient_id AND type = 'Dorilar'");
        $stmt->execute(['patient_id' => $patient_id]);
        $medicine_cost = $stmt->fetchColumn() ?? 0;

        // Bemorni yangilash (qarz holatini o'zgartirish)
        // Qarzdor bemorni yangilash va to'lov usulini qo'shish
$stmt = $conn->prepare("
    UPDATE patients 
    SET 
        debt = 0, 
        payment_method = :payment_method
    WHERE id = :patient_id
");

$stmt->execute([
    'patient_id' => $patient_id,
    'payment_method' => $payment_method // 'naqt', 'terminal' yoki 'click'
]);

        // Qaytarilgan qarzni yozib qo'yish
        $stmt = $conn->prepare("
            INSERT INTO debt_payments (
                patient_id, debt_date, repayment_date, service_id, doctor_id, nurse_id, 
                debt_amount, payment_method, cashier_id, medicine_cost
            ) VALUES (
                :patient_id, :debt_date, NOW(), NULL, :doctor_id, :nurse_id, 
                :debt_amount, :payment_method, :cashier_id, :medicine_cost
            )
        ");
        $stmt->execute([
            'patient_id' => $patient_id,
            'debt_date' => $patient['created_at'],
            'doctor_id' => $patient['doctor_id'],
            'nurse_id' => $patient['nurse_id'],
            'debt_amount' => $patient['price'],
            'payment_method' => $payment_method,
            'cashier_id' => $_SESSION['user']['id'],
            'medicine_cost' => $medicine_cost
        ]);

        // Daromadlarni yangilash
        if ($patient['doctor_id'] && $patient['doctor_income'] > 0) {
            $stmt = $conn->prepare("UPDATE users SET total_income = total_income + :income WHERE id = :user_id");
            $stmt->execute([
                'income' => $patient['doctor_income'],
                'user_id' => $patient['doctor_id']
            ]);
        }

        if ($patient['nurse_id'] && $patient['nurse_income'] > 0) {
            $stmt = $conn->prepare("UPDATE users SET total_income = total_income + :income WHERE id = :user_id");
            $stmt->execute([
                'income' => $patient['nurse_income'],
                'user_id' => $patient['nurse_id']
            ]);
        }

        if ($patient['cashier_id'] && $patient['kassir_income'] > 0) {
            $stmt = $conn->prepare("UPDATE users SET total_income = total_income + :income WHERE id = :user_id");
            $stmt->execute([
                'income' => $patient['kassir_income'],
                'user_id' => $patient['cashier_id']
            ]);
        }

        $conn->commit();

        // Telegram xabarlarini yuborish
        $total_amount = $patient['price'] + $medicine_cost;
        $visit_date = date('d.m.Y H:i', strtotime($patient['created_at']));
        $repayment_date = date('d.m.Y H:i');
        $days_in_debt = $patient['days_in_debt'] ?? round((time() - strtotime($patient['created_at'])) / (60 * 60 * 24));
        
        // 1. Rahbarga xabar
        $admin_id = $conn->query("SELECT id FROM users WHERE role = 'rahbar' LIMIT 1")->fetchColumn();
        if ($admin_id) {
            $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = :admin_id AND telegram_id IS NOT NULL");
            $stmt->execute(['admin_id' => $admin_id]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($admin) {
                $message = "✅ <b>QARZ UNDIRILDI</b>\n\n";
                $message .= "👤 <b>Bemor:</b> " . htmlspecialchars($patient['full_name']) . "\n";
                $message .= "📅 <b>Tug'ilgan yili:</b> " . $patient['birth_year'] . "\n";
                $message .= "📱 <b>Telefon:</b> " . ($patient['phone_number'] ?? 'Noma\'lum') . "\n";
                $message .= "🏥 <b>Xizmatlar:</b> " . ($patient['service_names'] ?? 'Noma\'lum') . "\n";
                $message .= "👨‍⚕️ <b>Shifokor:</b> " . ($patient['doctor_name'] ?? 'Tanlanmagan') . "\n";
                if ($patient['nurse_name']) {
                    $message .= "👩‍⚕️ <b>Hamshira:</b> " . $patient['nurse_name'] . "\n";
                }
                $message .= "💰 <b>Xizmat narxi:</b> " . number_format($patient['price'], 0, ',', ' ') . " so'm\n";
                if ($medicine_cost > 0) {
                    $message .= "💊 <b>Dori narxi:</b> " . number_format($medicine_cost, 0, ',', ' ') . " so'm\n";
                }
                $message .= "🧾 <b>Jami undirildi:</b> " . number_format($total_amount, 0, ',', ' ') . " so'm\n";
                $message .= "💳 <b>To'lov usuli:</b> " . ucfirst($payment_method) . "\n";
                $message .= "📅 <b>Qarz bo'lgan vaqt:</b> " . $visit_date . "\n";
                $message .= "⏳ <b>Qarz bo'lgan kunlar:</b> " . $days_in_debt . " kun\n";
                $message .= "🔄 <b>Undirilgan vaqt:</b> " . $repayment_date . "\n";
                $message .= "👨‍💼 <b>Kassir:</b> " . ($patient['cashier_name'] ?? 'Noma\'lum') . "\n";
                
                sendTelegramMessage($admin['telegram_id'], $message, 'HTML');
            }
        }
        
        // 2. Shifokorga xabar (agar telegram_id bo'lsa)
        if (!empty($patient['doctor_telegram_id'])) {
            $message = "👨‍⚕️ <b>Sizning bemoringiz qarzini to'ladi</b>\n\n";
            $message .= "👤 <b>Bemor:</b> " . htmlspecialchars($patient['full_name']) . "\n";
            $message .= "📅 <b>Tug'ilgan yili:</b> " . $patient['birth_year'] . "\n";
            $message .= "🏥 <b>Xizmatlar:</b> " . ($patient['service_names'] ?? 'Noma\'lum') . "\n";
            $message .= "💰 <b>Xizmat narxi:</b> " . number_format($patient['price'], 0, ',', ' ') . " so'm\n";
            if ($medicine_cost > 0) {
                $message .= "💊 <b>Dori narxi:</b> " . number_format($medicine_cost, 0, ',', ' ') . " so'm\n";
            }
            $message .= "🧾 <b>Jami undirildi:</b> " . number_format($total_amount, 0, ',', ' ') . " so'm\n";
            $message .= "📅 <b>Qarz bo'lgan vaqt:</b> " . $visit_date . "\n";
            $message .= "⏳ <b>Qarz bo'lgan kunlar:</b> " . $days_in_debt . " kun\n";
            $message .= "🔄 <b>Undirilgan vaqt:</b> " . $repayment_date . "\n";
            
            sendTelegramMessage($patient['doctor_telegram_id'], $message, 'HTML');
        }
        
        // 3. Hamshiraga xabar (agar telegram_id bo'lsa)
        if (!empty($patient['nurse_telegram_id'])) {
            $message = "👩‍⚕️ <b>Sizning bemoringiz qarzini to'ladi</b>\n\n";
            $message .= "👤 <b>Bemor:</b> " . htmlspecialchars($patient['full_name']) . "\n";
            $message .= "📅 <b>Tug'ilgan yili:</b> " . $patient['birth_year'] . "\n";
            $message .= "👨‍⚕️ <b>Shifokor:</b> " . ($patient['doctor_name'] ?? 'Tanlanmagan') . "\n";
            $message .= "🏥 <b>Xizmatlar:</b> " . ($patient['service_names'] ?? 'Noma\'lum') . "\n";
            $message .= "💰 <b>Xizmat narxi:</b> " . number_format($patient['price'], 0, ',', ' ') . " so'm\n";
            if ($medicine_cost > 0) {
                $message .= "💊 <b>Dori narxi:</b> " . number_format($medicine_cost, 0, ',', ' ') . " so'm\n";
            }
            $message .= "🧾 <b>Jami undirildi:</b> " . number_format($total_amount, 0, ',', ' ') . " so'm\n";
            $message .= "📅 <b>Qarz bo'lgan vaqt:</b> " . $visit_date . "\n";
            $message .= "⏳ <b>Qarz bo'lgan kunlar:</b> " . $days_in_debt . " kun\n";
            $message .= "🔄 <b>Undirilgan vaqt:</b> " . $repayment_date . "\n";
            
            sendTelegramMessage($patient['nurse_telegram_id'], $message, 'HTML');
        }

        $_SESSION['message'] = "Qarz muvaffaqiyatli undirildi!";
        echo '<script>window.location.href = "debtors.php";</script>';
        exit();
    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['message'] = "Xatolik: " . $e->getMessage();
        echo '<script>window.location.href = "debtors.php";</script>';
        exit();
    }
}

// Qarzdorlarni olish (barcha kerakli ma'lumotlar bilan)
$debtors = $conn->query("
    SELECT 
        p.id, 
        p.full_name, 
        p.birth_year,
        p.price, 
        p.created_at AS visit_date, 
        p.phone_number, 
        p.doctor_id,
        p.nurse_id,
        u.username AS doctor_name, 
        u2.username AS nurse_name, 
        u.telegram_id AS doctor_telegram_id,
        u2.telegram_id AS nurse_telegram_id,
        GROUP_CONCAT(DISTINCT s.name SEPARATOR ', ') AS service_names,
        (SELECT SUM(amount) FROM expenses WHERE patient_id = p.id AND type = 'Dorilar') AS medicine_cost,
        DATEDIFF(NOW(), p.created_at) AS days_in_debt
    FROM patients p 
    LEFT JOIN patient_services ps ON p.id = ps.patient_id 
    LEFT JOIN services s ON ps.service_id = s.id 
    LEFT JOIN users u ON p.doctor_id = u.id 
    LEFT JOIN users u2 ON p.nurse_id = u2.id 
    WHERE p.debt = 1 
    GROUP BY p.id 
    ORDER BY p.created_at DESC;
")->fetchAll(PDO::FETCH_ASSOC);

$total_debt = 0;
foreach ($debtors as $debtor) {
    $total_debt += $debtor['price'] + ($debtor['medicine_cost'] ?? 0);
}
?>

<div class="container py-4">
    <div class="card shadow mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Qarzdorlar</h5>
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h6 class="card-title text-muted">Jami qarzdorlar</h6>
                            <h4 class="card-text text-primary"><?= count($debtors) ?> ta</h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h6 class="card-title text-muted">Jami qarz miqdori</h6>
                            <h4 class="card-text text-danger"><?= number_format($total_debt, 0, ',', ' ') ?> so'm</h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Bemor</th>
                            <th>Xizmatlar</th>
                            <th>Narx</th>
                            <th>Shifokor</th>
                            <th>Hamshira</th>
                            <th>Telefon</th>
                            <th>Qarz kunlari</th>
                            <th>Harakat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($debtors)): ?>
                            <?php foreach ($debtors as $index => $debtor): 
                                $total_amount = $debtor['price'] + ($debtor['medicine_cost'] ?? 0);
                            ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= htmlspecialchars($debtor['full_name']) ?></td>
                                    <td><?= $debtor['service_names'] ?? 'Xizmatlar ko\'rsatilmagan' ?></td>
                                    <td class="text-end"><?= number_format($debtor['price'], 0, ',', ' ') ?> so'm                                <?php if ($debtor['medicine_cost'] > 0): ?>
                                    <br><small class="text-muted">+ <?= number_format($debtor['medicine_cost'], 0, ',', ' ') ?> so'm dori</small>
                                    <br><strong>Jami: <?= number_format($total_amount, 0, ',', ' ') ?> so'm</strong>
                                <?php endif; ?></td>
                                    <td><?= $debtor['doctor_name'] ?? '-' ?></td>
                                    <td><?= $debtor['nurse_name'] ?? '-' ?></td>
                                    <td>
                                        <?php if (!empty($debtor['phone_number'])): ?>
                                            <a href="tel:<?= $debtor['phone_number'] ?>" class="text-decoration-none">
                                                <?= formatPhoneNumber($debtor['phone_number']) ?>
                                            </a>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-<?= $debtor['days_in_debt'] > 7 ? 'danger' : 'warning' ?>">
                                            <?= $debtor['days_in_debt'] ?> kun
                                        </span>
                                    </td>
                                    <td>
                                        <form method="POST" class="d-flex flex-column gap-2" onsubmit="return confirm('<?= htmlspecialchars($debtor['full_name']) ?>ning qarzini undirmoqchimisiz? Jami: <?= number_format($total_amount, 0, ',', ' ') ?> so\'m')">
                                            <input type="hidden" name="patient_id" value="<?= $debtor['id'] ?>">
                                            <select name="payment_method" class="form-select form-select-sm" required>
                                                <option value="naqt">Naqt</option>
                                                <option value="terminal">Terminal</option>
                                                <option value="click">Click</option>
                                            </select>
                                            <button type="submit" name="repay_debt" class="btn btn-success btn-sm">
                                                <i class="fas fa-money-bill-wave me-1"></i>To'lash
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="11" class="text-center py-4 text-muted">
                                    <i class="fas fa-check-circle fa-2x mb-3 text-success"></i><br>
                                    Hozircha qarzdor bemorlar mavjud emas
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-3">
                <a href="redebtors.php" class="btn btn-outline-primary">
                    <i class="fas fa-history me-1"></i> To'langan qarzlar
                </a>
            </div>
        </div>
    </div>
</div>

<?php
include '../includes/body.php';
?>