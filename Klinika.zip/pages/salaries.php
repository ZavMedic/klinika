<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
$title = "To'lovlar tarixi";
ob_start(); // Kontentni buferga yozish
$content = ob_get_clean(); // Buferdagi ma'lumotni olish
include '../includes/head.php';

// Foydalanuvchi tizimga kirganligini tekshirish
if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole(); // Foydalanuvchi roli
$user_id = $_SESSION['user']['id']; // Foydalanuvchi ID si

// To'lovlar tarixini olish
try {
    if ($role === 'rahbar') {
        // Rahbar uchun barcha to'lovlar tarixi
        $query = "SELECT r.user_id, u.username, r.total_income, r.date 
                  FROM reports r
                  JOIN users u ON r.user_id = u.id
                  ORDER BY r.date DESC";
    } else {
        // Xodim uchun faqat o'zining to'lovlar tarixi
        $query = "SELECT r.user_id, u.username, r.total_income, r.date 
                  FROM reports r
                  JOIN users u ON r.user_id = u.id
                  WHERE r.user_id = :user_id
                  ORDER BY r.date DESC";
    }

    $stmt = $conn->prepare($query);
    if ($role !== 'rahbar') {
        $stmt->execute(['user_id' => $user_id]);
    } else {
        $stmt->execute();
    }
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("Xatolik yuz berdi: " . $e->getMessage());
}
?>

<div class="container mt-5">
    <h1>To'lovlar Tarixi</h1>

    <!-- To'lovlar ro'yxati -->
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Xodim Ismi</th>
                    <th>To'lov Miqdori</th>
                    <th>To'lov Sanasi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($payments)): ?>
                    <?php foreach ($payments as $index => $payment): ?>
                        <tr>
                            <td><?= $index + 1 ?></td> <!-- Tartib raqami -->
                            <td><?= htmlspecialchars($payment['username']) ?></td>
                            <td><?= number_format($payment['total_income'], 2) ?> so'm</td>
                            <td><?= date('d.m.Y H:i', strtotime($payment['date'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">To'lovlar tarixi topilmadi.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
<?php
include '../includes/body.php';
?>
</html>