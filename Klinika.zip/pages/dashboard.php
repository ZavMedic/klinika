<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
//session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
$title = "Hisobotlar";
ob_start(); // Kontentni buferga yozish
$content = ob_get_clean(); // Buferdagi ma'lumotni olish
include '../includes/head.php';

// Foydalanuvchi tizimga kirganligini tekshirish
if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole(); // Foydalanuvchi roli
$user_id = $_SESSION['user']['id']; // Foydalanuvchi ID si

// Rahbar va kassir uchun hisobotlar
if (in_array($role, ['rahbar', 'kassir'])) {
    // Bugungi kun
    $today = date('Y-m-d');

$qarz_naqt = $qarz_terminal = $qarz_click = $qarz_dori = 0;

$stmt = $conn->prepare("
//    SELECT dp.payment_method,
//           SUM(dp.debt_amount + dp.medicine_cost) AS total_with_medicine,
//           SUM(dp.medicine_cost) AS total_medicine
//    FROM debt_payments dp
//    JOIN patients p ON dp.patient_id = p.id
//    WHERE DATE(dp.repayment_date) = :today
//    GROUP BY dp.payment_method
//");
//$stmt->execute(['today' => $today]);
// Bugun qarzdan undirilganlar (faqat oldingi kunlarda qarz bo'lganlar)
$stmt = $conn->prepare("
    SELECT 
        dp.payment_method,
        SUM(dp.debt_amount + dp.medicine_cost) AS total_with_medicine,
        SUM(dp.medicine_cost) AS total_medicine
    FROM debt_payments dp
    JOIN patients p ON dp.patient_id = p.id
    WHERE DATE(dp.repayment_date) = :today
    AND DATE(p.created_at) != :today  -- Faqat bugundan tashqari yaratilgan qarzlar
    GROUP BY dp.payment_method
");
$stmt->execute(['today' => $today]);

foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    switch ($row['payment_method']) {
        case 'naqt': $qarz_naqt = $row['total_with_medicine']; break;
        case 'terminal': $qarz_terminal = $row['total_with_medicine']; break;
        case 'click': $qarz_click = $row['total_with_medicine']; break;
    }
    $qarz_dori += $row['total_medicine'];
}

    // Bugungi to'lovlar va qarzlar (faqat qarz bo'lmaganlar)
    $query = "SELECT 
                SUM(price) AS total_income,
                SUM(CASE WHEN payment_method = 'naqt' THEN price ELSE 0 END) AS naqt,
                SUM(CASE WHEN payment_method = 'terminal' THEN price ELSE 0 END) AS terminal,
                SUM(CASE WHEN payment_method = 'click' THEN price ELSE 0 END) AS click,
                SUM(CASE WHEN debt = 1 THEN price ELSE 0 END) AS qarz
              FROM patients 
              WHERE DATE(created_at) = :today AND debt = 0";
    $stmt = $conn->prepare($query);
    $stmt->execute(['today' => $today]);
    $today_stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Bugungi chiqimlar - dori xarajatlari va boshqalari
    $query = "SELECT 
                SUM(amount) AS total_expenses,
                SUM(CASE WHEN comment LIKE '%Bemor uchun dori xarajati%' THEN amount ELSE 0 END) AS dori_xarajati,
                SUM(CASE WHEN comment NOT LIKE '%Bemor uchun dori xarajati%' THEN amount ELSE 0 END) AS boshqa_chiqimlar
              FROM expenses 
              WHERE DATE(created_at) = :today";
    
    $stmt = $conn->prepare($query);
    $stmt->execute(['today' => $today]);
    $today_expenses = $stmt->fetch(PDO::FETCH_ASSOC);

//    $jami_tushum = $today_stats['total_income'] + $today_expenses['total_expenses'];
$jami_tushum = $today_stats['total_income'] + $qarz_naqt + $qarz_click + $qarz_terminal;

//$jami_tushum = $today_stats['total_income'];

    // Bugungi xodimlar tushirgan pullar (faqat shifokorlar, id=8 shifokorini olib tashlash, faqat qarz bo'lmaganlar)
    $query = "SELECT 
                u.id AS user_id,
                u.username AS xodim,
                SUM(p.price) AS total_income
              FROM patients p
              LEFT JOIN users u ON p.doctor_id = u.id
              WHERE DATE(p.created_at) = :date AND p.doctor_id != 8 AND p.debt = 0
              GROUP BY u.id, u.username";
    $stmt = $conn->prepare($query);
    $stmt->execute(['date' => $today]);
    $today_employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // id=8 shifokorga biriktirilgan bemorlardan tushgan pullar (Ulush ustunini olib tashlash, faqat qarz bo'lmaganlar)
    $query = "SELECT 
                u.id AS user_id,
                u.username AS hamshira,
                SUM(p.price) AS total_income
              FROM patients p
              LEFT JOIN users u ON p.nurse_id = u.id
              WHERE p.doctor_id = 8 AND DATE(p.created_at) = :today AND p.debt = 0
              GROUP BY u.id, u.username";
    $stmt = $conn->prepare($query);
    $stmt->execute(['today' => $today]);
    $doctor_8_patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Bugungi xizmat turlari bo'yicha statistikani olish (faqat qarz bo'lmaganlar)
    $query = "SELECT 
                s.name AS xizmat_nomi,
                COUNT(p.id) AS bemorlar_soni,
                SUM(p.price) AS jami_tushum
              FROM patients p
              LEFT JOIN services s ON p.service_id = s.id
              WHERE DATE(p.created_at) = :today AND p.debt = 0
              GROUP BY s.name";
    $stmt = $conn->prepare($query);
    $stmt->execute(['today' => $today]);
    $service_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Xizmat turlari bo'yicha nechta qilinganligi
    $query = "SELECT 
                s.name AS xizmat_nomi,
                COUNT(ps.id) AS xizmat_soni
              FROM patient_services ps
              JOIN services s ON ps.service_id = s.id
              JOIN patients p ON ps.patient_id = p.id
              WHERE DATE(p.created_at) = :today AND p.debt = 0
              GROUP BY s.name";
    $stmt = $conn->prepare($query);
    $stmt->execute(['today' => $today]);
    $services_count = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Bugungi jami qabul qilingan bemorlar soni (faqat qarz bo'lmaganlar)
    $query = "SELECT COUNT(id) AS total_patients FROM patients WHERE DATE(created_at) = :today AND debt = 0";
    $stmt = $conn->prepare($query);
    $stmt->execute(['today' => $today]);
    $total_patients = $stmt->fetch(PDO::FETCH_ASSOC)['total_patients'];

    // Xizmat turlarini `services` jadvalidan olish
    $query = "SELECT name FROM services";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $services_list = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Xabarni ko'rsatish
    if (isset($_SESSION['message'])) {
        echo "<div class='alert alert-info'>{$_SESSION['message']}</div>";
        unset($_SESSION['message']);
    }
    
    // Bugun qarz bo'lib kelgan bemorlar (debt = 1)
$query = "SELECT 
            COUNT(id) AS total_qarzdorlar,
            SUM(price) AS total_qarz_summa
          FROM patients 
          WHERE DATE(created_at) = :today
            AND debt = 1";
$stmt = $conn->prepare($query);
$stmt->execute(['today' => $today]);
$today_debtors = $stmt->fetch(PDO::FETCH_ASSOC);

    ?>

<!-- reports.php faylida head qismiga qoshiladigan kod -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">

<!-- Modal oynani yopish uchun JavaScript -->
<script>
$(document).ready(function() {
    // Modalni yopish
    $('.modal .close, .modal .btn-secondary').click(function() {
        $(this).closest('.modal').modal('hide');
    });
    
    // ESC tugmasi bilan yopish
    $(document).keyup(function(e) {
        if (e.key === "Escape") {
            $('.modal').modal('hide');
        }
    });
});
</script>
    <style>
        /* Yangi stil qismi */
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border: none;
            margin-bottom: 20px;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
        .card-body {
            padding: 1.5rem;
        }
        .card-title {
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        .card-text {
            font-size: 1.5rem;
            font-weight: 700;
        }
        .table-responsive {
            margin-bottom: 30px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .table {
            margin-bottom: 0;
        }
        .table thead th {
            background-color: #4e73df;
            color: white;
            border: none;
            padding: 15px;
            font-weight: 600;
        }
        .table tbody tr {
            transition: all 0.2s ease;
        }
        .table tbody tr:hover {
            background-color: #f8f9fc;
            transform: scale(1.01);
        }
        .table tbody td {
            padding: 12px 15px;
            vertical-align: middle;
            border-top: 1px solid #e3e6f0;
        }
        .table-bordered {
            border: none;
        }
        .table-bordered th, 
        .table-bordered td {
            border: 1px solid #e3e6f0;
        }
        h1, h2 {
            color: #2e3a59;
            margin-bottom: 1.5rem;
            font-weight: 700;
        }
        h2 {
            font-size: 1.5rem;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
        .container {
            background-color: #f8f9fc;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .bg-primary {
            background-color: #4e73df !important;
        }
        .bg-danger {
            background-color: #e74a3b !important;
        }
        .bg-warning {
            background-color: #f6c23e !important;
        }
        .bg-info {
            background-color: #36b9cc !important;
        }
        .bg-success {
            background-color: #1cc88a !important;
        }
        
        /* Modal uchun yangi stillar */
        .modal-content {
            border-radius: 10px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .modal-header {
            background-color: #4e73df;
            color: white;
            border-radius: 10px 10px 0 0;
            padding: 15px 20px;
        }
        .modal-title {
            font-weight: 600;
        }
        .modal-body {
            padding: 20px;
        }
        .modal-footer {
            border-top: 1px solid #e9ecef;
            padding: 15px 20px;
        }
        .close {
            color: white;
            opacity: 1;
            text-shadow: none;
        }
        .employee-link {
            cursor: pointer;
            color: #4e73df;
            font-weight: 600;
            transition: all 0.2s ease;
        }
        .employee-link:hover {
            color: #2e59d9;
            text-decoration: underline;
        }
    </style>



    <div class="container">
        <h1>Hisobotlar</h1>

        <!-- Bugungi statistika -->
        <h2>Bugungi Statistika</h2>
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5 class="card-title">Jami Tushum</h5>
                        <p class="card-text"><?= number_format($jami_tushum, 0, '.', ',') ?> so'm</p>
                    </div>
                </div>
            </div>
            <?php if ($today_stats['naqt'] > 0): ?>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body" style="cursor: pointer;" onclick="loadPaymentPatients('naqt', 'Naqt')">

                        <h5 class="card-title">Naqt</h5>
                        <p class="card-text"><?= number_format($today_stats['naqt'], 0, '.', ',') ?> so'm</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($today_stats['terminal'] > 0): ?>
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body" style="cursor:pointer;" onclick="loadPaymentPatients('terminal', 'Terminal')">
                        <h5 class="card-title">Terminal</h5>
                        <p class="card-text"><?= number_format($today_stats['terminal'], 0, '.', ',') ?> so'm</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($today_stats['click'] > 0): ?>
            <div class="col-md-3">
                <div class="card bg-secondary text-white">
                    <div class="card-body" style="cursor:pointer;" onclick="loadPaymentPatients('click', 'Click')">
                        <h5 class="card-title">Click</h5>
                        <p class="card-text"><?= number_format($today_stats['click'], 0, '.', ',') ?> so'm</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($today_debtors['total_qarzdorlar'] > 0): ?>
            <div class="col-md-3">
                <div class="card bg-dark text-white">
                    <div class="card-body" style="cursor:pointer;" onclick="loadPaymentPatients('qarz', 'Bugungi qarzdorlar')">

                        <h5 class="card-title">Qarz</h5>
                        <p class="card-text"><?= number_format($today_debtors['total_qarz_summa'], 0, '.', ',') ?> so'm</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($today_expenses['dori_xarajati'] > 0): ?>
            <div class="col-md-3">
                <div class="card bg-danger text-white">
                    <div class="card-body" style="cursor:pointer;" onclick="loadPaymentPatients('dori', 'Bemor uchun dori chiqimlari')">
                        <h5 class="card-title">Dori Xarajati</h5>
                        <p class="card-text"><?= number_format($today_expenses['dori_xarajati'], 0, '.', ',') ?> so'm</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($today_expenses['boshqa_chiqimlar'] > 0): ?>
            <div class="col-md-3">
                <div class="card bg-warning text-white">
                    <div class="card-body" style="cursor:pointer;" onclick="loadPaymentPatients('boshqa', 'Boshqa chiqimlar')">

                        <h5 class="card-title">Boshqa Chiqimlar</h5>
                        <p class="card-text"><?= number_format($today_expenses['boshqa_chiqimlar'], 0, '.', ',') ?> so'm</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <!-- Qarzi undirilganlar -->
        <?php
        // Bugun qarzdan undirgan bemorlar soni
//$stmt = $conn->prepare("
//      SELECT COUNT(DISTINCT patient_id) AS qarzdor_soni
//    FROM debt_payments
//    WHERE DATE(repayment_date) = :today
//");
//Bugun qarz bo'lib bugun undirilganlarni chiqarib tashlab
$stmt = $conn->prepare("
    SELECT COUNT(DISTINCT dp.patient_id) AS qarzdor_soni
    FROM debt_payments dp
    JOIN patients p ON dp.patient_id = p.id
    WHERE DATE(dp.repayment_date) = :today
      AND DATE(p.created_at) != :today
");
$stmt->execute(['today' => $today]);
$qarzdor_soni = $stmt->fetchColumn() ?? 0;


?>
<?php if ($qarzdor_soni > 0): ?>
    <h2 class="mt-5">
        🧾 Bugun QARZDAN Undirilganlar 
        <span class="badge bg-dark" style="cursor:pointer;" onclick="loadPaymentPatients('qarzdan_undirilgan', 'Bugun Undirilgan Qarzlar')">
    <?= $qarzdor_soni ?> ta
</span>

    </h2>
<?php endif; ?>
<div class="row mb-4">

    <?php if ($qarz_naqt > 0): ?>
    <div class="col-md-3">
        <div class="card border-success bg-light">
            <div class="card-body text-success">
                <h5 class="card-title">
                    <i class="fas fa-wallet me-2"></i>Naqt
                </h5>
                <p class="card-text"><?= number_format($qarz_naqt, 0, '.', ',') ?> so'm</p>
                <?php if ($qarz_dori > 0): ?>
                    <small class="text-muted"><i class="fas fa-pills me-1"></i> Dori narxi bilan</small>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($qarz_terminal > 0): ?>
    <div class="col-md-3">
        <div class="card border-info bg-light">
            <div class="card-body text-info">
                <h5 class="card-title">
                    <i class="fas fa-credit-card me-2"></i>Terminal
                </h5>
                <p class="card-text"><?= number_format($qarz_terminal, 0, '.', ',') ?> so'm</p>
                <?php if ($qarz_dori > 0): ?>
                    <small class="text-muted"><i class="fas fa-pills me-1"></i> Dori narxi bilan</small>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($qarz_click > 0): ?>
    <div class="col-md-3">
        <div class="card border-secondary bg-light">
            <div class="card-body text-secondary">
                <h5 class="card-title">
                    <i class="fas fa-mobile-alt me-2"></i>Click
                </h5>
                <p class="card-text"><?= number_format($qarz_click, 0, '.', ',') ?> so'm</p>
                <?php if ($qarz_dori > 0): ?>
                    <small class="text-muted"><i class="fas fa-pills me-1"></i> Dori narxi bilan</small>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($qarz_dori > 0): ?>
    <div class="col-md-3">
        <div class="card border-danger bg-light">
            <div class="card-body text-danger">
                <h5 class="card-title">
                    <i class="fas fa-capsules me-2"></i>Dori Narxi
                </h5>
                <p class="card-text"><?= number_format($qarz_dori, 0, '.', ',') ?> so'm</p>
                <small class="text-muted">Faqat qarzdorlardan</small>
            </div>
        </div>
    </div>
    <?php endif; ?>

</div>
        <!-- Bugungi xodimlar tushirgan pullar -->
        <h2>Shifokorlar</h2>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Xodim</th>
                        <th>Jami Tushum</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($today_employees)): ?>
                        <?php foreach ($today_employees as $employee): ?>
                            <tr>
                                <td>
                                    <span class="employee-link" onclick="loadEmployeePatients(<?= $employee['user_id'] ?>, 'shifokor', '<?= htmlspecialchars($employee['xodim']) ?>')">
                                        <?= $employee['xodim'] ?>
                                    </span>
                                </td>
                                <td><?= number_format($employee['total_income'], 0, '.', ',') ?> so'm</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2" class="text-center">Bugun hech qanday ma'lumot topilmadi.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Hamshiralar -->
        <h2>Hamshiralar</h2>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Hamshira</th>
                        <th>Jami Tushum</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($doctor_8_patients)): ?>
                        <?php foreach ($doctor_8_patients as $patient): ?>
                            <tr>
                                <td>
                                    <span class="employee-link" onclick="loadEmployeePatients(<?= $patient['user_id'] ?>, 'hamshira', '<?= htmlspecialchars($patient['hamshira']) ?>')">
                                        <?= $patient['hamshira'] ?>
                                    </span>
                                </td>
                                <td><?= number_format($patient['total_income'], 0, '.', ',') ?> so'm</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2" class="text-center">Bugun hech qanday ma'lumot topilmadi.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Xizmat turlari bo'yicha statistika -->
        <h2>Bugungi jami bemorlar <span class="badge bg-primary"><?= $total_patients ?> ta</span> shundan</h2>

        
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Xizmat Nomi</th>
                        <th>Soni</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($services_count)): ?>
                        <?php foreach ($services_count as $service): ?>
                            <tr>
                                <td><?= $service['xizmat_nomi'] ?></td>
                                <td><?= $service['xizmat_soni'] ?> ta</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2" class="text-center">Bugun hech qanday ma'lumot topilmadi.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Modal oyna -->
    <div class="modal fade" id="employeePatientsModal" tabindex="-1" aria-labelledby="employeePatientsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="employeePatientsModalLabel">Xodimning Bugungi Bemorlari</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="employeePatientsContent">
                    <!-- Ma'lumotlar bu yerga yuklanadi -->
                    <div class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="sr-only">Yuklanmoqda...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
</div>
            </div>
        </div>
    </div>
    
    <!-- To'lov turlari uchun modal -->
<div class="modal fade" id="paymentPatientsModal" tabindex="-1" aria-labelledby="paymentPatientsModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="paymentPatientsModalLabel">Bemorlari</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="paymentPatientsContent">
        <!-- Ma'lumot yuklanadi -->
        <div class="text-center">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Yuklanmoqda...</span>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
      </div>
    </div>
  </div>
</div>

    <!-- JavaScript kodlari -->
    <script>
    // To'lov turi bo'yicha bemorlarni yuklash
function loadPaymentPatients(paymentType, paymentTitle) {
    $('#paymentPatientsModalLabel').text(paymentTitle + ' Bemorlari');
    $('#paymentPatientsModal').modal('show');

    $('#paymentPatientsContent').html(`
        <div class="text-center">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Yuklanmoqda...</span>
            </div>
        </div>
    `);

    $.ajax({
        url: '../includes/get_payment_patients.php',
        type: 'POST',
        data: { payment_type: paymentType },
        success: function(response) {
            $('#paymentPatientsContent').html(response);
        },
        error: function(xhr, status, error) {
            $('#paymentPatientsContent').html(`
                <div class="alert alert-danger">
                    Xatolik: ${xhr.status} - ${error}
                </div>
            `);
        }
    });
}


    // AJAX so'rovlarida error handling
function loadEmployeePatients(userId, role, employeeName) {
    $('#employeePatientsModalLabel').text(employeeName + ' - Bugungi Bemorlar');
    $('#employeePatientsModal').modal('show');
    
    $('#employeePatientsContent').html(`
        <div class="text-center">
            <div class="spinner-border text-primary" role="status">
                <span class="sr-only">Yuklanmoqda...</span>
            </div>
        </div>
    `);
    
    $.ajax({
        url: '../includes/get_employee_patients.php',
        type: 'POST',
        data: {
            user_id: userId,
            role: role,
            date: '<?= $today ?>'
        },
        success: function(response) {
            $('#employeePatientsContent').html(response);
        },
        error: function(xhr, status, error) {
            console.error("AJAX Xatosi:", status, error);
            console.error("XHR Ob'ekti:", xhr);
            $('#employeePatientsContent').html(`
                <div class="alert alert-danger">
                    Xatolik yuz berdi. Ma'lumotlarni yuklab bo'lmadi.<br>
                    Xatolik tafsilotlari: ${error}<br>
                    Status kodi: ${xhr.status}
                </div>
            `);
        }
    });
}
    </script>
<?php
} elseif (in_array($role, ['shifokor', 'hamshira'])) {
    $role = getUserRole();
    $user_id = $_SESSION['user']['id']; // Kirgan foydalanuvchi IDsi
    $today = date('Y-m-d');

    if (in_array($role, ['shifokor', 'hamshira'])) {
        $query = $conn->prepare("
            SELECT 
                ps.service_id, 
                s.name AS xizmat_nomi,
                COUNT(ps.id) AS xizmat_soni,
                SUM(p.price) AS jami_tushum,
                SUM((p.price * sp_doctor.percentage / 100) * (s.price / total.total_price)) AS shifokor_ulushi,
                SUM((p.price * sp_nurse.percentage / 100) * (s.price / total.total_price)) AS hamshira_ulushi
            FROM patient_services ps
            JOIN services s ON ps.service_id = s.id
            JOIN patients p ON ps.patient_id = p.id
            LEFT JOIN staff_percentages sp_doctor 
                ON sp_doctor.user_id = p.doctor_id AND sp_doctor.service_id = s.id
            LEFT JOIN staff_percentages sp_nurse 
                ON sp_nurse.user_id = p.nurse_id AND sp_nurse.service_id = s.id
            LEFT JOIN (
                SELECT ps.patient_id, SUM(s.price) AS total_price
                FROM patient_services ps
                JOIN services s ON ps.service_id = s.id
                GROUP BY ps.patient_id
            ) total ON total.patient_id = p.id
            WHERE DATE(p.created_at) = :today  
            AND p.price > 0  
            AND p.debt = 0
            " . ($role == 'shifokor' ? "AND p.doctor_id = :user_id" : "AND p.nurse_id = :user_id") . "
            " . ($role == 'hamshira' ? "AND (sp_nurse.percentage > 0 OR sp_nurse.percentage IS NOT NULL)" : "") . "
            GROUP BY ps.service_id, s.name
            ORDER BY s.name
        ");

        $query->execute(['today' => date('Y-m-d'), 'user_id' => $user_id]);
        $service_stats = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    ?>
    <script>
$(document).ready(function() {
    // Modalni yopish uchun funksiya
    $(document).on('click', '[data-bs-dismiss="modal"]', function() {
        $('#serviceDetailsModal').modal('hide');
    });

    // Xizmat turlarini bosish funksiyasi
    window.loadServiceDetails = function(serviceId, serviceName) {
        // Modal sarlavhasini o'zgartirish
        $('#serviceDetailsModalLabel').text(serviceName + ' - Bemorlar');
        
        // Modalni ochish
        var modal = new bootstrap.Modal(document.getElementById('serviceDetailsModal'));
        modal.show();
        
        // Yuklash animatsiyasini ko'rsatish
        $('#serviceDetailsContent').html(`
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Yuklanmoqda...</span>
                </div>
                <p class="mt-2">Ma'lumotlar yuklanmoqda...</p>
            </div>
        `);
        
        // AJAX so'rovini yuborish
        $.ajax({
            url: '../includes/get_service_details_dash.php',
            type: 'POST',
            data: {
                service_id: serviceId,
                user_id: <?= $user_id ?>,
                role: '<?= $role ?>',
                date: '<?= $today ?>'
            },
            success: function(response) {
                $('#serviceDetailsContent').html(response);
            },
            error: function(xhr, status, error) {
                console.error("AJAX xatosi:", status, error);
                $('#serviceDetailsContent').html(`
                    <div class="alert alert-danger">
                        <h5>Xatolik yuz berdi!</h5>
                        <p>Ma'lumotlarni yuklab bo'lmadi.</p>
                        <p class="small">${xhr.status}: ${error}</p>
                    </div>
                `);
            }
        });
    };
});
</script>
    <!-- Qolgan HTML va JavaScript kodlari o'zgarishsiz qoldi -->
    <style>
        /* Shifokor/hamshira uchun stil */
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border: none;
            margin-bottom: 20px;
        }
        .table-responsive {
            margin-bottom: 30px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .table {
            margin-bottom: 0;
        }
        .table thead th {
            background-color: #4e73df;
            color: white;
            border: none;
            padding: 15px;
            font-weight: 600;
        }
        .table tbody tr {
            transition: all 0.2s ease;
        }
        .table tbody tr:hover {
            background-color: #f8f9fc;
            transform: scale(1.01);
        }
        .table tbody td {
            padding: 12px 15px;
            vertical-align: middle;
            border-top: 1px solid #e3e6f0;
        }
        h1, h2 {
            color: #2e3a59;
            margin-bottom: 1.5rem;
            font-weight: 700;
        }
        .container {
            background-color: #f8f9fc;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        /* Xizmat turlari uchun link */
        .service-link {
            cursor: pointer;
            color: #4e73df;
            font-weight: 600;
            transition: all 0.2s ease;
        }
        .service-link:hover {
            color: #2e59d9;
            text-decoration: underline;
        }
    </style>

    <div class="container">
        <h1>Bugungi Xizmat Turlari Bo'yicha Bemorlarim</h1>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Xizmat Nomi</th>
                        <th>Xizmatlar Soni</th>
                        <th>Jami Tushum</th>
                        <?php if ($role != 'hamshira'): ?>
                        <th>Ulushingiz</th>
                        <?php endif; ?>
                        <?php if ($role != 'shifokor'): ?>
                        <th>Ulushingiz.</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($service_stats)): ?>
                        <?php foreach ($service_stats as $service): ?>
                            <tr>
                                <td>
<span class="service-link" data-service-id="<?= $service['service_id'] ?>" 
      data-service-name="<?= htmlspecialchars($service['xizmat_nomi']) ?>">
    <?= htmlspecialchars($service['xizmat_nomi']) ?>
</span>
                                </td>
                                <td><?= $service['xizmat_soni'] ?> ta</td>
                                <td><?= number_format($service['jami_tushum'], 0, '.', ',') ?> so'm</td>
                                <?php if ($role != 'hamshira'): ?>
                                <td><?= number_format($service['shifokor_ulushi'] ?? 0, 0, '.', ',') ?> so'm</td>
                                <?php endif; ?>
                                <?php if ($role != 'shifokor'): ?>
                                <td><?= number_format($service['hamshira_ulushi'] ?? 0, 0, '.', ',') ?> so'm</td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="<?= $role == 'shifokor' ? 4 : 5 ?>" class="text-center">Bugun hech qanday ma'lumot topilmadi.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Xodimlar statistikasi -->
    <div class="row">
        <div class="col-12">
            <?php include 'employee_stats.php'; ?>
        </div>
    </div>
    <!-- Modal oyna -->
    <div class="modal fade" id="serviceDetailsModal" tabindex="-1" aria-labelledby="serviceDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="serviceDetailsModalLabel">Xizmat Bo'yicha Bemorlaringiz</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="serviceDetailsContent">
                    <!-- Ma'lumotlar bu yerga yuklanadi -->
                    <div class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="sr-only">Yuklanmoqda...</span>
                        </div>
                    </div>
                </div>
                <!-- Modal footer qismini quyidagicha o'zgartiring -->
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
</div>
            </div>
        </div>
    </div>
    
    <!-- JavaScript kodlari -->

<?php
} else {
    redirect('login.php');
}
?>
<?php include './../includes/medical_jokes.php'; ?>

</html>
</body>