<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
$title = "Bemorlar Boshqaruvi";
ob_start();

// Xatoliklarni ko'rsatish (development uchun)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Avtorizatsiya tekshiruvi
if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole();
$user_id = $_SESSION['user']['id'];

// Kassir uchun faqat bugungi bemorlarni ko'rsatish
$is_kassir = ($role === 'kassir');
$show_deleted = isset($_GET['show_deleted']) && $_GET['show_deleted'] == '1' && $role === 'rahbar';

$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

// Sana oralig'ini sozlash (rahbar uchun)
$start_date = $is_kassir ? date('Y-m-d') : ($_GET['start_date'] ?? date('Y-m-01'));
$end_date = $is_kassir ? date('Y-m-d') : ($_GET['end_date'] ?? date('Y-m-d'));

// Sana formati tekshiruvi
if (!empty($_GET['start_date']) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['start_date'])) {
    $start_date = date('Y-m-01');
}
if (!empty($_GET['end_date']) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['end_date'])) {
    $end_date = date('Y-m-d');
}

// Tanlangan davr uchun bemorlarni olish funksiyasi
function getPatientsByDateRange($conn, $start_date, $end_date, $is_deleted = false) {
    if ($is_deleted) {
        $query = "
            SELECT dp.*, 
                   u1.username AS doctor_name,
                   u2.username AS nurse_name,
                   u3.username AS cashier_name,
                   u4.username AS deleted_by_name,
                   u5.username AS created_by_name
            FROM deleted_patients dp
            LEFT JOIN users u1 ON dp.doctor_id = u1.id
            LEFT JOIN users u2 ON dp.nurse_id = u2.id
            LEFT JOIN users u3 ON dp.cashier_id = u3.id
            LEFT JOIN users u4 ON dp.deleted_by = u4.id
            LEFT JOIN users u5 ON dp.created_by = u5.id
            WHERE DATE(dp.deleted_at) BETWEEN :start_date AND :end_date
            ORDER BY dp.deleted_at DESC
            LIMIT 1000
        ";
    } else {
        $query = "
            SELECT p.*, 
                   GROUP_CONCAT(s.name SEPARATOR ', ') AS service_names, 
                   u1.username AS doctor_name, 
                   u2.username AS nurse_name, 
                   u3.username AS cashier_name,
                   u4.username AS created_by_name,
                   (SELECT SUM(amount) FROM expenses WHERE patient_id = p.id AND type = 'Dorilar') AS medicine_cost,
                   (SELECT COUNT(*) FROM payment_history WHERE patient_id = p.id) AS change_count
            FROM patients p 
            LEFT JOIN patient_services ps ON p.id = ps.patient_id 
            LEFT JOIN services s ON ps.service_id = s.id 
            LEFT JOIN users u1 ON p.doctor_id = u1.id 
            LEFT JOIN users u2 ON p.nurse_id = u2.id 
            LEFT JOIN users u3 ON p.cashier_id = u3.id 
            LEFT JOIN users u4 ON p.cashier_id = u4.id
            WHERE DATE(p.date) BETWEEN :start_date AND :end_date
            GROUP BY p.id 
            ORDER BY p.created_at DESC
            LIMIT 1000
        ";
    }
    
    $stmt = $conn->prepare($query);
    $stmt->execute([
        'start_date' => $start_date,
        'end_date' => $end_date
    ]);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// To'lov usulini o'zgartirish
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_payment'])) {
    try {
        $patient_id = intval($_POST['patient_id']);
        $new_payment_method = $_POST['payment_method'];
        $new_debt_status = isset($_POST['debt']) ? 1 : 0;
        $phone_number = $new_debt_status ? trim($_POST['phone_number']) : null;

        // Bemor ma'lumotlarini olish
        $stmt = $conn->prepare("SELECT p.*, 
                               u.username AS doctor_name, 
                               u2.username AS nurse_name, 
                               u3.username AS cashier_name
                               FROM patients p
                               LEFT JOIN users u ON p.doctor_id = u.id
                               LEFT JOIN users u2 ON p.nurse_id = u2.id
                               LEFT JOIN users u3 ON p.cashier_id = u3.id
                               WHERE p.id = ?");
        $stmt->execute([$patient_id]);
        $patient = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$patient) {
            throw new Exception("Bemor topilmadi!");
        }

        $old_payment_method = $patient['payment_method'];
        $old_debt_status = $patient['debt'];

        // Agar qarz holati o'zgarsa
        if ($new_debt_status != $old_debt_status) {
            if ($new_debt_status && (empty($phone_number) || !preg_match('/^\+998\d{9}$/', $phone_number))) {
                throw new Exception("Telefon raqam noto'g'ri formatda. Iltimos, +998901234567 formatida kiriting.");
            }

            // Qarzga o'tkazilganda xodimlarning daromadlarini kamaytirish
            if ($new_debt_status && !$old_debt_status) {
                deductStaffIncome($conn, $patient_id, $patient['doctor_id'], $patient['nurse_id'], $patient['cashier_id']);
            }
            // Qarz to'landa xodimlarning daromadlarini qo'shish
            elseif (!$new_debt_status && $old_debt_status) {
                addStaffIncome($conn, $patient_id, $patient['doctor_id'], $patient['nurse_id'], $patient['cashier_id']);
            }
        }

        // Bemor ma'lumotlarini yangilash
//        $stmt = $conn->prepare("UPDATE patients SET payment_method = ?, debt = ?, phone_number = ? WHERE id = ?");
//        $stmt->execute([$new_payment_method, $new_debt_status, $phone_number, $patient_id]);
$new_full_name = trim($_POST['full_name']);
$new_birth_year = intval($_POST['birth_year']);

$stmt = $conn->prepare("UPDATE patients SET payment_method = ?, debt = ?, phone_number = ?, full_name = ?, birth_year = ? WHERE id = ?");
$stmt->execute([$new_payment_method, $new_debt_status, $phone_number, $new_full_name, $new_birth_year, $patient_id]);


        // O'zgarishlar tarixiga yozish
        $stmt = $conn->prepare("INSERT INTO payment_history 
            (patient_id, old_payment_method, new_payment_method, old_debt_status, new_debt_status, changed_by) 
            VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $patient_id, 
            $old_payment_method, 
            $new_payment_method, 
            $old_debt_status, 
            $new_debt_status, 
            $user_id
        ]);

        // Telegramga xabar yuborish
        $changed_by = $_SESSION['user']['username'];
        $message = "🔄 <b>Bemor ma'lumotlari o'zgartirildi</b>\n\n";
        $message .= "👤 <b>Bemor:</b> " . htmlspecialchars($patient['full_name']) . "\n";
        $message .= "📅 <b>Tug'ilgan yili:</b> " . $patient['birth_year'] . "\n";
        
        $message .= "\n📌 <b>Eski ma'lumotlar:</b>\n";
        $message .= "💳 To'lov usuli: " . ucfirst($old_payment_method) . "\n";
        $message .= "💰 Qarz holati: " . ($old_debt_status ? "Ha" : "Yo'q") . "\n";
        
        $message .= "\n🆕 <b>Yangi ma'lumotlar:</b>\n";
        $message .= "💳 To'lov usuli: " . ucfirst($new_payment_method) . "\n";
        $message .= "💰 Qarz holati: " . ($new_debt_status ? "Ha" : "Yo'q") . "\n";
        
        if ($new_debt_status) {
            $message .= "📱 Telefon: " . ($phone_number ?? 'Koʻrsatilmagan') . "\n";
        }
        
        $message .= "\n👤 <b>O'zgartirgan:</b> " . $changed_by . "\n";
        $message .= "⏰ <b>Vaqt:</b> " . date('Y-m-d H:i:s') . "\n";
        
        // Rahbarga xabar
        $admin_id = $conn->query("SELECT id FROM users WHERE role = 'rahbar' LIMIT 1")->fetchColumn();
        if ($admin_id) {
            $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = :admin_id");
            $stmt->execute(['admin_id' => $admin_id]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($admin && $admin['telegram_id']) {
                sendTelegramMessage($admin['telegram_id'], $message, 'HTML');
            }
        }

        // Shifokorga xabar
        if ($patient['doctor_id']) {
            $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = ?");
            $stmt->execute([$patient['doctor_id']]);
            $doctor = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($doctor && $doctor['telegram_id']) {
                $doctor_message = "ℹ️ <b>Bemoringizning to'lov ma'lumotlari o'zgartirildi</b>\n\n";
                $doctor_message .= "👤 <b>Bemor:</b> " . htmlspecialchars($patient['full_name']) . "\n";
                $doctor_message .= "💳 <b>Yangi to'lov usuli:</b> " . ucfirst($new_payment_method) . "\n";
                $doctor_message .= "💰 <b>Qarz holati:</b> " . ($new_debt_status ? "Ha" : "Yo'q") . "\n";
                $doctor_message .= "👤 <b>O'zgartirgan:</b> " . $changed_by . "\n";
                
                sendTelegramMessage($doctor['telegram_id'], $doctor_message, 'HTML');
            }
        }

        // Hamshiraga xabar
        if ($patient['nurse_id']) {
            $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = ?");
            $stmt->execute([$patient['nurse_id']]);
            $nurse = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($nurse && $nurse['telegram_id']) {
                $nurse_message = "ℹ️ <b>Bemoringizning to'lov ma'lumotlari o'zgartirildi</b>\n\n";
                $nurse_message .= "👤 <b>Bemor:</b> " . htmlspecialchars($patient['full_name']) . "\n";
                $nurse_message .= "💳 <b>Yangi to'lov usuli:</b> " . ucfirst($new_payment_method) . "\n";
                $nurse_message .= "💰 <b>Qarz holati:</b> " . ($new_debt_status ? "Ha" : "Yo'q") . "\n";
                $nurse_message .= "👤 <b>O'zgartirgan:</b> " . $changed_by . "\n";
                
                sendTelegramMessage($nurse['telegram_id'], $nurse_message, 'HTML');
            }
        }

        // Kassirga xabar
        if ($patient['cashier_id']) {
            $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = ?");
            $stmt->execute([$patient['cashier_id']]);
            $cashier = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($cashier && $cashier['telegram_id']) {
                $cashier_message = "ℹ️ <b>Bemoringizning to'lov ma'lumotlari o'zgartirildi</b>\n\n";
                $cashier_message .= "👤 <b>Bemor:</b> " . htmlspecialchars($patient['full_name']) . "\n";
                $cashier_message .= "💳 <b>Yangi to'lov usuli:</b> " . ucfirst($new_payment_method) . "\n";
                $cashier_message .= "💰 <b>Qarz holati:</b> " . ($new_debt_status ? "Ha" : "Yo'q") . "\n";
                $cashier_message .= "👤 <b>O'zgartirgan:</b> " . $changed_by . "\n";
                
                sendTelegramMessage($cashier['telegram_id'], $cashier_message, 'HTML');
            }
        }

        $message = "Bemor to'lov ma'lumotlari muvaffaqiyatli yangilandi!";
    } catch (Exception $e) {
        $message = $e->getMessage();
    }
}

// Bemorni o'chirish funksiyasi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_patient'])) {
    try {
        if ($role !== 'rahbar') {
            throw new Exception("Faqat rahbarlar bemorlarni o'chira oladi!");
        }

        $patient_id = intval($_POST['patient_id']);
        $delete_reason = trim($_POST['delete_reason']);
        
        if (empty($delete_reason)) {
            throw new Exception("Bemorni o'chirish sababini ko'rsating!");
        }

        // Transaction boshlash
        $conn->beginTransaction();

        // Bemor ma'lumotlarini olish
        $stmt = $conn->prepare("
            SELECT p.*, 
                   GROUP_CONCAT(s.name SEPARATOR ', ') AS service_names,
                   u1.username AS doctor_name,
                   u2.username AS nurse_name,
                   u3.username AS cashier_name,
                   u4.username AS created_by_name
            FROM patients p
            LEFT JOIN patient_services ps ON p.id = ps.patient_id
            LEFT JOIN services s ON ps.service_id = s.id
            LEFT JOIN users u1 ON p.doctor_id = u1.id
            LEFT JOIN users u2 ON p.nurse_id = u2.id
            LEFT JOIN users u3 ON p.cashier_id = u3.id
            LEFT JOIN users u4 ON p.cashier_id = u4.id
            WHERE p.id = ?
            GROUP BY p.id
        ");
        $stmt->execute([$patient_id]);
        $patient = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$patient) {
            throw new Exception("Bemor topilmadi!");
        }

        // Agar qarz bo'lmasa, xodimlarning daromadlarini qaytarish
        if (!$patient['debt']) {
            if ($patient['doctor_id']) {
                $stmt = $conn->prepare("UPDATE users SET total_income = total_income - ? WHERE id = ?");
                $stmt->execute([$patient['doctor_income'], $patient['doctor_id']]);
            }

            if ($patient['nurse_id']) {
                $stmt = $conn->prepare("UPDATE users SET total_income = total_income - ? WHERE id = ?");
                $stmt->execute([$patient['nurse_income'], $patient['nurse_id']]);
            }

            if ($patient['cashier_id']) {
                $stmt = $conn->prepare("UPDATE users SET total_income = total_income - ? WHERE id = ?");
                $stmt->execute([$patient['kassir_income'], $patient['cashier_id']]);
            }
        }

        // Bemor ma'lumotlarini arxivga saqlash
        $stmt = $conn->prepare("
    INSERT INTO deleted_patients (
        original_patient_id, full_name, birth_year, price, 
        payment_method, debt, phone_number, medicine_cost,
        doctor_id, nurse_id, cashier_id, service_names,
        created_at, created_by, deleted_by, delete_reason, deleted_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

$stmt->execute([
    $patient['id'],
    $patient['full_name'],
    $patient['birth_year'],
    $patient['price'],
    $patient['payment_method'],
    $patient['debt'],
    $patient['phone_number'],
    $patient['medicine_cost'] ?? 0,
    $patient['doctor_id'],
    $patient['nurse_id'],
    $patient['cashier_id'],
    $patient['service_names'],
    $patient['created_at'],
    $patient['cashier_id'],
    $user_id,                  // deleted_by
    $delete_reason,
    date('Y-m-d H:i:s')        // ✅ hozirgi vaqtni deleted_at sifatida yozish
]);


        // Bog'liq jadvallardan o'chirish
        $conn->prepare("DELETE FROM patient_services WHERE patient_id = ?")->execute([$patient_id]);
        $conn->prepare("DELETE FROM expenses WHERE patient_id = ?")->execute([$patient_id]);
        //Qarz undirilgan bo'lsa uni ham
        $conn->prepare("DELETE FROM debt_payments WHERE patient_id = ?")->execute([$patient_id]);
        $conn->prepare("DELETE FROM patients WHERE id = ?")->execute([$patient_id]);

        $conn->commit();

        // Telegramga xabarlar yuborish
        $deleted_by = $_SESSION['user']['username'];
        $message = "🗑️ <b>Bemor o'chirildi</b>\n\n";
        $message .= "👤 <b>Bemor:</b> " . htmlspecialchars($patient['full_name']) . "\n";
        $message .= "📅 <b>Tug'ilgan yili:</b> " . $patient['birth_year'] . "\n";
        $message .= "👨‍⚕️ <b>Shifokor:</b> " . ($patient['doctor_name'] ?? 'Nomaʼlum') . "\n";
        $message .= "💊 <b>Hamshira:</b> " . ($patient['nurse_name'] ?? 'Nomaʼlum') . "\n";
        $message .= "💰 <b>Kassir:</b> " . ($patient['cashier_name'] ?? 'Nomaʼlum') . "\n";
        $message .= "📝 <b>Sabab:</b> " . htmlspecialchars($delete_reason) . "\n";
        $message .= "👤 <b>O'chirgan:</b> " . $deleted_by . "\n";
        $message .= "⏰ <b>Vaqt:</b> " . date('Y-m-d H:i:s') . "\n";

        // Rahbarga xabar
        $admin_id = $conn->query("SELECT id FROM users WHERE role = 'rahbar' LIMIT 1")->fetchColumn();
        if ($admin_id) {
            $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = ?");
            $stmt->execute([$admin_id]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($admin && $admin['telegram_id']) {
                sendTelegramMessage($admin['telegram_id'], $message, 'HTML');
            }
        }

        // Shifokorga xabar
        if ($patient['doctor_id']) {
            $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = ?");
            $stmt->execute([$patient['doctor_id']]);
            $doctor = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($doctor && $doctor['telegram_id']) {
                sendTelegramMessage($doctor['telegram_id'], $message, 'HTML');
            }
        }

        // Hamshiraga xabar
        if ($patient['nurse_id']) {
            $stmt = $conn->prepare("SELECT telegram_id FROM users WHERE id = ?");
            $stmt->execute([$patient['nurse_id']]);
            $nurse = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($nurse && $nurse['telegram_id']) {
                sendTelegramMessage($nurse['telegram_id'], $message, 'HTML');
            }
        }

        $_SESSION['message'] = "Bemor muvaffaqiyatli o'chirildi va arxivlandi";
        redirect('patients_management.php?start_date='.$start_date.'&end_date='.$end_date);

    } catch (Exception $e) {
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        $message = "Xatolik: ".$e->getMessage();
        error_log("Patient deletion error: ".$e->getMessage());
    }
}

// Xodimlarning daromadlarini kamaytirish (qarzga o'tkazilganda)
function deductStaffIncome($conn, $patient_id, $doctor_id, $nurse_id, $cashier_id) {
    $stmt = $conn->prepare("SELECT doctor_income, nurse_income, kassir_income FROM patients WHERE id = ?");
    $stmt->execute([$patient_id]);
    $incomes = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$incomes) return;

    if ($doctor_id && $incomes['doctor_income'] > 0) {
        $stmt = $conn->prepare("UPDATE users SET total_income = total_income - ? WHERE id = ?");
        $stmt->execute([$incomes['doctor_income'], $doctor_id]);
    }

    if ($nurse_id && $incomes['nurse_income'] > 0) {
        $stmt = $conn->prepare("UPDATE users SET total_income = total_income - ? WHERE id = ?");
        $stmt->execute([$incomes['nurse_income'], $nurse_id]);
    }

    if ($cashier_id && $incomes['kassir_income'] > 0) {
        $stmt = $conn->prepare("UPDATE users SET total_income = total_income - ? WHERE id = ?");
        $stmt->execute([$incomes['kassir_income'], $cashier_id]);
    }
}

// Xodimlarning daromadlarini qo'shish (qarz to'langanda)
function addStaffIncome($conn, $patient_id, $doctor_id, $nurse_id, $cashier_id) {
    $stmt = $conn->prepare("SELECT doctor_income, nurse_income, kassir_income FROM patients WHERE id = ?");
    $stmt->execute([$patient_id]);
    $incomes = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$incomes) return;

    if ($doctor_id && $incomes['doctor_income'] > 0) {
        $stmt = $conn->prepare("UPDATE users SET total_income = total_income + ? WHERE id = ?");
        $stmt->execute([$incomes['doctor_income'], $doctor_id]);
    }

    if ($nurse_id && $incomes['nurse_income'] > 0) {
        $stmt = $conn->prepare("UPDATE users SET total_income = total_income + ? WHERE id = ?");
        $stmt->execute([$incomes['nurse_income'], $nurse_id]);
    }

    if ($cashier_id && $incomes['kassir_income'] > 0) {
        $stmt = $conn->prepare("UPDATE users SET total_income = total_income + ? WHERE id = ?");
        $stmt->execute([$incomes['kassir_income'], $cashier_id]);
    }
}

// Bemorning to'lov tarixini olish
function getPaymentHistory($conn, $patient_id) {
    $stmt = $conn->prepare("
        SELECT ph.*, u.username AS changed_by_name 
        FROM payment_history ph
        JOIN users u ON ph.changed_by = u.id
        WHERE ph.patient_id = ?
        ORDER BY ph.changed_at DESC
    ");
    $stmt->execute([$patient_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Bemorlarni yuklash
if ($show_deleted) {
    $patients = getPatientsByDateRange($conn, $start_date, $end_date, true);
} else {
    $patients = getPatientsByDateRange($conn, $start_date, $end_date);
}

$content = ob_get_clean();
include '../includes/head.php';
?>


<div class="container">
    <h1>Bemorlar Boshqaruvi</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <!-- Sana oralig'i formasi -->
    <form method="GET" class="mb-4">
        <div class="row g-3 align-items-end">
            <?php if (!$is_kassir): ?>
                <div class="col-md-3">
                    <label for="start_date" class="form-label">Boshlanish sanasi</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" 
                           value="<?= htmlspecialchars($start_date) ?>" <?= $is_kassir ? 'disabled' : '' ?>>
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label">Tugash sanasi</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" 
                           value="<?= htmlspecialchars($end_date) ?>" <?= $is_kassir ? 'disabled' : '' ?>>
                </div>
            <?php endif; ?>
                        <?php if ($role === 'rahbar'): ?>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Filtr</button>
            </div>

                <div class="col-md-2">
                    <a href="?show_deleted=<?= $show_deleted ? '0' : '1' ?>&start_date=<?= $start_date ?>&end_date=<?= $end_date ?>" 
                       class="btn btn-<?= $show_deleted ? 'primary' : 'secondary' ?> w-100">
                        <?= $show_deleted ? 'Faol bemorlar' : 'Arxiv' ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </form>

    <h2><?= $show_deleted ? 'O\'chirilgan Bemorlar' : ($is_kassir ? 'Bugungi Bemorlar' : 'Bemorlar Ro\'yxati') ?> 
        <small class="text-muted">(<?= date('d.m.Y', strtotime($start_date)) ?> - <?= date('d.m.Y', strtotime($end_date)) ?>)</small>
    </h2>
    
    <div class="table-responsive">
        <table id="patientsTable" class="table table-bordered table-hover">

            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Ism</th>
                    <th>Yil</th>
                    <th>Tel</th>
                    <th>Xizmatlar</th>
                    <th>Shifokor</th>
                    <th>Hamshira</th>
                    <th>Kassir</th>
                    <th>Narxi</th>
                    <th>To'lov</th>
<!--                    <th>Holat</th> -->
                    <th>Sana</th>
                    <?php if ($role === 'rahbar' && !$show_deleted): ?>
                        <th>Amallar</th>
                    <?php elseif ($show_deleted): ?>
                        <th>Sabab</th>
                        <th>O'chirgan</th>
                        <th>O'chirilgan</th>
                    <?php elseif ($role === 'kassir'): ?>
                        <th>Harakatlar</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($patients)): ?>
                    <tr>
                        <td colspan="<?= $show_deleted ? 15 : ($role === 'kassir' ? 13 : 12) ?>" class="text-center">Bemorlar topilmadi</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($patients as $index => $patient): ?>
                        <?php 
                        $total_price = $patient['price'] + ($patient['medicine_cost'] ?? 0);
                        $row_class = isset($patient['change_count']) && $patient['change_count'] > 0 ? 'table-warning' : '';
                        ?>
                        <tr class="<?= $row_class ?>">
                            <td><?= $index + 1 ?></td>
                            <td><?= htmlspecialchars($patient['full_name']) ?></td>
                            <td><?= $patient['birth_year'] ?></td>
                                    <td>
                                        <?php if (!empty($patient['phone_number'])): ?>
                                            <a href="tel:<?= $patient['phone_number'] ?>" class="text-decoration-none">
                                                <?= formatPhoneNumber($patient['phone_number']) ?>
                                            </a>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                            <td><?= $patient['service_names'] ?? '-' ?></td>
                            <td><?= $patient['doctor_name'] ?? '-' ?></td>
                            <td><?= $patient['nurse_name'] ?? '-' ?></td>
                            <td><?= $patient['cashier_name'] ?? '-' ?></td>
                            <td>
                                <?= number_format($patient['price'], 0, ',', ' ') ?> so'm
                                <?php if (($patient['medicine_cost'] ?? 0) > 0): ?>
                                    <br><small class="text-muted">+ <?= number_format($patient['medicine_cost'], 0, ',', ' ') ?> so'm dori</small>
                                    <br><strong>Jami: <?= number_format($total_price, 0, ',', ' ') ?> so'm</strong>
                                <?php endif; ?>
                            </td>
                            <td>
    <span class="<?php
        switch ($patient['payment_method']) {
            case 'naqt': echo 'badge bg-success'; break;
            case 'click': echo 'badge bg-info'; break;
            case 'terminal': echo 'badge bg-primary'; break;
            default: echo 'badge bg-secondary'; break;
        }
    ?>">
        <?= ucfirst($patient['payment_method']) ?>
    </span>
</td>

<!--                            <td>
    <span class="<?= $patient['debt'] ? 'badge bg-danger' : 'badge bg-success' ?>">
        <?= $patient['debt'] ? 'Qarzdor' : "To'langan" ?>
    </span>
</td>
-->
                            <td><?= date('d.m.Y H:i', strtotime($show_deleted ? $patient['deleted_at'] : $patient['created_at'])) ?></td>
                            
                            <?php if ($role === 'rahbar' && !$show_deleted): ?>
                                <td>
                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" 
                                        data-bs-target="#deletePatientModal<?= $patient['id'] ?>">
                                        <i class="bi bi-trash"></i> O'chirish
                                    </button>
                                    <button type="button" class="btn btn-sm btn-primary ms-1" data-bs-toggle="modal" 
                                        data-bs-target="#editPaymentModal<?= $patient['id'] ?>">
                                        Tahrirlash
                                    </button>
                                    <?php if ($patient['change_count'] > 0): ?>
                                        <button type="button" class="btn btn-sm btn-info mt-1" data-bs-toggle="modal" 
                                            data-bs-target="#historyModal<?= $patient['id'] ?>">
                                            Tarix
                                        </button>
                                    <?php endif; ?>
                                </td>
                            <?php elseif ($show_deleted): ?>
                                <td><?= htmlspecialchars($patient['delete_reason']) ?></td>
                                <td><?= $patient['deleted_by_name'] ?? 'Noma\'lum' ?></td>
                                <td><?= date('d.m.Y H:i', strtotime($patient['deleted_at'])) ?></td>
                            <?php elseif ($role === 'kassir'): ?>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" 
                                        data-bs-target="#editPaymentModal<?= $patient['id'] ?>">
                                        Tahrirlash
                                    </button>
                                    <?php if ($patient['change_count'] > 0): ?>
                                        <button type="button" class="btn btn-sm btn-info mt-1" data-bs-toggle="modal" 
                                            data-bs-target="#historyModal<?= $patient['id'] ?>">
                                            Tarix
                                        </button>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php foreach ($patients as $patient): ?>
    <?php if (!$show_deleted): ?>
        <!-- Tahrirlash modali -->
        <div class="modal fade" id="editPaymentModal<?= $patient['id'] ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">To'lovni Tahrirlash</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST">
                        <div class="modal-body">
                            <input type="hidden" name="patient_id" value="<?= $patient['id'] ?>">
                            <div class="mb-3">
    <label class="form-label">F.I.Sh</label>
    <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($patient['full_name']) ?>" required>
</div>

<div class="mb-3">
    <label class="form-label">Tug'ilgan yili</label>
    <input type="number" name="birth_year" class="form-control" min="1900" max="<?= date('Y') ?>" value="<?= $patient['birth_year'] ?>" required>
</div>

                            <div class="mb-3">
                                <label class="form-label">To'lov usuli</label>
                                <select name="payment_method" class="form-select" required>
                                    <option value="naqt" <?= $patient['payment_method'] == 'naqt' ? 'selected' : '' ?>>Naqt</option>
                                    <option value="terminal" <?= $patient['payment_method'] == 'terminal' ? 'selected' : '' ?>>Terminal</option>
                                    <option value="click" <?= $patient['payment_method'] == 'click' ? 'selected' : '' ?>>Click</option>
                                </select>
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" name="debt" class="form-check-input" id="debt<?= $patient['id'] ?>" 
                                    <?= $patient['debt'] ? 'checked' : '' ?> onchange="togglePhoneNumberField(this, '<?= $patient['id'] ?>')">
                                <label class="form-check-label" for="debt<?= $patient['id'] ?>">Qarz</label>
                            </div>
                            
                            <div class="mb-3" id="phoneNumberField<?= $patient['id'] ?>" style="<?= $patient['debt'] ? '' : 'display: none;' ?>">
                                <label class="form-label">Telefon raqam</label>
                                <input type="text" name="phone_number" class="form-control" 
                                    value="<?= $patient['phone_number'] ?? '+998' ?>" id="phoneInput<?= $patient['id'] ?>">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Bekor qilish</button>
                            <button type="submit" name="update_payment" class="btn btn-primary">Saqlash</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Bemor o'chirish modali -->
        <div class="modal fade" id="deletePatientModal<?= $patient['id'] ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Bemorni O'chirish</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST">
                        <div class="modal-body">
                            <input type="hidden" name="patient_id" value="<?= $patient['id'] ?>">
                            
                            <div class="mb-3">
                                <label class="form-label">O'chirish sababi</label>
                                <textarea name="delete_reason" class="form-control" rows="3" required></textarea>
                            </div>
                            
                            <div class="alert alert-warning">
                                <strong>Diqqat!</strong> Ushbu bemor butunlay o'chiriladi va faqat arxivda saqlanib qoladi.
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Bekor qilish</button>
                            <button type="submit" name="delete_patient" class="btn btn-danger">O'chirish</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Tarix modali (faqat o'zgartirilgan bemorlar uchun) -->
        <?php if (isset($patient['change_count']) && $patient['change_count'] > 0): ?>
            <div class="modal fade" id="historyModal<?= $patient['id'] ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">To'lov Tarixi: <?= htmlspecialchars($patient['full_name']) ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php $history = getPaymentHistory($conn, $patient['id']); ?>
                            
                            <?php if (empty($history)): ?>
                                <p>To'lov ma'lumotlarida o'zgartirishlar mavjud emas.</p>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Eski to'lov usuli</th>
                                                <th>Yangi to'lov usuli</th>
                                                <th>Eski qarz holati</th>
                                                <th>Yangi qarz holati</th>
                                                <th>O'zgartirgan</th>
                                                <th>Vaqt</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($history as $index => $record): ?>
                                                <tr>
                                                    <td><?= $index + 1 ?></td>
                                                    <td><?= $record['old_payment_method'] ?></td>
                                                    <td><?= $record['new_payment_method'] ?></td>
                                                    <td><?= $record['old_debt_status'] ? 'Ha' : 'Yo\'q' ?></td>
                                                    <td><?= $record['new_debt_status'] ? 'Ha' : 'Yo\'q' ?></td>
                                                    <td><?= $record['changed_by_name'] ?></td>
                                                    <td><?= $record['changed_at'] ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php endforeach; ?>
<script>


// Telefon raqam maydonini boshqarish
function togglePhoneNumberField(checkbox, patientId) {
    const phoneNumberField = document.getElementById('phoneNumberField' + patientId);
    const phoneInput = document.getElementById('phoneInput' + patientId);

    if (checkbox.checked) {
        phoneNumberField.style.display = 'block';
        phoneInput.setAttribute('required', true);
        if (!phoneInput.value) {
            phoneInput.value = '+998';
        }
    } else {
        phoneNumberField.style.display = 'none';
        phoneInput.removeAttribute('required');
    }
}

// Telefon raqamini formatlash
document.querySelectorAll('[id^="phoneInput"]').forEach(input => {
    input.addEventListener('input', function(e) {
        const value = e.target.value;

        if (!value.startsWith('+998')) {
            e.target.value = '+998' + value.replace(/[^0-9]/g, '');
        }

        if (value.length > 13) {
            e.target.value = value.slice(0, 13);
        }
    });
});
// dragdroppppp
$(function () {
    let savedOrder = JSON.parse(localStorage.getItem("columnOrder") || "[]");

    function applyOrder(order) {
        const $thead = $('table thead tr');
        const $tbody = $('table tbody tr');
        if (order.length) {
            // Ustunlarni thead da o‘zgartirish
            const $th = $thead.children();
            const sortedTh = order.map(i => $th.eq(i));
            $thead.html(sortedTh);

            // Har bir tr uchun tdan tartibni o‘zgartirish
            $tbody.each(function () {
                const $td = $(this).children();
                const sortedTd = order.map(i => $td.eq(i));
                $(this).html(sortedTd);
            });
        }
    }

    // Drag-and-drop ishga tushirish
    $('table thead tr').sortable({
        items: "th",
        axis: "x",
        update: function () {
            const newOrder = $(this).children().map(function () {
                return $(this).index();
            }).get();
            localStorage.setItem("columnOrder", JSON.stringify(newOrder));
            location.reload(); // refresh qilsak tbody ham qayta tartiblanadi
        }
    });

    applyOrder(savedOrder);
});
</script>


<?php
include '../includes/body.php';
?>