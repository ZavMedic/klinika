<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Sessiya sozlamalari (30 kun = 2592000 sekund)
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.gc_maxlifetime', 2592000);
    session_set_cookie_params([
        'lifetime' => 2592000,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// Agar allaqachon kirgan bo'lsa, redirect qilamiz
if (isset($_SESSION['user'])) {
    redirectToAppropriatePage();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    try {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Parolni tekshirish (hashlanmagan holda)
        if ($user && $password === $user['password']) {
            // Sessiyaga ma'lumotlarni saqlash
            $_SESSION['user'] = $user;
            $_SESSION['LAST_ACTIVITY'] = time();
            
            // 30 kunlik cookie
            setcookie(
                session_name(),
                session_id(),
                time() + 2592000,
                '/',
                $_SERVER['HTTP_HOST'],
                isset($_SERVER['HTTPS']),
                true
            );
            
            // Redirect qilish
            redirectToAppropriatePage();
        } else {
            $error = 'Login yoki parol noto\'g\'ri';
        }
    } catch (PDOException $e) {
        $error = 'Tizimda xatolik yuz berdi. Iltimos, keyinroq urunib ko\'ring.';
        error_log("Login error: " . $e->getMessage());
    }
}

/**
 * Foydalanuvchini mos sahifaga yo'naltiradi
 * 1. Agar redirect parametri bo'lsa, u sahifaga
 * 2. Agar sessiyada redirect_url bo'lsa, u sahifaga
 * 3. Aks holda dashboard sahifasiga
 */
function redirectToAppropriatePage() {
    if (isset($_GET['redirect']) && isValidRedirect($_GET['redirect'])) {
        redirect($_GET['redirect']);
    } elseif (isset($_SESSION['redirect_url']) && isValidRedirect($_SESSION['redirect_url'])) {
        $url = $_SESSION['redirect_url'];
        unset($_SESSION['redirect_url']);
        redirect($url);
    } else {
        redirect('../pages/dashboard.php');
    }
}

/**
 * Redirect URL ni xavfsizligini tekshiradi
 * Faqat o'z domenimizdagi sahifalarga yo'naltirishga ruxsat beradi
 */
function isValidRedirect($url) {
    $domain = $_SERVER['HTTP_HOST'];
    $allowed = [
        '/project/',
        '/project/pages/',
        '/project/auth/'
    ];
    
    // URL domain va allowed qismlarini tekshirish
    if (strpos($url, $domain) === false) {
        return false;
    }
    
    foreach ($allowed as $prefix) {
        if (strpos($url, $prefix) !== false) {
            return true;
        }
    }
    
    return false;
}

?>

<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tizimga kirish | HappyMedline</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            overflow: hidden;
            background: #f5f7fa;
        }
        .login-wrapper {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            z-index: 2;
        }
        .login-card {
            width: 100%;
            max-width: 450px;
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            background-color: white;
        }
        .login-header {
            background-color: #0d6efd;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .login-header img.logo-icon {
            width: 40px;
            height: 40px;
            vertical-align: middle;
            margin-right: 10px;
        }
        .login-body {
            padding: 30px;
        }
        .form-control {
            border-radius: 8px;
            padding: 12px 15px;
            border: 1px solid #ddd;
        }
        .form-control:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
        }
        .btn-login {
            background-color: #0d6efd;
            border: none;
            padding: 12px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .btn-login:hover {
            background-color: #0b5ed7;
            transform: translateY(-2px);
        }
        .input-group-text {
            background-color: #f8f9fa;
        }
        .password-toggle {
            cursor: pointer;
            background-color: #f8f9fa;
        }
        .bg-logo {
    position: absolute;
    width: 100px;
    height: 100px;
    background: url('../../logo.png') no-repeat center/contain;
    opacity: 0.08;
    will-change: transform;
    pointer-events: none;
  }

  .floaty {
    animation: floaty 12s infinite ease-in-out;
  }

  .laughing {
    animation: laughing 2s infinite ease-in-out;
    filter: hue-rotate(60deg);
  }

  .angry {
    animation: angryShake 0.5s infinite alternate;
    transform: scale(1.1) rotate(-10deg);
  }

  .exploding {
    animation: explode 2s ease-in forwards;
  }

  .dead {
    transform: rotate(90deg) scale(1.2);
    opacity: 0.4;
    filter: grayscale(1);
  }



 .split-container {
    position: absolute;
    width: 100px;
    height: 100px;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    pointer-events: none;
    z-index: 5;
  }

  .half {
    position: absolute;
    width: 50%;
    height: 100%;
    background: url('../../logo.png') no-repeat center/cover;
    background-size: 200% 100%;
    opacity: 1;
    animation: flyApart 2s ease-out forwards;
  }

  .half.left {
    left: 0;
    background-position: left center;
    transform-origin: right center;
  }

  .half.right {
    right: 0;
    background-position: right center;
    transform-origin: left center;
  }

  @keyframes flyApart {
    0% { transform: rotate(0) translateX(0); opacity: 1; }
    100% { transform: rotate(-30deg) translateX(-200px); opacity: 0; }
  }

  .half.right {
    animation: flyApartRight 2s ease-out forwards;
  }

  @keyframes flyApartRight {
    0% { transform: rotate(0) translateX(0); opacity: 1; }
    100% { transform: rotate(30deg) translateX(200px); opacity: 0; }
  }
  
  
  
  @keyframes floaty {
    0% { transform: translateY(0) rotate(0deg); }
    50% { transform: translateY(60px) rotate(180deg); }
    100% { transform: translateY(0) rotate(360deg); }
  }

  @keyframes laughing {
    0%, 100% { transform: rotate(5deg) scale(1); }
    50% { transform: rotate(-5deg) scale(1.1); }
  }

  @keyframes angryShake {
    0% { transform: rotate(-5deg); }
    100% { transform: rotate(5deg); }
  }

  @keyframes explode {
    0% { transform: scale(1) rotate(0); opacity: 1; }
    50% { transform: scale(1.5) rotate(180deg); filter: brightness(2); }
    100% { transform: scale(0) rotate(720deg); opacity: 0; }
  }
</style>
</head>
<body>
    <script>
  const emotes = ['floaty', 'laughing', 'angry', 'exploding', 'dead'];

  for (let i = 0; i < 25; i++) {
    const logo = document.createElement('div');
    logo.classList.add('bg-logo');

    // Random pozitsiya
    logo.style.top = Math.random() * 90 + '%';
    logo.style.left = Math.random() * 90 + '%';

    // Tasodifiy emotsiya klassi
    const mood = emotes[Math.floor(Math.random() * emotes.length)];
    logo.classList.add(mood);

    // Delay portlash uchun
    if (mood === 'exploding') {
      logo.style.animationDelay = Math.random() * 5 + 's';
    }

    document.body.appendChild(logo);
  }
</script>

<script>
  function createSplitLogo() {
    const container = document.createElement('div');
    container.classList.add('split-container');

    const left = document.createElement('div');
    left.classList.add('half', 'left');

    const right = document.createElement('div');
    right.classList.add('half', 'right');

    container.appendChild(left);
    container.appendChild(right);
    document.body.appendChild(container);

    setTimeout(() => container.remove(), 2500);
  }

  // Har 6 sekundda bitta logoni bo‘lib yubor
  setInterval(createSplitLogo, 6000);
</script>



    <div class="login-wrapper">
        <div class="login-card">
            <div class="login-header">
                <h4>
                    <img src="../../logo.png" alt="logo" class="logo-icon">
                    HappyMedline Boshqaruv Tizimi
                </h4>
                <p class="mb-0">Tizimga kirish uchun ma'lumotlaringizni kiriting</p>
            </div>
            <div class="login-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?= htmlspecialchars($error) ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" id="loginForm">
                            <div class="mb-4">
                                <label for="username" class="form-label">Foydalanuvchi nomi</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" class="form-control" id="username" name="username" 
                                           placeholder="Login" required
                                           value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>">
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <label for="password" class="form-label">Parol</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" 
                                           placeholder="Parolingizni kiriting" required>
                                    <span class="input-group-text password-toggle" id="togglePassword">
                                        <i class="fas fa-eye"></i>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-login">
                                    <i class="fas fa-sign-in-alt me-2"></i> Kirish
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $('#togglePassword').click(function () {
            const passwordInput = $('#password');
            const icon = $(this).find('i');
            if (passwordInput.attr('type') === 'password') {
                passwordInput.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                passwordInput.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        });
    </script>
</body>
</html>
