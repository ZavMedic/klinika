<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
$title = "Rahbar paneli";
ob_start(); // Kontentni buferga yozish
$content = ob_get_clean(); // Buferdagi ma'lumotni olish
include '../includes/head.php';
if (!isLoggedIn()) {
    redirect('../pages/login.php');
}

$role = getUserRole();
$username = $_SESSION['user']['username'];

// Xodimlarni ro'yxatdan o'tkazish (parolni hashlamasdan)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register_employee'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Xodimni ro'yxatdan o'tkazish
    $query = "INSERT INTO users (username, password, role, status) 
              VALUES (:username, :password, :role, 'faol')";
    $stmt = $conn->prepare($query);
    $stmt->execute([
        'username' => $username,
        'password' => $password, // Parolni hashlamasdan saqlash
        'role' => $role
    ]);

    // Yangi xodimning ID sini olish
    $employee_id = $conn->lastInsertId();

    // Barcha xizmat turlarini olish
    $services = $conn->query("SELECT id FROM services")->fetchAll(PDO::FETCH_ASSOC);

    // Har bir xizmat turi uchun ulushni 0% qilib qo'shish
if (in_array($role, ['hamshira', 'kassir'])) {
    foreach ($services as $service) {
        $query = "INSERT INTO staff_percentages (user_id, service_id, percentage) 
                  VALUES (:user_id, :service_id, 0)";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            'user_id' => $employee_id,
            'service_id' => $service['id']
        ]);
    }
}
    $_SESSION['message'] = "Xodim muvaffaqiyatli ro'yxatdan o'tkazildi va barcha xizmat turlari uchun ulushlar 0% qilib belgilandi!";
}
// Xodimlarni faol/nofaol qilish
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['toggle_status'])) {
    $employee_id = $_POST['employee_id'];
    $status = $_POST['status'];

    $query = "UPDATE users SET status = :status WHERE id = :employee_id";
    $stmt = $conn->prepare($query);
    $stmt->execute(['status' => $status, 'employee_id' => $employee_id]);

    $_SESSION['message'] = "Xodim holati muvaffaqiyatli o'zgartirildi!";
}

// Xodimlarning rolini o'zgartirish
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_role'])) {
    $employee_id = $_POST['employee_id'];
    $role = $_POST['role'];

    $query = "UPDATE users SET role = :role WHERE id = :employee_id";
    $stmt = $conn->prepare($query);
    $stmt->execute(['role' => $role, 'employee_id' => $employee_id]);

    $_SESSION['message'] = "Xodim roli muvaffaqiyatli o'zgartirildi!";
}

// Xizmat turlarini qo'shish
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_service'])) {
    $name = $_POST['name'];
    $doctor_id = $_POST['doctor_id'];
    $price = $_POST['price'];

    $query = "INSERT INTO services (name, doctor_id, price) 
              VALUES (:name, :doctor_id, :price)";
    $stmt = $conn->prepare($query);
    $stmt->execute([
        'name' => $name,
        'doctor_id' => $doctor_id,
        'price' => $price
    ]);
    $service_id = $conn->lastInsertId(); // Yangi qo'shilgan xizmat IDsi

    // Shifokor uchun ulush belgilash
    $doctor_percentage = $_POST['doctor_percentage'] ?? 0;
    if ($doctor_percentage > 0) {
        $query = "INSERT INTO staff_percentages (user_id, service_id, percentage) 
                  VALUES (:user_id, :service_id, :percentage)";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            'user_id' => $doctor_id,
            'service_id' => $service_id,
            'percentage' => $doctor_percentage
        ]);
    }

    // Hamshiralar uchun ulushlarni belgilash
    foreach ($_POST['nurse_percentages'] as $nurse_id => $percentage) {
        if ($percentage > 0) {
            $query = "INSERT INTO staff_percentages (user_id, service_id, percentage) 
                      VALUES (:user_id, :service_id, :percentage)";
            $stmt = $conn->prepare($query);
            $stmt->execute([
                'user_id' => $nurse_id,
                'service_id' => $service_id,
                'percentage' => $percentage
            ]);
        }
    }

    // Kassirlar uchun ulushlarni belgilash
    foreach ($_POST['cashier_percentages'] as $cashier_id => $percentage) {
        if ($percentage > 0) {
            $query = "INSERT INTO staff_percentages (user_id, service_id, percentage) 
                      VALUES (:user_id, :service_id, :percentage)";
            $stmt = $conn->prepare($query);
            $stmt->execute([
                'user_id' => $cashier_id,
                'service_id' => $service_id,
                'percentage' => $percentage
            ]);
        }
    }

    $_SESSION['message'] = "Xizmat turi va ulushlar muvaffaqiyatli qo'shildi!";
}

// Xizmat narxini o'zgartirish
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_price'])) {
    $service_id = $_POST['service_id'];
    $price = $_POST['price'];

    $query = "UPDATE services SET price = :price WHERE id = :service_id";
    $stmt = $conn->prepare($query);
    $stmt->execute(['price' => $price, 'service_id' => $service_id]);

    $_SESSION['message'] = "Xizmat narxi muvaffaqiyatli yangilandi!";
}

// Shifokor ulushini o'zgartirish
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_doctor_percentage'])) {
    $service_id = $_POST['service_id'];
    $doctor_id = $_POST['doctor_id'];
    $doctor_percentage = $_POST['doctor_percentage'];

    if ($doctor_percentage > 0) {
        $query = "INSERT INTO staff_percentages (user_id, service_id, percentage) 
                  VALUES (:user_id, :service_id, :percentage) 
                  ON DUPLICATE KEY UPDATE percentage = :percentage";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            'user_id' => $doctor_id,
            'service_id' => $service_id,
            'percentage' => $doctor_percentage
        ]);
    } else {
        // Agar ulush 0 bo'lsa, shifokor ulushini o'chirish
        $query = "DELETE FROM staff_percentages 
                  WHERE user_id = :user_id AND service_id = :service_id";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            'user_id' => $doctor_id,
            'service_id' => $service_id
        ]);
    }

    $_SESSION['message'] = "Shifokor ulushi muvaffaqiyatli yangilandi!";
}

// Hamshira ulushini o'zgartirish
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_nurse_percentage'])) {
    $service_id = $_POST['service_id'];
    $nurse_id = $_POST['nurse_id'];
    $nurse_percentage = $_POST['nurse_percentage'];

    if ($nurse_percentage > 0) {
        $query = "INSERT INTO staff_percentages (user_id, service_id, percentage) 
                  VALUES (:user_id, :service_id, :percentage) 
                  ON DUPLICATE KEY UPDATE percentage = :percentage";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            'user_id' => $nurse_id,
            'service_id' => $service_id,
            'percentage' => $nurse_percentage
        ]);
    } else {
        // Agar ulush 0 bo'lsa, hamshira ulushini o'chirish
        $query = "DELETE FROM staff_percentages 
                  WHERE user_id = :user_id AND service_id = :service_id";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            'user_id' => $nurse_id,
            'service_id' => $service_id
        ]);
    }

    $_SESSION['message'] = "Hamshira ulushi muvaffaqiyatli yangilandi!";
}

// Kassir ulushini o'zgartirish
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_cashier_percentage'])) {
    $service_id = $_POST['service_id'];
    $cashier_id = $_POST['cashier_id'];
    $cashier_percentage = $_POST['cashier_percentage'];

    if ($cashier_percentage > 0) {
        $query = "INSERT INTO staff_percentages (user_id, service_id, percentage) 
                  VALUES (:user_id, :service_id, :percentage) 
                  ON DUPLICATE KEY UPDATE percentage = :percentage";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            'user_id' => $cashier_id,
            'service_id' => $service_id,
            'percentage' => $cashier_percentage
        ]);
    } else {
        // Agar ulush 0 bo'lsa, kassir ulushini o'chirish
        $query = "DELETE FROM staff_percentages 
                  WHERE user_id = :user_id AND service_id = :service_id";
        $stmt = $conn->prepare($query);
        $stmt->execute([
            'user_id' => $cashier_id,
            'service_id' => $service_id
        ]);
    }

    $_SESSION['message'] = "Kassir ulushi muvaffaqiyatli yangilandi!";
}

// Xodimlarni olish
$employees = $conn->query("SELECT * FROM users WHERE role != 'rahbar'")->fetchAll(PDO::FETCH_ASSOC);

// Xizmatlar va ulushlarni olish
$services = $conn->query("SELECT s.id, s.name, s.doctor_id, s.price, u.username AS doctor_name 
                          FROM services s 
                          LEFT JOIN users u ON s.doctor_id = u.id")->fetchAll(PDO::FETCH_ASSOC);

// Shifokorlarni olish
$doctors = $conn->query("SELECT * FROM users WHERE role = 'shifokor'")->fetchAll(PDO::FETCH_ASSOC);

// Hamshiralarni olish
$nurses = $conn->query("SELECT * FROM users WHERE role = 'hamshira'")->fetchAll(PDO::FETCH_ASSOC);

// Kassirlarni olish
$cashiers = $conn->query("SELECT * FROM users WHERE role = 'kassir'")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mt-5">
    <!-- Xabarni ko'rsatish -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-info"><?= htmlspecialchars($_SESSION['message']) ?></div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <h1 class="mb-4">Rahbar boshqaruvi <a href="./../admin/nurse_schedule.php" class="btn btn-primary btn-icon-split"> 
    <span class="icon text-white-50">
        <i class="fas fa-calendar-alt"></i>
    </span>
    <span class="text">Ish Jadvali</span>
</a> | <a href="./../admin/errors_nurses.php" class="btn btn-warning btn-icon-split">Xatoliklarni belgilash</a></h1>

    <!-- Rahbar uchun funksiyalar -->
    <?php if ($role === 'rahbar'): ?>
        <!-- Xodimlarni Ro'yxatdan O'tkazish -->
        <div class="card mb-4">
            <div class="card-header">
                <h2 class="mb-0">Xodimlarni Ro'yxatdan O'tkazish</h2>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <input type="text" name="username" class="form-control" placeholder="Foydalanuvchi nomi" required>
                    </div>
                    <div class="mb-3">
                        <input type="password" name="password" class="form-control" placeholder="Parol" required>
                    </div>
                    <div class="mb-3">
                        <select name="role" class="form-control" required>
                            <option value="">Rolni tanlang</option>
                            <option value="shifokor">Shifokor</option>
                            <option value="hamshira">Hamshira</option>
                            <option value="kassir">Kassir</option>
                            <option value="bugalter">Bugalter</option>
                            <option value="rizerv1">Rizerv1</option>
                            <option value="rizerv2">Rizerv2</option>
                        </select>
                    </div>
                    <button type="submit" name="register_employee" class="btn btn-primary">Ro'yxatdan O'tkazish</button>
                </form>
            </div>
        </div>

        <!-- Xodimlarni Faol/Nofaol Qilish -->
        <div class="card mb-4">
            <div class="card-header">
                <h2 class="mb-0">Xodimlarni Faol/Nofaol Qilish</h2>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <select name="employee_id" class="form-control" required>
                            <option value="">Xodimni tanlang</option>
                            <?php foreach ($employees as $employee): ?>
                                <option value="<?= $employee['id'] ?>"><?= htmlspecialchars($employee['username']) ?> (<?= htmlspecialchars($employee['role']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <select name="status" class="form-control" required>
                            <option value="faol">Faol</option>
                            <option value="nofaol">Nofaol</option>
                        </select>
                    </div>
                    <button type="submit" name="toggle_status" class="btn btn-primary">Holatni O'zgartirish</button>
                </form>
            </div>
        </div>

        <!-- Xodimlarning Rolini O'zgartirish -->
        <div class="card mb-4">
            <div class="card-header">
                <h2 class="mb-0">Xodimlarning Rolini O'zgartirish</h2>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <select name="employee_id" class="form-control" required>
                            <option value="">Xodimni tanlang</option>
                            <?php foreach ($employees as $employee): ?>
                                <option value="<?= $employee['id'] ?>"><?= htmlspecialchars($employee['username']) ?> (<?= htmlspecialchars($employee['role']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <select name="role" class="form-control" required>
                            <option value="">Rolni tanlang</option>
                            <option value="shifokor">Shifokor</option>
                            <option value="hamshira">Hamshira</option>
                            <option value="kassir">Kassir</option>
                            <option value="bugalter">Bugalter</option>
                            <option value="rizerv1">Rizerv1</option>
                            <option value="rizerv2">Rizerv2</option>
                        </select>
                    </div>
                    <button type="submit" name="change_role" class="btn btn-primary">Rolni O'zgartirish</button>
                </form>
            </div>
        </div>

        <!-- Xodimlar Ro'yxati -->
        <div class="card mb-4">
            <div class="card-header">
                <h2 class="mb-0">Xodimlar Ro'yxati</h2>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Foydalanuvchi nomi</th>
                            <th>Rol</th>
                            <th>Holat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($employees as $employee): ?>
                            <tr>
                                <td><?= $employee['id'] ?></td>
                                <td><?= htmlspecialchars($employee['username']) ?></td>
                                <td><?= htmlspecialchars($employee['role']) ?></td>
                                <td><?= htmlspecialchars($employee['status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Xizmat turlarini qo'shish -->
        <div class="card mb-4">
            <div class="card-header">
                <h2 class="mb-0">Xizmat Turlarini Qo'shish</h2>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <input type="text" name="name" class="form-control" placeholder="Xizmat nomi" required>
                    </div>
                    <div class="mb-3">
                        <select name="doctor_id" class="form-control" required>
                            <option value="">Shifokorni tanlang</option>
                            <?php foreach ($doctors as $doctor): ?>
                                <option value="<?= $doctor['id'] ?>"><?= htmlspecialchars($doctor['username']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <input type="number" name="price" class="form-control" placeholder="Xizmat narxi" required>
                    </div>
                    <div class="mb-3">
                        <h5>Shifokor uchun ulush:</h5>
                        <input type="number" name="doctor_percentage" class="form-control" placeholder="Shifokor ulushi %" step="0.01" min="0" max="100">
                    </div>
                    <div class="mb-3">
                        <h5>Hamshiralar uchun ulushlar:</h5>
                        <?php foreach ($nurses as $nurse): ?>
                            <div class="input-group mb-2">
                                <label class="input-group-text"><?= htmlspecialchars($nurse['username']) ?></label>
                                <input type="number" name="nurse_percentages[<?= $nurse['id'] ?>]" class="form-control" placeholder="Ulush %" step="0.01" min="0" max="100">
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="mb-3">
                        <h5>Kassirlar uchun ulushlar:</h5>
                        <?php foreach ($cashiers as $cashier): ?>
                            <div class="input-group mb-2">
                                <label class="input-group-text"><?= htmlspecialchars($cashier['username']) ?></label>
                                <input type="number" name="cashier_percentages[<?= $cashier['id'] ?>]" class="form-control" placeholder="Ulush %" step="0.01" min="0" max="100">
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="submit" name="add_service" class="btn btn-primary">Qo'shish</button>
                </form>
            </div>
        </div>

<!-- Xizmatlar va Ulushlar -->
<div class="card mb-4">
    <div class="card-header">
        <h2 class="mb-0">Xizmatlar va Ulushlar</h2>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Xizmat Nomi</th>
                    <th>Shifokor</th>
                    <th>Narxi</th>
                    <th>Shifokor Ulushi</th>
                    <th>Hamshiralar Ulushi</th>
                    <th>Kassirlar Ulushi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($services as $service): ?>
                    <?php
                    // Shifokor uchun ulushni olish
                    $doctor_share = $conn->query("SELECT percentage 
                                                 FROM staff_percentages 
                                                 WHERE service_id = {$service['id']} AND user_id = {$service['doctor_id']}")
                                        ->fetch(PDO::FETCH_ASSOC);
                    $doctor_percentage = $doctor_share ? $doctor_share['percentage'] : 0;

                    // Hamshiralar uchun ulushlarni olish
                    $nurse_shares = $conn->query("SELECT u.id, u.username, sp.percentage 
                                                  FROM users u 
                                                  LEFT JOIN staff_percentages sp 
                                                  ON u.id = sp.user_id AND sp.service_id = {$service['id']} 
                                                  WHERE u.role = 'hamshira'")
                                        ->fetchAll(PDO::FETCH_ASSOC);

                    // Kassirlar uchun ulushlarni olish
                    $cashier_shares = $conn->query("SELECT u.id, u.username, sp.percentage 
                                                    FROM users u 
                                                    LEFT JOIN staff_percentages sp 
                                                    ON u.id = sp.user_id AND sp.service_id = {$service['id']} 
                                                    WHERE u.role = 'kassir'")
                                          ->fetchAll(PDO::FETCH_ASSOC);
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($service['name']) ?></td>
                        <td><?= htmlspecialchars($service['doctor_name']) ?></td>
                        <td>
                            <!-- Narxni o'zgartirish formasi -->
                            <form method="POST" class="form-inline">
                                <input type="hidden" name="service_id" value="<?= $service['id'] ?>">
                                <div class="input-group">
                                    <input type="number" name="price" class="form-control" value="<?= $service['price'] ?>" step="0.01" min="0" required>
                                    <button type="submit" name="update_price" class="btn btn-primary">Saqlash</button>
                                </div>
                            </form>
                        </td>
                        <td>
                            <!-- Shifokor ulushini o'zgartirish formasi -->
                            <form method="POST" class="form-inline">
                                <input type="hidden" name="service_id" value="<?= $service['id'] ?>">
                                <input type="hidden" name="doctor_id" value="<?= $service['doctor_id'] ?>">
                                <div class="input-group">
                                    <input type="number" name="doctor_percentage" class="form-control" value="<?= $doctor_percentage ?>" step="0.01" min="0" max="100" required>
                                    <button type="submit" name="update_doctor_percentage" class="btn btn-primary">Saqlash</button>
                                </div>
                            </form>
                        </td>
                        <td>
                            <!-- Hamshiralar ulushini o'zgartirish -->
                            <?php foreach ($nurse_shares as $nurse): ?>
                                <form method="POST" class="form-inline mb-2">
                                    <input type="hidden" name="service_id" value="<?= $service['id'] ?>">
                                    <input type="hidden" name="nurse_id" value="<?= $nurse['id'] ?>">
                                    <div class="input-group">
                                        <label class="input-group-text"><?= htmlspecialchars($nurse['username']) ?></label>
                                        <input type="number" name="nurse_percentage" class="form-control" value="<?= $nurse['percentage'] ?? 0 ?>" step="0.01" min="0" max="100" required>
                                        <button type="submit" name="update_nurse_percentage" class="btn btn-primary">Saqlash</button>
                                    </div>
                                </form>
                            <?php endforeach; ?>
                        </td>
                        <td>
                            <!-- Kassirlar ulushini o'zgartirish -->
                            <?php foreach ($cashier_shares as $cashier): ?>
                                <form method="POST" class="form-inline mb-2">
                                    <input type="hidden" name="service_id" value="<?= $service['id'] ?>">
                                    <input type="hidden" name="cashier_id" value="<?= $cashier['id'] ?>">
                                    <div class="input-group">
                                        <label class="input-group-text"><?= htmlspecialchars($cashier['username']) ?></label>
                                        <input type="number" name="cashier_percentage" class="form-control" value="<?= $cashier['percentage'] ?? 0 ?>" step="0.01" min="0" max="100" required>
                                        <button type="submit" name="update_cashier_percentage" class="btn btn-primary">Saqlash</button>
                                    </div>
                                </form>
                            <?php endforeach; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>