<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Foydalanuvchi tizimga kirganligini va rahbar ekanligini tekshirish
if (!isLoggedIn() || getUserRole() !== 'rahbar') {
    die("Sizda ushbu sahifaga kirish uchun ruxsat yo'q!");
}

// Xabar yuborish funksiyasi
function sendBulkTelegramMessages($conn, $message, $recipients, $sender_id) {
    // Xabarni arxivga saqlash
    $stmt = $conn->prepare("INSERT INTO sent_messages (sender_id, message_text) VALUES (?, ?)");
    $stmt->execute([$sender_id, $message]);
    $message_id = $conn->lastInsertId();
    
    $success_count = 0;
    $failed_count = 0;
    $results = [];
    
    foreach ($recipients as $employee) {
        try {
            $response = sendTelegramMessage($employee['telegram_id'], $message, 'HTML');
            $result = json_decode($response, true);
            
            if ($result['ok']) {
                $success_count++;
                // Har bir qabul qiluvchini arxivga saqlash
                $stmt = $conn->prepare("
                    INSERT INTO message_recipients 
                    (message_id, recipient_id, status, telegram_message_id) 
                    VALUES (?, ?, 'sent', ?)
                ");
                $stmt->execute([
                    $message_id,
                    $employee['id'],
                    $result['result']['message_id']
                ]);
                
                $results[] = [
                    'status' => 'success',
                    'employee' => $employee['username'],
                    'role' => $employee['role'],
                    'message' => 'Xabar muvaffaqiyatli yuborildi'
                ];
            } else {
                $failed_count++;
                $results[] = [
                    'status' => 'error',
                    'employee' => $employee['username'],
                    'role' => $employee['role'],
                    'message' => $result['description'] ?? 'Noma\'lum xato'
                ];
            }
        } catch (Exception $e) {
            $failed_count++;
            $results[] = [
                'status' => 'error',
                'employee' => $employee['username'],
                'role' => $employee['role'],
                'message' => $e->getMessage()
            ];
        }
    }
    
    return [
        'message_id' => $message_id,
        'success_count' => $success_count,
        'failed_count' => $failed_count,
        'results' => $results
    ];
}

// Xabar yuborishni qayta ishlash
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = trim($_POST['message']);
    $recipient_roles = $_POST['recipients'] ?? [];
    
    if (empty($message)) {
        $_SESSION['error'] = "Xabar matni bo'sh bo'lmasligi kerak!";
    } elseif (empty($recipient_roles)) {
        $_SESSION['error'] = "Kamida bitta qabul qiluvchi tanlanishi kerak!";
    } else {
        // Tanlangan rollar bo'yicha xodimlarni olish
        $placeholders = implode(',', array_fill(0, count($recipient_roles), '?'));
        $stmt = $conn->prepare("
            SELECT id, username, telegram_id, role 
            FROM users 
            WHERE role IN ($placeholders) 
            AND telegram_id IS NOT NULL
            AND status = 'faol'
        ");
        $stmt->execute($recipient_roles);
        $recipients = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($recipients)) {
            $result = sendBulkTelegramMessages($conn, $message, $recipients, $_SESSION['user']['id']);
            $_SESSION['notification_result'] = $result;
            $_SESSION['success'] = "Xabarlar yuborildi! Muvaffaqiyatli: {$result['success_count']}, Xatolar: {$result['failed_count']}";
        } else {
            $_SESSION['error'] = "Tanlangan rollarda Telegram ID si mavjud xodim topilmadi!";
        }
    }
    
    redirect('send_notifications.php');
}

// Arxiv xabarlarni olish
$stmt = $conn->prepare("
    SELECT sm.id, sm.message_text, sm.sent_at, u.username AS sender_name,
           COUNT(mr.id) AS total_recipients,
           SUM(CASE WHEN mr.status = 'sent' THEN 1 ELSE 0 END) AS sent_count,
           SUM(CASE WHEN mr.status = 'delivered' THEN 1 ELSE 0 END) AS delivered_count,
           SUM(CASE WHEN mr.status = 'read' THEN 1 ELSE 0 END) AS read_count
    FROM sent_messages sm
    JOIN users u ON sm.sender_id = u.id
    LEFT JOIN message_recipients mr ON sm.id = mr.message_id
    GROUP BY sm.id
    ORDER BY sm.sent_at DESC
    LIMIT 10
");
$stmt->execute();
$archived_messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Barcha mumkin bo'lgan qabul qiluvchilarni olish
$stmt = $conn->query("SELECT DISTINCT role FROM users WHERE role IN ('shifokor', 'hamshira', 'kassir')");
$available_roles = $stmt->fetchAll(PDO::FETCH_COLUMN);

$title = "Botdan xabar yuborish";
$content = ob_get_clean();
include '../includes/head.php';
?>

<div class="container mt-5">
    <h1>Xodimlarga Xabar Yuborish</h1>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_SESSION['success']) ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-6">
            <form method="POST" class="mt-4">
               <div class="mb-3">
    <label for="message" class="form-label">Xabar Matni</label>
    <textarea class="form-control" id="message" name="message" rows="8" required
              placeholder="Xabar matnini kiriting..."></textarea>
    <div class="mt-2">
        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="formatText('bold')" title="Ctrl+B">
            <b>B</b>
        </button>
        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="formatText('italic')" title="Ctrl+I">
            <i>I</i>
        </button>
        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="formatText('underline')" title="Ctrl+U">
            <u>U</u>
        </button>
        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="insertNewline()">
            Yangi qator ↵
        </button>
    </div>
    <div class="form-text">
        HTML formatlash: <code>&lt;b&gt;qalin&lt;/b&gt;</code>, 
        <code>&lt;i&gt;yotiq&lt;/i&gt;</code>, 
        <code>&lt;u&gt;tagi chizilgan&lt;/u&gt;</code>
    </div>
</div>
                
                <div class="mb-4">
                    <label class="form-label">Qabul Qiluvchilar:</label>
                    <div class="row">
                        <?php foreach ($available_roles as $role): ?>
                            <div class="col-md-4">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="role_<?= $role ?>" 
                                           name="recipients[]" value="<?= $role ?>" checked>
                                    <label class="form-check-label" for="role_<?= $role ?>">
                                        <?= ucfirst($role) ?>lar
                                    </label>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Emojilar:</label>
                    <div class="d-flex flex-wrap gap-2 mb-3" id="emojiContainer">
                        <!-- Emojilar JavaScript orqali yuklanadi -->
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">Xabarlarni Yuborish</button>
            </form>
        </div>
        
        <div class="col-md-6">
    <h2 class="mb-3">Oxirgi 10 ta Xabar Arxivi</h2>
    <div class="accordion" id="archiveAccordion">
        <?php foreach ($archived_messages as $msg): ?>
            <div class="accordion-item">
                <h2 class="accordion-header" id="heading<?= $msg['id'] ?>">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" 
                            data-bs-target="#collapse<?= $msg['id'] ?>" aria-expanded="false" 
                            aria-controls="collapse<?= $msg['id'] ?>">
                        #<?= $msg['id'] ?> - <?= substr(htmlspecialchars($msg['message_text']), 0, 30) ?>...
                        <span class="badge bg-primary ms-2"><?= $msg['sent_at'] ?></span>
                    </button>
                </h2>
                <div id="collapse<?= $msg['id'] ?>" class="accordion-collapse collapse" 
                     aria-labelledby="heading<?= $msg['id'] ?>" data-bs-parent="#archiveAccordion">
                    <div class="accordion-body">
                        <p><strong>Xabar matni:</strong></p>
                        <div class="bg-light p-3 mb-3 rounded">
                            <?= nl2br(htmlspecialchars($msg['message_text'])) ?>
                        </div>
                        
                        <p><strong>Qabul qiluvchilar:</strong></p>
                        <?php 
                        // Xabarning qabul qiluvchilarini olish
                        $stmt = $conn->prepare("
                            SELECT u.username, u.role, mr.status, mr.telegram_message_id
                            FROM message_recipients mr
                            JOIN users u ON mr.recipient_id = u.id
                            WHERE mr.message_id = ?
                            ORDER BY mr.status DESC, u.username
                        ");
                        $stmt->execute([$msg['id']]);
                        $recipients = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        ?>
                        
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Foydalanuvchi</th>
                                    <th>Lavozim</th>
                                    <th>Holat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recipients as $recipient): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($recipient['username']) ?></td>
                                        <td><?= htmlspecialchars($recipient['role']) ?></td>
                                        <td>
                                            <?php if ($recipient['status'] == 'read'): ?>
                                                <span class="badge bg-success">O'qilgan</span>
                                            <?php elseif ($recipient['status'] == 'delivered'): ?>
                                                <span class="badge bg-warning">Yetkazilgan</span>
                                            <?php else: ?>
                                                <span class="badge bg-primary">Yuborilgan</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <div class="mt-3">
                            <span class="badge bg-primary">Yuborilgan: <?= $msg['sent_count'] ?></span>
                            <span class="badge bg-warning">Yetkazilgan: <?= $msg['delivered_count'] ?></span>
                            <span class="badge bg-success">O'qilgan: <?= $msg['read_count'] ?></span>
                            <span class="badge bg-secondary">Jami: <?= $msg['total_recipients'] ?></span>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
    </div>
    
    <?php if (isset($_SESSION['notification_result'])): ?>
        <div class="mt-4">
            <h3>Xabar Yuborish Natijalari</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Xodim</th>
                        <th>Lavozim</th>
                        <th>Holat</th>
                        <th>Xabar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['notification_result']['results'] as $result): ?>
                        <tr class="<?= $result['status'] === 'success' ? 'table-success' : 'table-danger' ?>">
                            <td><?= htmlspecialchars($result['employee']) ?></td>
                            <td><?= htmlspecialchars($result['role']) ?></td>
                            <td><?= $result['status'] === 'success' ? '✅' : '❌' ?></td>
                            <td><?= htmlspecialchars($result['message']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php unset($_SESSION['notification_result']); ?>
    <?php endif; ?>
</div>

<script>
// Emojilarni yuklash va qo'shish
document.addEventListener('DOMContentLoaded', function() {
    const emojis = ['😊', '👍', '👨‍⚕️', '👩‍⚕️', '💰', '📅', '⚠️', '✅', '❌', '🔔', '📝', '📌'];
    const container = document.getElementById('emojiContainer');
    
    emojis.forEach(emoji => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-outline-secondary btn-sm';
        btn.textContent = emoji;
        btn.onclick = function() {
            const textarea = document.getElementById('message');
            textarea.value += emoji;
            textarea.focus();
        };
        container.appendChild(btn);
    });
    
    // Barcha qabul qiluvchilarni tanlash/olib tashlash
    const toggleAllBtn = document.createElement('button');
    toggleAllBtn.type = 'button';
    toggleAllBtn.className = 'btn btn-outline-primary btn-sm';
    toggleAllBtn.textContent = 'Barchasini tanlash/olib tashlash';
    toggleAllBtn.onclick = function() {
        document.querySelectorAll('input[name="recipients[]"]').forEach(checkbox => {
            checkbox.checked = !checkbox.checked;
        });
    };
    container.parentNode.insertBefore(toggleAllBtn, container.nextSibling);
});
	
	// Formatlash funksiyasi
function formatText(format) {
    const textarea = document.getElementById('message');
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);
    let wrappedText = '';
    
    switch(format) {
        case 'bold':
            wrappedText = '<b>' + selectedText + '</b>';
            break;
        case 'italic':
            wrappedText = '<i>' + selectedText + '</i>';
            break;
        case 'underline':
            wrappedText = '<u>' + selectedText + '</u>';
            break;
    }
    
    textarea.value = textarea.value.substring(0, start) + wrappedText + textarea.value.substring(end);
    textarea.focus();
    textarea.setSelectionRange(start + (wrappedText.length - selectedText.length), end + (wrappedText.length - selectedText.length));
}

// Yangi qator qo'shish
function insertNewline() {
    const textarea = document.getElementById('message');
    const start = textarea.selectionStart;
    textarea.value = textarea.value.substring(0, start) + '\n' + textarea.value.substring(start);
    textarea.focus();
    textarea.setSelectionRange(start + 1, start + 1);
}

// Klaviatura qisqartmalari
document.getElementById('message').addEventListener('keydown', function(e) {
    if (e.ctrlKey) {
        switch(e.key.toLowerCase()) {
            case 'b':
                e.preventDefault();
                formatText('bold');
                break;
            case 'i':
                e.preventDefault();
                formatText('italic');
                break;
            case 'u':
                e.preventDefault();
                formatText('underline');
                break;
        }
    }
});
</script>

<?php include '../includes/body.php'; ?>