<?php
// employee_stats.php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Foydalanuvchi ma'lumotlarini olish
$user_id = $_SESSION['user']['id'];
$role = getUserRole();

// Faqat shifokor/hamshira uchun ruxsat
if (!in_array($role, ['shifokor', 'hamshira'])) {
    die(json_encode(['error' => 'Ruxsat yo\'q']));
}

// Oxirgi 30 kunlik ma'lumotlarni olish faqat ishlangan kunlar chiqadi
//$query = "SELECT 
//            DATE(created_at) AS sana,
//            SUM(price) AS kunlik_tushum,
//            COUNT(id) AS bemorlar_soni
//          FROM patients
//          WHERE (doctor_id = :user_id OR nurse_id = :user_id
//          AND doctor_id = 8)
//          AND DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
//          AND debt = 0
//          GROUP BY DATE(created_at)
//          ORDER BY DATE(created_at) ASC";

//$stmt = $conn->prepare($query);
//$stmt->execute(['user_id' => $user_id]);
//$stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Oxirgi 30 kunlik ma'lumotlarni olish ishlanmagan kunlar chiqadi
$query = "SELECT 
            DATE(created_at) AS sana,
            SUM(price) AS kunlik_tushum,
            COUNT(id) AS bemorlar_soni
          FROM patients
          WHERE (doctor_id = :user_id OR nurse_id = :user_id
          AND doctor_id = 8)
          AND DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
          AND debt = 0
          GROUP BY DATE(created_at)
          ORDER BY DATE(created_at) ASC";

$stmt = $conn->prepare($query);
$stmt->execute(['user_id' => $user_id]);
$stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Sanalar ro'yxatini 30 kun uchun tayyorlash
$all_dates = [];
$start = new DateTime('-29 days');
$end = new DateTime(); // bugungi sana

for ($date = $start; $date <= $end; $date->modify('+1 day')) {
    $key = $date->format('Y-m-d');
    $all_dates[$key] = [
        'sana' => $key,
        'kunlik_tushum' => 0,
        'bemorlar_soni' => 0
    ];
}

// So'rovdan olingan ma'lumotlarni ustiga yozamiz
foreach ($stats as $row) {
    $all_dates[$row['sana']] = $row;
}

// Yakuniy massiv
$stats = array_values($all_dates); // indeksni qayta tartiblash



// Ma'lumotlarni grafik uchun tayyorlash
$labels = [];
$data = [];
$bemorlar = [];

foreach ($stats as $stat) {
    $labels[] = $stat['sana'];
    $data[] = (float)$stat['kunlik_tushum'];
    $bemorlar[] = (int)$stat['bemorlar_soni'];
}
?>

<!-- HTML qismi -->
<div class="container mt-4">
    <h4 class="mb-4">Mening Oxirgi 30 Kunlik Statistikalarim</h4>
    
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Kunlik Tushumlar</h6>
                </div>
                <div class="card-body">
                    <canvas id="incomeChart" height="200"></canvas>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Kunlik Bemorlar</h6>
                </div>
                <div class="card-body">
                    <canvas id="patientsChart" height="200"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript qismi -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Tushumlar grafigi
    const incomeCtx = document.getElementById('incomeChart');
    new Chart(incomeCtx, {
        type: 'bar',
        data: {
            labels: <?= json_encode($labels) ?>,
            datasets: [{
                label: 'Tushum (so\'m)',
                data: <?= json_encode($data) ?>,
                backgroundColor: 'rgba(78, 115, 223, 0.5)',
                borderColor: 'rgba(78, 115, 223, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString() + ' so\'m';
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y.toLocaleString() + ' so\'m';
                        }
                    }
                }
            }
        }
    });

    // Bemorlar grafigi
    const patientsCtx = document.getElementById('patientsChart');
    new Chart(patientsCtx, {
        type: 'line',
        data: {
            labels: <?= json_encode($labels) ?>,
            datasets: [{
                label: 'Bemorlar soni',
                data: <?= json_encode($bemorlar) ?>,
                backgroundColor: 'rgba(28, 200, 138, 0.2)',
                borderColor: 'rgba(28, 200, 138, 1)',
                borderWidth: 2,
                tension: 0.1,
                fill: true
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
});
</script>