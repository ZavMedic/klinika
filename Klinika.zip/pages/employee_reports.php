<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
$title = "Shifokor/Hamshira Kabineti";
ob_start();
$content = ob_get_clean();
include '../includes/head.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$role = getUserRole();
$user_id = $_SESSION['user']['id'];

if (!in_array($role, ['shifokor', 'hamshira'])) {
    die("Sizda ushbu sahifaga kirish uchun ruxsat yo'q!");
}

// Tanlangan davr (default - bugun)
$start_date = date('Y-m-d');
$end_date = date('Y-m-d');
$show_period_report = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['start_date']) && isset($_POST['end_date'])) {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $show_period_report = true;
}

// Tanlangan davr uchun hisobot
$period_patients = [];
if ($show_period_report) {
    $period_query = "SELECT 
                    p.id,
                    p.full_name AS bemor_ismi,
                    GROUP_CONCAT(s.name SEPARATOR ', ') AS xizmat_nomi,
                    p.price AS narxi,
                    p.created_at AS qabul_vaqti,
                    p.phone_number AS telefon,
                    DATEDIFF(NOW(), p.created_at) AS qarz_kunlari,
                    p.debt AS qarzdor,
                    p.doctor_income,
                    p.nurse_income
                  FROM patients p
                  LEFT JOIN patient_services ps ON p.id = ps.patient_id
                  LEFT JOIN services s ON ps.service_id = s.id
                  WHERE DATE(p.created_at) BETWEEN :start_date AND :end_date
                  AND (p.doctor_id = :user_id OR p.nurse_id = :user_id)
                  AND (
                      (:role = 'shifokor' AND p.doctor_income > 0) OR 
                      (:role = 'hamshira' AND p.nurse_income > 0)
                  )
                  GROUP BY p.id
                  ORDER BY p.created_at DESC";
    
    $period_stmt = $conn->prepare($period_query);
    $period_stmt->execute([
        'start_date' => $start_date,
        'end_date' => $end_date,
        'user_id' => $user_id,
        'role' => $role
    ]);
    $period_patients = $period_stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Bugungi bemorlar (faqat asosiy sahifada ko'rsatiladi)
$today_patients = [];
if (!$show_period_report) {
    $today = date('Y-m-d');
    $query = "SELECT 
                p.id,
                p.full_name AS bemor_ismi,
                GROUP_CONCAT(s.name SEPARATOR ', ') AS xizmat_nomi,
                p.price AS narxi,
                p.created_at AS qabul_vaqti,
                p.phone_number AS telefon,
                DATEDIFF(NOW(), p.created_at) AS qarz_kunlari,
                p.debt AS qarzdor,
                p.doctor_income,
                p.nurse_income
              FROM patients p
              LEFT JOIN patient_services ps ON p.id = ps.patient_id
              LEFT JOIN services s ON ps.service_id = s.id
              WHERE DATE(p.created_at) = :today 
              AND (p.doctor_id = :user_id OR p.nurse_id = :user_id)
              AND (
                  (:role = 'shifokor' AND p.doctor_income > 0) OR 
                  (:role = 'hamshira' AND p.nurse_income > 0)
              )
              GROUP BY p.id
              ORDER BY p.created_at DESC";

    $stmt = $conn->prepare($query);
    $stmt->execute([
        'today' => $today,
        'user_id' => $user_id,
        'role' => $role
    ]);
    $today_patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Qarzdor bemorlar (har doim ko'rsatiladi)
$debt_query = "SELECT 
                p.id,
                p.full_name AS bemor_ismi,
                GROUP_CONCAT(s.name SEPARATOR ', ') AS xizmat_nomi,
                p.price AS narxi,
                p.created_at AS qabul_vaqti,
                p.phone_number AS telefon,
                DATEDIFF(NOW(), p.created_at) AS qarz_kunlari,
                p.debt AS qarzdor,
                p.doctor_income,
                p.nurse_income
              FROM patients p
              LEFT JOIN patient_services ps ON p.id = ps.patient_id
              LEFT JOIN services s ON ps.service_id = s.id
              WHERE p.debt = 1 
              AND (p.doctor_id = :user_id OR p.nurse_id = :user_id)
              AND (
                  (:role = 'shifokor' AND p.doctor_income > 0) OR 
                  (:role = 'hamshira' AND p.nurse_income > 0)
              )
              GROUP BY p.id
              ORDER BY p.created_at DESC";

$debt_stmt = $conn->prepare($debt_query);
$debt_stmt->execute([
    'user_id' => $user_id,
    'role' => $role
]);
$debt_patients = $debt_stmt->fetchAll(PDO::FETCH_ASSOC);

if (isset($_SESSION['message'])) {
    echo "<div class='alert alert-info'>{$_SESSION['message']}</div>";
    unset($_SESSION['message']);
}
?>

<div class="container mt-5">
    <!-- Tanlangan davr uchun hisobotlar -->
    <h2>Tanlangan Davr Uchun Hisobotlar</h2>
    <form method="POST" class="mb-4">
        <div class="row">
            <div class="col-md-3">
                <label for="start_date" class="form-label">Boshlanish sanasi:</label>
                <input type="date" name="start_date" id="start_date" class="form-control" 
                       value="<?= $start_date ?>" required>
            </div>
            <div class="col-md-3">
                <label for="end_date" class="form-label">Tugash sanasi:</label>
                <input type="date" name="end_date" id="end_date" class="form-control" 
                       value="<?= $end_date ?>" required>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary mt-4">Hisobotni Ko'rish</button>
                <?php if ($show_period_report): ?>
                    <a href="?" class="btn btn-secondary mt-4">Orqaga</a>
                <?php endif; ?>
            </div>
        </div>
    </form>

    <?php if ($show_period_report): ?>
        <!-- Tanlangan davr hisoboti -->
        <div class="table-responsive mt-4">
            <h3>Tanlangan davr hisoboti (<?= date('d.m.Y', strtotime($start_date)) ?> - <?= date('d.m.Y', strtotime($end_date)) ?>)</h3>
            <?php if (!empty($period_patients)): ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Bemor Ismi</th>
                            <th>Xizmat Nomi</th>
                            <th>Narxi</th>
                            <th>Qabul Vaqti</th>
                            <th>Telefon</th>
                            <th>Daromad</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($period_patients as $index => $patient): ?>
                            <tr class="<?= $patient['qarzdor'] ? 'table-danger' : '' ?>">
                                <td><?= $index + 1 ?></td>
                                <td><?= htmlspecialchars($patient['bemor_ismi']) ?></td>
                                <td><?= htmlspecialchars($patient['xizmat_nomi']) ?></td>
                                <td><?= number_format($patient['narxi'], 0, ',', ' ') ?> so'm</td>
                                <td><?= date('d.m.Y H:i', strtotime($patient['qabul_vaqti'])) ?></td>
                                <td>
                                    <?php if (!empty($patient['telefon'])): ?>
                                        <a href="tel:<?= $patient['telefon'] ?>" class="text-decoration-none">
                                            <?= formatPhoneNumber($patient['telefon']) ?>
                                        </a>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= number_format($role === 'shifokor' ? $patient['doctor_income'] : $patient['nurse_income'], 0, ',', ' ') ?> so'm
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-warning">Tanlangan davrda hech qanday bemor topilmadi.</div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <!-- Asosiy sahifa (bugungi bemorlar) -->
        <h1>Bugun <?= $role === 'shifokor' ? 'Shifokor' : 'Hamshira' ?> Hisobotlari</h1>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Bemor Ismi</th>
                        <th>Xizmat Nomi</th>
                        <th>Narxi</th>
                        <th>Qabul Vaqti</th>
                        <th>Telefon</th>
                        <th>Daromad</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($today_patients)): ?>
                        <?php foreach ($today_patients as $index => $patient): ?>
                            <tr class="<?= $patient['qarzdor'] ? 'table-danger' : '' ?>">
                                <td><?= $index + 1 ?></td>
                                <td><?= htmlspecialchars($patient['bemor_ismi']) ?></td>
                                <td><?= htmlspecialchars($patient['xizmat_nomi']) ?></td>
                                <td><?= number_format($patient['narxi'], 0, ',', ' ') ?> so'm</td>
                                <td><?= date('d.m.Y H:i', strtotime($patient['qabul_vaqti'])) ?></td>
                                <td>
                                    <?php if (!empty($patient['telefon'])): ?>
                                        <a href="tel:<?= $patient['telefon'] ?>" class="text-decoration-none">
                                            <?= formatPhoneNumber($patient['telefon']) ?>
                                        </a>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= number_format($role === 'shifokor' ? $patient['doctor_income'] : $patient['nurse_income'], 0, ',', ' ') ?> so'm
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7">Bugun hech qanday bemor topilmadi.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <!-- Qarzdor bemorlar ro'yxati (har doim ko'rsatiladi) -->
    <h2>Qarzdor Bemorlarim</h2>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Bemor Ismi</th>
                    <th>Xizmat Nomi</th>
                    <th>Narxi</th>
                    <th>Qabul Vaqti</th>
                    <th>Telefon</th>
                    <th>Qarz Kunlari</th>
                    <th>Daromad</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($debt_patients)): ?>
                    <?php foreach ($debt_patients as $index => $patient): ?>
                        <tr class="table-danger">
                            <td><?= $index + 1 ?></td>
                            <td><?= htmlspecialchars($patient['bemor_ismi']) ?></td>
                            <td><?= htmlspecialchars($patient['xizmat_nomi']) ?></td>
                            <td><?= number_format($patient['narxi'], 0, ',', ' ') ?> so'm</td>
                            <td><?= date('d.m.Y H:i', strtotime($patient['qabul_vaqti'])) ?></td>
                            <td>
                                <?php if (!empty($patient['telefon'])): ?>
                                    <a href="tel:<?= $patient['telefon'] ?>" class="text-decoration-none">
                                        <?= formatPhoneNumber($patient['telefon']) ?>
                                    </a>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><?= $patient['qarz_kunlari'] ?> kun</td>
                            <td>
                                <?= number_format($role === 'shifokor' ? $patient['doctor_income'] : $patient['nurse_income'], 0, ',', ' ') ?> so'm
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8">Qarzdor bemorlar topilmadi.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
include '../includes/body.php';
?>